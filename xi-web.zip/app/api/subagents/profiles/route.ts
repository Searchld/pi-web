import { NextResponse } from "next/server";
import { existsSync } from "fs";
import { getAllowedFileRoots, isExistingFilePathAllowed } from "@/lib/file-access";
import {
  deleteSubagentProfile,
  listSubagentProfileSources,
  saveSubagentProfile,
  type SubagentProfile,
  type SubagentWritableScope,
} from "@/lib/subagents";
import { writeDisabledBuiltInSubagent } from "@/lib/subagent-settings";
import { requireRuoyiSettingsAccess, requireRuoyiSharedSettingsWriteAccess, requireRuoyiOwnWorkspace } from "@/lib/ruoyi-settings-access";
import { isRuoyiIntegrationEnabled } from "@/lib/ruoyi-identity";

export const dynamic = "force-dynamic";

async function validateCwd(cwd: unknown): Promise<string> {
  if (typeof cwd !== "string" || !cwd || !existsSync(cwd)) throw new Error("Valid cwd required");
  if (!isExistingFilePathAllowed(cwd, await getAllowedFileRoots())) throw new Error("Access denied");
  return cwd;
}

function validateScope(scope: unknown): SubagentWritableScope {
  if (scope !== "global" && scope !== "project") throw new Error("scope must be global or project");
  return scope;
}

/** A built-in has no file to save or delete, but its switch is persisted all the same. */
function validateToggleScope(scope: unknown): SubagentWritableScope | "builtin" {
  if (scope === "builtin") return scope;
  if (scope !== "global" && scope !== "project") throw new Error("scope must be global, project, or builtin");
  return scope;
}

export async function GET(req: Request) {
  const denied = await requireRuoyiSettingsAccess(req, "agents");
  if (denied) return denied;
  try {
    const cwd = await validateCwd(new URL(req.url).searchParams.get("cwd"));
    const workspaceDenied = await requireRuoyiOwnWorkspace(req, cwd);
    if (workspaceDenied) return workspaceDenied;
    return NextResponse.json({ profiles: listSubagentProfileSources(cwd) });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json({ error: message }, { status: message === "Access denied" ? 403 : 400 });
  }
}

export async function PUT(req: Request) {
  const denied = await requireRuoyiSharedSettingsWriteAccess(req, "agents");
  if (denied) return denied;
  try {
    const body = await req.json() as {
      cwd?: unknown;
      scope?: unknown;
      profile?: Omit<SubagentProfile, "scope" | "filePath">;
    };
    const cwd = await validateCwd(body.cwd);
    const workspaceDenied = await requireRuoyiOwnWorkspace(req, cwd);
    if (workspaceDenied) return workspaceDenied;
    const requestedScope = validateScope(body.scope);
    const scope = isRuoyiIntegrationEnabled() ? "global" : requestedScope;
    if (!body.profile || typeof body.profile.name !== "string") {
      return NextResponse.json({ error: "profile required" }, { status: 400 });
    }
    return NextResponse.json({ profile: saveSubagentProfile(cwd, scope, body.profile) });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json({ error: message }, { status: message === "Access denied" ? 403 : 400 });
  }
}

export async function PATCH(req: Request) {
  const denied = await requireRuoyiSharedSettingsWriteAccess(req, "agents");
  if (denied) return denied;
  try {
    const body = await req.json() as { cwd?: unknown; scope?: unknown; name?: unknown; enabled?: unknown };
    const cwd = await validateCwd(body.cwd);
    const workspaceDenied = await requireRuoyiOwnWorkspace(req, cwd);
    if (workspaceDenied) return workspaceDenied;
    const scope = validateToggleScope(body.scope);
    if (typeof body.name !== "string") return NextResponse.json({ error: "name required" }, { status: 400 });
    if (typeof body.enabled !== "boolean") return NextResponse.json({ error: "enabled required" }, { status: 400 });
    const name = body.name;
    const source = listSubagentProfileSources(cwd).find((profile) =>
      profile.scope === scope && profile.name.toLowerCase() === name.toLowerCase()
    );
    if (!source) return NextResponse.json({ error: "Agent profile not found" }, { status: 404 });
    if (scope === "builtin") {
      writeDisabledBuiltInSubagent(source.name, !body.enabled);
      return NextResponse.json({ profile: { ...source, enabled: body.enabled } });
    }
    const profile: Omit<SubagentProfile, "scope" | "filePath"> = {
      name: source.name,
      displayName: source.displayName,
      description: source.description,
      systemPrompt: source.systemPrompt,
      tools: source.tools,
      ...(source.extensionTools !== undefined ? { extensionTools: [...source.extensionTools] } : {}),
      ...(source.disallowedExtensionTools !== undefined ? { disallowedExtensionTools: [...source.disallowedExtensionTools] } : {}),
      loadSkills: source.loadSkills,
      ...(source.skills !== undefined ? { skills: [...source.skills] } : {}),
      loadExtensions: source.loadExtensions,
      ...(source.extensions !== undefined ? { extensions: [...source.extensions] } : {}),
      codemode: source.codemode,
      mcp: source.mcp,
      promptMode: source.promptMode,
      model: source.model,
      thinking: source.thinking,
      maxTurns: source.maxTurns,
      inheritContext: source.inheritContext,
      runInBackground: source.runInBackground,
      color: source.color,
      isolation: source.isolation,
      persistSession: source.persistSession,
      enabled: source.enabled,
    };
    return NextResponse.json({ profile: saveSubagentProfile(cwd, scope, { ...profile, enabled: body.enabled }) });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json({ error: message }, { status: message === "Access denied" ? 403 : 400 });
  }
}

export async function DELETE(req: Request) {
  const denied = await requireRuoyiSharedSettingsWriteAccess(req, "agents");
  if (denied) return denied;
  try {
    const body = await req.json() as { cwd?: unknown; scope?: unknown; name?: unknown };
    const cwd = await validateCwd(body.cwd);
    const workspaceDenied = await requireRuoyiOwnWorkspace(req, cwd);
    if (workspaceDenied) return workspaceDenied;
    const scope = validateScope(body.scope);
    if (typeof body.name !== "string") return NextResponse.json({ error: "name required" }, { status: 400 });
    deleteSubagentProfile(cwd, scope, body.name);
    return NextResponse.json({ ok: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json({ error: message }, { status: message === "Access denied" ? 403 : 400 });
  }
}
