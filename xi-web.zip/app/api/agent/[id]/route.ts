import { NextResponse } from "next/server";
import { resolveSessionPath } from "@/lib/session-reader";
import { startRpcSession, getRpcSession, setRpcSessionTools } from "@/lib/rpc-manager";
import { isRuoyiAccessDenied, requireIntegrationSessionAccess } from "@/lib/ruoyi-session-access";
import { sameRuoyiCodingToolNames, sameRuoyiSkillNames, RuoyiToolAuthorizationError } from "@/lib/ruoyi-tool-policy";
import { RUOYI_WEB_SYSTEM_PROMPT } from "@/lib/ruoyi-business-tools";
import { loadRuoyiSystemPrompt } from "@/lib/ruoyi-system-prompt";
import { cwdMissingBody, missingCwdFromBody } from "@/lib/missing-cwd";

// POST /api/agent/[id] - Send a command to an existing session
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const access = await requireIntegrationSessionAccess(req, id);
  if (access && isRuoyiAccessDenied(access)) return access;
  let commandType: string | undefined;
  let promptAccepted = false;

  try {
    const body = await req.json() as { type: string; [key: string]: unknown };
    commandType = typeof body.type === "string" ? body.type : undefined;
    const requestedToolNames = body.toolNames;
    if (
      requestedToolNames !== undefined
      && (!Array.isArray(requestedToolNames) || requestedToolNames.some((name) => typeof name !== "string"))
    ) {
      throw new Error("toolNames must be an array of strings");
    }
    const toolNames = requestedToolNames as string[] | undefined;
    const ruoyiPolicy = access?.policy;
    const ruoyiSystemPrompt = access
      ? await loadRuoyiSystemPrompt(access.identity.userId, RUOYI_WEB_SYSTEM_PROMPT)
      : undefined;
    if (access && body.type === "bash" && !ruoyiPolicy!.toolNames.includes("bash")) {
      throw new RuoyiToolAuthorizationError("当前账户未获得终端命令权限");
    }

    // Fast path: already-running session
    const existing = getRpcSession(id);
    if (body.type === "set_tools") {
      if (access) throw new RuoyiToolAuthorizationError("Agent 工具由系统权限统一管理");
      const filePath = existing?.sessionFile || await resolveSessionPath(id) || undefined;
      if (!existing?.isAlive() && !filePath) {
        return NextResponse.json({ error: "Session not found" }, { status: 404 });
      }
      const changed = await setRpcSessionTools(id, filePath, toolNames);
      return NextResponse.json({
        success: true,
        data: { sessionId: changed.sessionId, recreated: changed.recreated },
      });
    }
    if (existing?.isAlive()) {
      let session = existing;
      if (access) {
        const currentTools = existing.isSideChat() ? existing.getRuoyiCodingToolNames() : existing.getActiveCodingToolNames();
        const codingToolsChanged = !currentTools || !sameRuoyiCodingToolNames(currentTools, ruoyiPolicy!.toolNames);
        const skillsChanged = !sameRuoyiSkillNames(existing.getRuoyiLoadedSkillNames(), ruoyiPolicy!.skillNames);
        existing.setRuoyiAuthorization(access.identity.authorization);
        existing.setRuoyiSystemPrompt(ruoyiSystemPrompt!);
        if ((codingToolsChanged || skillsChanged) && existing.isSideChat()) {
          if (existing.isRunning()) throw new Error("会话运行期间无法更新工具权限");
          const filePath = existing.sessionFile;
          await existing.shutdown();
          session = (await startRpcSession(id, filePath, undefined, {
            toolNames: ruoyiPolicy!.toolNames,
            ruoyiAuthorization: access.identity.authorization,
            ruoyiPolicy,
            ruoyiSystemPrompt,
            forceToolNames: true,
          })).session;
        } else if (codingToolsChanged || skillsChanged) {
          const tightened = await setRpcSessionTools(id, existing.sessionFile || undefined, ruoyiPolicy!.toolNames, {
            ruoyiAuthorization: access.identity.authorization,
            ruoyiPolicy,
            forceToolNames: true,
            ...(skillsChanged ? { recreateForResources: true } : {}),
          });
          session = tightened.session;
        }
        session.setRuoyiPolicy(ruoyiPolicy!);
      }
      const result = await session.send(body);
      promptAccepted = body.type === "prompt";
      return NextResponse.json({ success: true, data: result });
    }

    const filePath = await resolveSessionPath(id);
    if (!filePath) {
      return NextResponse.json({
        error: "Session not found",
        ...(body.type === "prompt"
          ? { code: "prompt_rejected", accepted: false }
          : {}),
      }, { status: 404 });
    }

    const initialToolNames = access ? ruoyiPolicy!.toolNames : toolNames;
    const { session } = await startRpcSession(id, filePath, undefined, {
      ...(initialToolNames !== undefined ? { toolNames: initialToolNames } : {}),
      ...(access ? { ruoyiAuthorization: access.identity.authorization } : {}),
      ...(ruoyiPolicy ? { ruoyiPolicy } : {}),
      ...(ruoyiSystemPrompt !== undefined ? { ruoyiSystemPrompt } : {}),
      ...(access ? { forceToolNames: true } : {}),
    });
    const result = await session.send(body);
    promptAccepted = body.type === "prompt";

    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    // Read by its fields: the wrapper that threw may come from another route's bundle.
    const missingCwd = missingCwdFromBody(error);
    return NextResponse.json({
      error: error instanceof Error ? error.message : String(error),
      ...(missingCwd ? cwdMissingBody(missingCwd) : {}),
      ...(commandType === "prompt" && !promptAccepted
        ? { code: "prompt_rejected", accepted: false }
        : {}),
    }, { status: error instanceof RuoyiToolAuthorizationError ? 403 : 500 });
  }
}

// GET /api/agent/[id] - Get current agent state
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const access = await requireIntegrationSessionAccess(req, id);
  if (access && isRuoyiAccessDenied(access)) return access;

  try {
    const session = getRpcSession(id);
    if (!session || !session.isAlive()) {
      return NextResponse.json({ running: false });
    }
    if (access) session.setRuoyiAuthorization(access.identity.authorization);

    const state = await session.send({ type: "get_state" }) as Record<string, unknown>;
    // Status reads leave out the system prompt, most of the reply (agentStatusUrl()).
    if (new URL(req.url).searchParams.get("systemPrompt") === "0") delete state.systemPrompt;
    return NextResponse.json({ running: true, state });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
