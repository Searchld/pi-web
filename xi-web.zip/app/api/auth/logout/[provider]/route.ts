import { invalidateModelsCache } from "@/lib/models-cache";
import { removeStoredCredentialIfType } from "@/lib/provider-credential-store";
import { getModelRuntimeWithExtensions } from "@/lib/model-runtime";
import { requireRuoyiSettingsAccess } from "@/lib/ruoyi-settings-access";

export const dynamic = "force-dynamic";

export async function POST(
  req: Request,
  { params }: { params: Promise<{ provider: string }> }
) {
  const denied = await requireRuoyiSettingsAccess(req, "models");
  if (denied) return denied;
  const { provider } = await params;
  const modelRuntime = await getModelRuntimeWithExtensions();
  if (!modelRuntime.getProvider(provider)?.auth.oauth) {
    return Response.json({ error: `Unknown provider: ${provider}` }, { status: 400 });
  }
  const removal = await removeStoredCredentialIfType(provider, "oauth");
  if (removal.status === "type_mismatch") {
    return Response.json({ error: `${provider} is authenticated with an API key, not OAuth` }, { status: 409 });
  }
  invalidateModelsCache();
  return Response.json({ ok: true });
}
