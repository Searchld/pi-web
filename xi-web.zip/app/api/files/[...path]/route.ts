import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import {
  allowFileRoot,
  getAllowedFileRoots,
  isExistingFilePathAllowed,
  isFilePathAllowed,
} from "@/lib/file-access";
import { checkLinkedDirectoryApproval, withOutsideLinkTargets } from "@/lib/linked-directory";
import {
  DOCX_PREVIEW_MAX_BYTES,
  IMAGE_PREVIEW_MAX_BYTES,
  XLSX_PREVIEW_MAX_BYTES,
  documentPreviewKind,
  getAudioMime,
  getDocumentMime,
  getFileExt,
  getImageMime,
  getVideoMime,
} from "@/lib/file-types";
import { resolveDirentIsDirectory } from "@/lib/file-dirent";
import { getFileTreeHiddenReasons } from "@/lib/file-tree-visibility";
import { isFilePathReferencedBySession } from "@/lib/session-file-references";
import { hasJsonContentType, isApiRequestAllowed } from "@/lib/request-security";
import {
  inspectUploadTargets,
  parseUploadConflictStrategy,
  replaceUploadFile,
  validateUploadFileNames,
} from "@/lib/file-upload";
import { parseFormDataWithinLimit, RequestBodyTooLargeError } from "@/lib/bounded-form-data";
import { filePathFromApiSegments, samePath } from "@/lib/paths";
import { hasParentDirectorySegment } from "@/lib/path-security";
import { readTextPreviewChunk } from "@/lib/text-preview";
import { isRuoyiIntegrationEnabled } from "@/lib/ruoyi-identity";
import { requireRuoyiToolAccess } from "@/lib/ruoyi-access";
import { getRuoyiEmbedOrigins } from "@/lib/ruoyi-embed-origins";
import { registerFileWatch } from "@/lib/file-watch-registry";
import { pageStreamLabel, registerPageStream } from "@/lib/page-stream-registry";

const FILE_REQUEST_TYPES = ["list", "read", "download", "meta", "preview", "watch"] as const;
type FileRequestType = typeof FILE_REQUEST_TYPES[number];
const FILE_REQUEST_TYPE_SET = new Set<string>(FILE_REQUEST_TYPES);
const MAX_UPLOAD_FILE_BYTES = 25 * 1024 * 1024;
const MAX_UPLOAD_TOTAL_BYTES = 100 * 1024 * 1024;
// Multipart boundaries and headers are not file bytes, but must be bounded too.
const MAX_UPLOAD_REQUEST_BYTES = MAX_UPLOAD_TOTAL_BYTES + 1024 * 1024;
const XLSX_PREVIEW_MAX_SHEETS = 10;
const XLSX_PREVIEW_MAX_ROWS = 500;
const XLSX_PREVIEW_MAX_COLUMNS = 50;

function documentPreviewContentSecurityPolicy(): string {
  // 文档预览自身与 Pi Web 同源，但在 RuoYi 的外层 iframe 中还会有一个
  // RuoYi 祖先页面。仅放行配置里的精确来源，避免放宽为任意站点可嵌入。
  const ancestors = ["'self'", ...getRuoyiEmbedOrigins(process.env.NEXT_PUBLIC_RUOYI_EMBED_ORIGIN)].join(" ");
  return `default-src 'none'; img-src data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors ${ancestors}`;
}

// The source view highlights every language here but text, pdf and word with
// the Prism grammar of that name (refractor/all); a name it lacks renders
// plain. "html" and "markdown" also turn on FileViewer's Preview, so templates
// that are not pages take "markup". `.m` stays plain: Objective-C and MATLAB
// both use it.
const EXT_TO_LANGUAGE: Record<string, string> = {
  ts: "typescript", tsx: "tsx", mts: "typescript", cts: "typescript",
  js: "javascript", jsx: "jsx", mjs: "javascript", cjs: "javascript",
  py: "python", rb: "ruby", php: "php", lua: "lua", pl: "perl", r: "r",
  go: "go", rs: "rust", java: "java", kt: "kotlin", kts: "kotlin", swift: "swift",
  scala: "scala", groovy: "groovy", gradle: "groovy", dart: "dart", zig: "zig",
  c: "c", cpp: "cpp", h: "c", hpp: "cpp", cs: "csharp", mm: "objectivec",
  ex: "elixir", exs: "elixir", hs: "haskell", ml: "ocaml", clj: "clojure", nix: "nix",
  html: "html", htm: "html", vue: "markup", svelte: "markup", astro: "markup",
  css: "css", scss: "scss", less: "less",
  json: "json", jsonl: "json", yaml: "yaml", yml: "yaml",
  toml: "toml", ini: "ini", cfg: "ini", properties: "properties",
  xml: "xml", md: "markdown", mdx: "markdown", tex: "latex",
  sh: "bash", bash: "bash", zsh: "bash", fish: "bash",
  ps1: "powershell", psm1: "powershell", bat: "batch", cmd: "batch",
  sql: "sql", graphql: "graphql", gql: "graphql", proto: "protobuf",
  dockerfile: "dockerfile", tf: "hcl", hcl: "hcl", diff: "diff", patch: "diff",
  env: "bash", gitignore: "bash", txt: "text",
  pdf: "pdf", docx: "word",
};

function getLanguage(filePath: string): string {
  const base = path.basename(filePath).toLowerCase();
  // Special full-name matches
  if (base === "dockerfile" || base.startsWith("dockerfile.")) return "dockerfile";
  if (base === ".env" || base.startsWith(".env.")) return "bash";
  if (base === "makefile" || base === "gnumakefile") return "makefile";
  const ext = base.split(".").pop() ?? "";
  return EXT_TO_LANGUAGE[ext] ?? "text";
}

function parseFileRequestType(value: string): FileRequestType | null {
  return FILE_REQUEST_TYPE_SET.has(value) ? (value as FileRequestType) : null;
}

async function getUploadDirectory(segments: string[], allowedRoots?: Set<string>): Promise<
  { directory: string } | { response: NextResponse }
> {
  const directory = filePathFromApiSegments(segments);
  const roots = allowedRoots ?? await getAllowedFileRoots();
  if (!isFilePathAllowed(directory, roots)) {
    return { response: NextResponse.json({ error: "Access denied" }, { status: 403 }) };
  }

  let stat: fs.Stats;
  try {
    stat = fs.statSync(directory);
  } catch {
    return { response: NextResponse.json({ error: "Upload directory not found" }, { status: 404 }) };
  }
  if (!stat.isDirectory()) {
    return { response: NextResponse.json({ error: "Upload target is not a directory" }, { status: 400 }) };
  }

  // A browsable directory can be a symlink. Resolve both sides before writes
  // so a symlink inside an allowed root cannot redirect uploads outside it.
  const realDirectory = fs.realpathSync(directory);
  const realRoots = new Set<string>();
  for (const root of roots) {
    try {
      realRoots.add(fs.realpathSync(root));
    } catch {
      // Ignore stale session roots that no longer exist.
    }
  }
  if (!isFilePathAllowed(realDirectory, realRoots)) {
    return { response: NextResponse.json({ error: "Access denied" }, { status: 403 }) };
  }

  return { directory: realDirectory };
}

// A directory link whose target is outside the allowed roots is listed but not
// browsable. Allowing it is the operator's explicit choice, the same one as
// selecting that directory as a workspace, and lasts until the server restarts.
async function allowLinkedDirectory(
  request: NextRequest,
  segments: string[],
): Promise<NextResponse> {
  if (isRuoyiIntegrationEnabled()) {
    return NextResponse.json({ error: "RuoYi 模式不允许授权工作区外的符号链接目录" }, { status: 403 });
  }
  if (!hasJsonContentType(request)) {
    return NextResponse.json({ error: "Content-Type must be application/json" }, { status: 415 });
  }
  const body = await request.json().catch(() => null) as { target?: unknown } | null;
  if (typeof body?.target !== "string" || !body.target) {
    return NextResponse.json({ error: "target must be the link target shown in the listing" }, { status: 400 });
  }
  const approval = checkLinkedDirectoryApproval(
    filePathFromApiSegments(segments),
    body.target,
    await getAllowedFileRoots(),
  );
  if (!approval.ok) {
    return NextResponse.json({ error: approval.error }, { status: approval.status });
  }
  if (!approval.alreadyAllowed) allowFileRoot(approval.target);
  return NextResponse.json({ path: approval.target });
}

function parseUploadFileNames(value: unknown): string[] | null {
  if (!Array.isArray(value) || !value.every((item) => typeof item === "string")) return null;
  return value;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  if (!isApiRequestAllowed(request)) {
    return NextResponse.json({ error: "Untrusted API request" }, { status: 403 });
  }

  try {
    const access = await requireRuoyiToolAccess(request, "write");
    if (access instanceof NextResponse) return access;
    const { path: segments } = await params;
    const type = request.nextUrl.searchParams.get("type") ?? "upload";
    if (type === "allow-link") return allowLinkedDirectory(request, segments);

    const uploadDirectory = await getUploadDirectory(segments, access ? new Set([access.workspace]) : undefined);
    if ("response" in uploadDirectory) return uploadDirectory.response;
    const { directory } = uploadDirectory;

    if (type === "upload-check") {
      const body = await request.json().catch(() => null) as { fileNames?: unknown } | null;
      const fileNames = parseUploadFileNames(body?.fileNames);
      if (!fileNames) {
        return NextResponse.json({ error: "fileNames must be an array of strings" }, { status: 400 });
      }
      const validationError = validateUploadFileNames(fileNames);
      if (validationError) {
        return NextResponse.json({ error: validationError }, { status: 400 });
      }
      return NextResponse.json(inspectUploadTargets(directory, fileNames));
    }

    if (type !== "upload") {
      return NextResponse.json({ error: "Invalid upload request type" }, { status: 400 });
    }

    const strategy = parseUploadConflictStrategy(request.nextUrl.searchParams.get("conflict"));
    if (!strategy) {
      return NextResponse.json({ error: "Invalid conflict strategy" }, { status: 400 });
    }

    let formData: FormData;
    try {
      formData = await parseFormDataWithinLimit(request, MAX_UPLOAD_REQUEST_BYTES);
    } catch (error) {
      if (error instanceof RequestBodyTooLargeError) {
        return NextResponse.json({ error: "Uploads must total 100MB or less" }, { status: 413 });
      }
      throw error;
    }
    const files = formData.getAll("files").filter((entry): entry is File => typeof entry !== "string");
    if (files.some((file) => file.size > MAX_UPLOAD_FILE_BYTES)) {
      return NextResponse.json({ error: "Each upload must be 25MB or smaller" }, { status: 413 });
    }
    if (files.reduce((total, file) => total + file.size, 0) > MAX_UPLOAD_TOTAL_BYTES) {
      return NextResponse.json({ error: "Uploads must total 100MB or less" }, { status: 413 });
    }
    const fileNames = files.map((file) => file.name);
    const validationError = validateUploadFileNames(fileNames);
    if (validationError) {
      return NextResponse.json({ error: validationError }, { status: 400 });
    }

    const inspection = inspectUploadTargets(directory, fileNames);
    if (strategy === "error" && inspection.conflicts.length > 0) {
      return NextResponse.json({
        error: "One or more files already exist",
        conflicts: inspection.conflicts,
        nonReplaceable: inspection.nonReplaceable,
      }, { status: 409 });
    }

    const conflictSet = new Set(inspection.conflicts);
    const nonReplaceableSet = new Set(inspection.nonReplaceable);
    const uploaded: string[] = [];
    const skipped: string[] = [];
    const errors: Array<{ name: string; error: string }> = [];

    for (const file of files) {
      const destination = path.join(directory, file.name);
      if (conflictSet.has(file.name) && strategy === "skip") {
        skipped.push(file.name);
        continue;
      }
      if (conflictSet.has(file.name) && nonReplaceableSet.has(file.name)) {
        errors.push({ name: file.name, error: "Cannot replace a directory or symbolic link" });
        continue;
      }

      let bytes: Buffer;
      try {
        bytes = Buffer.from(await file.arrayBuffer());
      } catch (error) {
        errors.push({ name: file.name, error: error instanceof Error ? error.message : String(error) });
        continue;
      }

      try {
        if (conflictSet.has(file.name)) {
          replaceUploadFile(destination, bytes);
        } else {
          fs.writeFileSync(destination, bytes, { flag: "wx" });
        }
        uploaded.push(file.name);
      } catch (error) {
        errors.push({ name: file.name, error: error instanceof Error ? error.message : String(error) });
      }
    }

    return NextResponse.json(
      { uploaded, skipped, errors },
      { status: errors.length > 0 ? 207 : 200 },
    );
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : String(error) }, { status: 500 });
  }
}

function createFileBodyStream(filePath: string, range?: { start: number; end: number }): ReadableStream<Uint8Array> {
  const fileStream = fs.createReadStream(filePath, range);
  let closed = false;

  return new ReadableStream<Uint8Array>({
    start(controller) {
      fileStream.on("data", (chunk: Buffer) => {
        if (closed) return;
        try {
          controller.enqueue(new Uint8Array(chunk));
        } catch {
          closed = true;
          fileStream.destroy();
        }
      });
      fileStream.once("end", () => {
        if (closed) return;
        closed = true;
        try {
          controller.close();
        } catch {
          // The browser may cancel media probes before the file stream ends.
        }
      });
      fileStream.once("error", (error) => {
        if (closed) return;
        closed = true;
        try {
          controller.error(error);
        } catch {
          // The response was already abandoned by the client.
        }
      });
    },
    cancel() {
      closed = true;
      fileStream.destroy();
    },
  });
}

function encodeHeaderValue(value: string): string {
  return encodeURIComponent(value).replace(/[!'()*]/g, (ch) =>
    `%${ch.charCodeAt(0).toString(16).toUpperCase()}`
  );
}

function getContentDisposition(filePath: string, asDownload = false): string {
  const disposition = asDownload ? "attachment" : "inline";
  const fileName = path.basename(filePath);
  const fallback = fileName.replace(/[^\x20-\x7E]|["\\;\r\n]/g, "_") || "download";
  return `${disposition}; filename="${fallback}"; filename*=UTF-8''${encodeHeaderValue(fileName)}`;
}

function streamFile(filePath: string, stat: fs.Stats, contentType: string, rangeHeader: string | null, asDownload = false): Response {
  const headers: Record<string, string> = {
    "Content-Type": contentType,
    "Cache-Control": "no-cache",
    "Accept-Ranges": "bytes",
    "Content-Disposition": getContentDisposition(filePath, asDownload),
    "X-Content-Type-Options": "nosniff",
  };
  // SVG is the only preview type a browser executes as a document. A
  // repo-controlled SVG navigated to directly (for example through a link in
  // a transcript) would otherwise run script in the Pi Web origin, where it
  // can call any /api route. These headers only affect document rendering;
  // <img> preview embedding ignores them.
  if (contentType === "image/svg+xml") {
    headers["Content-Security-Policy"] =
      "default-src 'none'; img-src data:; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'self'";
    headers["Referrer-Policy"] = "no-referrer";
  }

  if (!rangeHeader) {
    return new Response(createFileBodyStream(filePath), {
      headers: {
        ...headers,
        "Content-Length": String(stat.size),
      },
    });
  }

  const match = /^bytes=(\d*)-(\d*)$/.exec(rangeHeader);
  if (!match) {
    return new Response(null, {
      status: 416,
      headers: {
        ...headers,
        "Content-Range": `bytes */${stat.size}`,
      },
    });
  }

  let start = match[1] ? Number(match[1]) : 0;
  let end = match[2] ? Number(match[2]) : stat.size - 1;
  if (!match[1] && match[2]) {
    const suffixLength = Number(match[2]);
    start = Math.max(stat.size - suffixLength, 0);
    end = stat.size - 1;
  }

  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end < start || start >= stat.size) {
    return new Response(null, {
      status: 416,
      headers: {
        ...headers,
        "Content-Range": `bytes */${stat.size}`,
      },
    });
  }

  end = Math.min(end, stat.size - 1);
  const chunkSize = end - start + 1;
  return new Response(createFileBodyStream(filePath, { start, end }), {
    status: 206,
    headers: {
      ...headers,
      "Content-Length": String(chunkSize),
      "Content-Range": `bytes ${start}-${end}/${stat.size}`,
    },
  });
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function wrapDocxPreviewHtml(bodyHtml: string, fileName: string): string {
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { color-scheme: light; }
  html, body { margin: 0; min-height: 100%; background: #eef1f5; color: #171717; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; padding: 28px; }
  main {
    box-sizing: border-box;
    max-width: 840px;
    min-height: calc(100vh - 56px);
    margin: 0 auto;
    padding: 56px 64px;
    background: #fff;
    box-shadow: 0 8px 28px rgba(15, 23, 42, 0.14);
  }
  .file-title {
    margin: 0 0 28px;
    padding-bottom: 10px;
    border-bottom: 1px solid #e5e7eb;
    color: #6b7280;
    font: 12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    word-break: break-word;
  }
  h1, h2, h3, h4, h5, h6 { line-height: 1.3; margin: 1.1em 0 0.45em; color: #111827; }
  p { margin: 0.65em 0; line-height: 1.7; }
  table { border-collapse: collapse; max-width: 100%; margin: 1em 0; }
  th, td { border: 1px solid #d1d5db; padding: 6px 9px; vertical-align: top; }
  img { max-width: 100%; height: auto; }
  pre { white-space: pre-wrap; overflow-wrap: anywhere; }
  a { color: #2563eb; }
  @media (max-width: 720px) {
    body { padding: 0; background: #fff; }
    main { min-height: 100vh; padding: 28px 22px; box-shadow: none; }
  }
</style>
</head>
<body>
<main>
<div class="file-title">${escapeHtml(fileName)}</div>
${bodyHtml}
</main>
</body>
</html>`;
}

async function createXlsxPreviewHtml(filePath: string): Promise<string> {
  const xlsx = await import("xlsx");
  const workbook = xlsx.read(fs.readFileSync(filePath), {
    type: "buffer",
    cellFormula: false,
    cellHTML: false,
    sheetRows: XLSX_PREVIEW_MAX_ROWS,
  });
  const sheetNames = workbook.SheetNames.slice(0, XLSX_PREVIEW_MAX_SHEETS);
  if (sheetNames.length === 0) throw new Error("Workbook has no worksheets");

  const sheets = sheetNames.map((sheetName) => {
    const worksheet = workbook.Sheets[sheetName];
    const reference = worksheet?.["!ref"];
    if (!worksheet || !reference) {
      return `<section class="sheet"><h2>${escapeHtml(sheetName)}</h2><p class="empty">此工作表没有可显示的单元格。</p></section>`;
    }

    const range = xlsx.utils.decode_range(reference);
    const lastRow = Math.min(range.e.r, range.s.r + XLSX_PREVIEW_MAX_ROWS - 1);
    const lastColumn = Math.min(range.e.c, range.s.c + XLSX_PREVIEW_MAX_COLUMNS - 1);
    const rows: string[] = [];
    for (let row = range.s.r; row <= lastRow; row += 1) {
      const cells: string[] = [];
      for (let column = range.s.c; column <= lastColumn; column += 1) {
        const cell = worksheet[xlsx.utils.encode_cell({ r: row, c: column })];
        const value = cell ? xlsx.utils.format_cell(cell) : "";
        cells.push(`<td>${escapeHtml(value)}</td>`);
      }
      rows.push(`<tr><th scope="row">${row + 1}</th>${cells.join("")}</tr>`);
    }

    return `<section class="sheet"><h2>${escapeHtml(sheetName)}</h2><div class="table-wrap"><table><tbody>${rows.join("")}</tbody></table></div></section>`;
  });
  const omittedSheetNotice = workbook.SheetNames.length > sheetNames.length
    ? `<p class="notice">仅显示前 ${XLSX_PREVIEW_MAX_SHEETS} 个工作表。</p>`
    : "";

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { color-scheme: light; }
  html, body { margin: 0; min-height: 100%; background: #eef1f5; color: #171717; }
  body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; padding: 24px; }
  main { box-sizing: border-box; max-width: 1280px; margin: 0 auto; padding: 28px; background: #fff; box-shadow: 0 8px 28px rgba(15, 23, 42, 0.14); }
  .file-title { margin: 0 0 10px; color: #6b7280; font: 12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; overflow-wrap: anywhere; }
  .notice, .empty { margin: 0 0 18px; color: #6b7280; font-size: 13px; }
  .sheet { margin-top: 28px; }
  h2 { margin: 0 0 10px; color: #111827; font-size: 16px; }
  .table-wrap { overflow: auto; border: 1px solid #d1d5db; }
  table { border-collapse: collapse; min-width: 100%; font-size: 13px; }
  th, td { border: 1px solid #e5e7eb; padding: 6px 9px; text-align: left; vertical-align: top; white-space: pre-wrap; overflow-wrap: anywhere; }
  th { position: sticky; left: 0; background: #f8fafc; color: #64748b; font: 11px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; }
  td { min-width: 76px; max-width: 360px; }
  @media (max-width: 720px) { body { padding: 0; background: #fff; } main { min-height: 100vh; padding: 20px; box-shadow: none; } }
</style>
</head>
<body>
<main>
<div class="file-title">${escapeHtml(path.basename(filePath))}</div>
<p class="notice">每个工作表最多显示前 ${XLSX_PREVIEW_MAX_ROWS} 行和 ${XLSX_PREVIEW_MAX_COLUMNS} 列。</p>
${omittedSheetNotice}
${sheets.join("")}
</main>
</body>
</html>`;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ path: string[] }> }
) {
  try {
    const access = await requireRuoyiToolAccess(request, "read");
    if (access instanceof NextResponse) return access;
    const { path: segments } = await params;
    const filePath = filePathFromApiSegments(segments);
    // Authorization collapses `..` lexically, but the filesystem applies it
    // after following links, so `link/../x` names a file beside the link's
    // target, outside the roots. URL parsing already drops real `..` segments;
    // only an encoded slash inside a segment still carries one here. The
    // existing-path check refuses them too, but a file referenced by the
    // session skips that check.
    if (hasParentDirectorySegment(filePath)) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }
    const rawType = request.nextUrl.searchParams.get("type") ?? "list";
    const type = parseFileRequestType(rawType);
    if (!type) {
      return NextResponse.json({ error: "Invalid file request type" }, { status: 400 });
    }
    const sessionId = request.nextUrl.searchParams.get("sessionId");

    const allowedRoots = access ? new Set([access.workspace]) : await getAllowedFileRoots();
    const allowedByRoot = isFilePathAllowed(filePath, allowedRoots);
    const allowedBySessionReference =
      !access && !allowedByRoot &&
      type !== "list" &&
      await isFilePathReferencedBySession(filePath, sessionId);
    if (!allowedByRoot && !allowedBySessionReference) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }

    let stat: fs.Stats | undefined;
    try {
      stat = fs.statSync(filePath);
    } catch {
      if (type !== "watch") {
        return NextResponse.json({ error: "Not found" }, { status: 404 });
      }
    }

    const existingAuthorizationPath = stat ? filePath : path.dirname(filePath);
    if (
      !allowedBySessionReference
      && !isExistingFilePathAllowed(existingAuthorizationPath, allowedRoots)
    ) {
      return NextResponse.json({ error: "Access denied" }, { status: 403 });
    }

    if (type === "read") {
      if (!stat?.isFile()) {
        return NextResponse.json({ error: "Not a file" }, { status: 400 });
      }
      const imageMime = getImageMime(filePath);
      if (imageMime) {
        if (stat.size > IMAGE_PREVIEW_MAX_BYTES) {
          return NextResponse.json({ error: "Image too large (>10MB)" }, { status: 413 });
        }
        return streamFile(filePath, stat, imageMime, request.headers.get("range"));
      }
      const audioMime = getAudioMime(filePath);
      if (audioMime) {
        return streamFile(filePath, stat, audioMime, request.headers.get("range"));
      }
      const videoMime = getVideoMime(filePath);
      if (videoMime) {
        return streamFile(filePath, stat, videoMime, request.headers.get("range"));
      }
      const documentMime = getDocumentMime(filePath);
      if (documentMime) {
        return streamFile(filePath, stat, documentMime, request.headers.get("range"));
      }
      const rawOffset = request.nextUrl.searchParams.get("offset");
      if (rawOffset !== null && !/^\d+$/.test(rawOffset)) {
        return NextResponse.json({ error: "Invalid text preview offset" }, { status: 400 });
      }
      const offset = Number(rawOffset ?? 0);
      if (!Number.isSafeInteger(offset) || offset > stat.size) {
        return NextResponse.json({ error: "Invalid text preview offset" }, { status: 400 });
      }
      const chunk = readTextPreviewChunk(filePath, stat.size, offset);
      const language = getLanguage(filePath);
      return NextResponse.json({ ...chunk, language, size: stat.size, mtime: stat.mtime.toISOString() });
    }

    if (type === "download") {
      if (!stat?.isFile()) {
        return NextResponse.json({ error: "Not a file" }, { status: 400 });
      }
      const mime = getImageMime(filePath) || getAudioMime(filePath) || getVideoMime(filePath) || getDocumentMime(filePath) || "application/octet-stream";
      return streamFile(filePath, stat, mime, request.headers.get("range"), true);
    }

    if (type === "meta") {
      if (!stat?.isFile()) {
        return NextResponse.json({ error: "Not a file" }, { status: 400 });
      }
      const imageMime = getImageMime(filePath);
      const audioMime = getAudioMime(filePath);
      const videoMime = getVideoMime(filePath);
      const documentMime = getDocumentMime(filePath);
      return NextResponse.json({
        size: stat.size,
        // The watch's `change` events carry the same pair (lib/file-version.ts).
        mtime: stat.mtime.toISOString(),
        language: getLanguage(filePath),
        mime: imageMime || audioMime || videoMime || documentMime || "text/plain",
        previewKind: documentPreviewKind(filePath),
      });
    }

    if (type === "preview") {
      if (!stat?.isFile()) {
        return NextResponse.json({ error: "Not a file" }, { status: 400 });
      }
      const previewExtension = getFileExt(filePath);
      if (previewExtension !== "docx" && previewExtension !== "xlsx") {
        return NextResponse.json({ error: "Preview not available for this file type" }, { status: 400 });
      }
      const previewMaxBytes = previewExtension === "xlsx" ? XLSX_PREVIEW_MAX_BYTES : DOCX_PREVIEW_MAX_BYTES;
      if (stat.size > previewMaxBytes) {
        return NextResponse.json({ error: `${previewExtension.toUpperCase()} too large for preview (>10MB)` }, { status: 413 });
      }

      let html: string;
      try {
        if (previewExtension === "xlsx") {
          html = await createXlsxPreviewHtml(filePath);
        } else {
          const mammoth = await import("mammoth");
          const result = await mammoth.convertToHtml(
            { path: filePath },
            {
              externalFileAccess: false,
              convertImage: mammoth.images.dataUri,
            }
          );
          html = wrapDocxPreviewHtml(result.value, path.basename(filePath));
        }
      } catch {
        return NextResponse.json({ error: `Cannot preview ${previewExtension.toUpperCase()} file` }, { status: 422 });
      }
      return new Response(html, {
        headers: {
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "no-cache",
          "Content-Security-Policy": documentPreviewContentSecurityPolicy(),
          "Referrer-Policy": "no-referrer",
          "X-Content-Type-Options": "nosniff",
        },
      });
    }

    if (type === "watch") {
      if (stat && !stat.isFile()) {
        return NextResponse.json({ error: "Not a file" }, { status: 400 });
      }
      let watcher: fs.FSWatcher | null = null;
      // The debug panel's count of open watches; released when the watcher fails or the client cancels.
      let releaseWatch: (() => void) | null = null;
      let lastMtimeMs = stat?.mtimeMs ?? 0;
      let lastCtimeMs = stat?.ctimeMs ?? 0;
      let lastIno = stat?.ino ?? 0;
      let lastSize = stat?.size ?? 0;
      let lastExists = stat !== undefined;
      const stream = new ReadableStream({
        start(controller) {
          const send = (eventName: string, data: Record<string, unknown>) => {
            const payload = `event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`;
            try {
              controller.enqueue(new TextEncoder().encode(payload));
            } catch {
              // client disconnected
            }
          };
          try {
            const watchedDirectory = path.dirname(filePath);
            watcher = fs.watch(watchedDirectory, (_eventType, changedName) => {
              if (
                changedName != null
                && !samePath(path.join(watchedDirectory, changedName.toString()), filePath)
              ) return;
              try {
                const s = fs.statSync(filePath);
                // Some platforms emit watch events for file reads/attribute
                // access. Ignore those or the client's refresh read loops.
                if (
                  lastExists
                  && s.mtimeMs === lastMtimeMs
                  && s.ctimeMs === lastCtimeMs
                  && s.ino === lastIno
                  && s.size === lastSize
                ) return;
                lastExists = true;
                lastMtimeMs = s.mtimeMs;
                lastCtimeMs = s.ctimeMs;
                lastIno = s.ino;
                lastSize = s.size;
                send("change", { mtime: s.mtime.toISOString(), size: s.size });
              } catch {
                if (!lastExists) return;
                lastExists = false;
                send("change", { mtime: new Date().toISOString(), size: 0 });
              }
            });
            watcher.on("error", () => {
              try { watcher?.close(); } catch { /* ignore */ }
              watcher = null;
              releaseWatch?.();
              try { controller.close(); } catch { /* ignore */ }
            });
            // Counted, and listed under the page that opened it (`?holder=`).
            const releaseCount = registerFileWatch();
            const releasePage = registerPageStream(pageStreamLabel("file-watch", request));
            releaseWatch = () => {
              releaseCount();
              releasePage();
            };
            // A client gone without a cancel (a phone off the network) would keep
            // the watcher, and its place in the debug panel's count, forever.
            const onAbort = () => {
              try { watcher?.close(); } catch { /* ignore */ }
              watcher = null;
              releaseWatch?.();
              try { controller.close(); } catch { /* ignore */ }
            };
            if (request.signal.aborted) {
              onAbort();
              return;
            }
            request.signal.addEventListener("abort", onAbort, { once: true });
            // The client snapshots only after this event, so emit it after the
            // watcher exists to avoid dropping changes between those steps.
            send("connected", { filePath });
          } catch {
            send("error", { message: "Failed to watch file" });
            controller.close();
          }
        },
        cancel() {
          try { watcher?.close(); } catch { /* ignore */ }
          releaseWatch?.();
        },
      });
      return new Response(stream, {
        headers: {
          "Content-Type": "text/event-stream",
          "Cache-Control": "no-cache, no-transform",
          Connection: "keep-alive",
          "X-Accel-Buffering": "no",
        },
      });
    }

    // type === "list"
    if (!stat?.isDirectory()) {
      return NextResponse.json({ error: "Not a directory" }, { status: 400 });
    }

    // `hidden=1` (the explorer's "show hidden" switch) also lists what Git
    // ignores and what the name list hides, marked with the reason; `.pi`,
    // `.git` and `.DS_Store` stay out either way.
    const showHidden = request.nextUrl.searchParams.get("hidden") === "1";
    // Avoid per-entry stat calls for normal files and directories. Symlinks and
    // filesystems without directory type information use the stat fallback.
    const dirents = fs.readdirSync(filePath, { withFileTypes: true });
    const hiddenReason = await getFileTreeHiddenReasons(filePath, dirents.map((d) => d.name));
    const entries = dirents
      .flatMap((d) => {
        const hidden = hiddenReason(d.name);
        if (hidden === "always" || (hidden && !showHidden)) return [];
        const isDir = resolveDirentIsDirectory(d, path.join(filePath, d.name));
        if (isDir === null) return [];
        const entry = { name: d.name, isDir, size: 0, modified: "" };
        return [hidden ? { ...entry, hidden } : entry];
      })
      .sort((a, b) => {
        // Dirs first, then files, both alphabetically
        if (a.isDir !== b.isDir) return a.isDir ? -1 : 1;
        return a.name.localeCompare(b.name);
      });

    return NextResponse.json({
      entries: withOutsideLinkTargets(filePath, entries, dirents, allowedRoots),
      path: filePath,
    });
  } catch (error) {
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
