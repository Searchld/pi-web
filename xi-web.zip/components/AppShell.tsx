"use client";

import { useState, useCallback, useRef, useEffect, useLayoutEffect, useMemo } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useGlobalKeyboardShortcuts } from "@/hooks/useKeyboardShortcuts";
import { SessionSidebar, type SelectSessionOptions, type SessionSidebarControl } from "./SessionSidebar";
import { ChatWindow } from "./ChatWindow";
import { NewSessionContextBar, type NewSessionContextControl } from "./NewSessionContextBar";
import type { ChatScrollPosition } from "@/lib/chat-scroll-position";
import { FileExplorer, type FileExplorerHandle } from "./FileExplorer";
import { FileViewer } from "./FileViewer";
import { ChangesIcon, EyeIcon, FolderIcon, OpenInNewTabIcon, RefreshIcon, SearchIcon, TerminalIcon, UploadIcon } from "./SidebarIcons";
import { TabBar, type Tab } from "./TabBar";
import { movePanelTab, orderPanelTabs } from "@/lib/panel-tab-order";
import { openFileTab, saveFileViewerState, saveParkedFileViewerState, switchFileWorkspace, type ParkedFileWorkspace } from "./file-tab-state";
import { SettingsPanel, SettingsSectionIcon } from "./SettingsPanel";
import { ProjectTrustDialog, type ProjectTrustFailure } from "./ProjectTrustDialog";
import { BranchNavigator, hasSessionBranches } from "./BranchNavigator";
import { SystemPromptPanel } from "./SystemPromptPanel";
import { ToolDefinitionsPanel } from "./ToolDefinitionsPanel";
import { AgentSessionPanel } from "./AgentSessionPanel";
import { DebugPanel, DebugPanelBoundary } from "./DebugPanel";
import { SessionChatPanel } from "./SessionChatPanel";
import { TerminalPanel } from "./TerminalPanel";
import { DigitalHumanPanel, type DigitalHumanHandle } from "./DigitalHumanPanel";
import { newTerminalTab, restoreTerminalTabs, TERMINAL_TABS_KEY, type TerminalTab } from "./terminal-tab-state";
import { appendSideTab, restoreSideTabs, sideTabsKey } from "./side-tab-state";
import { useTheme } from "@/hooks/useTheme";
import { useFontPreferences } from "@/hooks/useFontPreferences";
import { useI18n } from "@/hooks/useI18n";
import { useIsMobile, useIsNarrowMobile } from "@/hooks/useIsMobile";
import { useViewportHeight } from "@/hooks/useViewportHeight";
import { useResizablePanel } from "@/hooks/useResizablePanel";
import { useAudio } from "@/hooks/useAudio";
import { copyText } from "@/lib/clipboard";
import { getFileName, getWorkspaceDownloadPath } from "@/lib/file-paths";
import { buildAtMentionText, buildFileAtMentionsText, buildFileLineMentionText } from "@/lib/file-fuzzy";
import {
  claimExtensionAttentionNotification,
  shouldShowBrowserNotification,
  showBrowserNotification,
} from "@/lib/browser-notifications";
import { setupPushSubscription } from "@/lib/push-client";
import { startPageVisibilityTracking } from "@/lib/page-debug";
import type { DebugClientSession } from "@/lib/debug-types";
import { getInitialNavigation, linkedSessionId, withTabOpen } from "@/lib/initial-navigation";
import { newSessionDeepLink, sessionDeepLink } from "@/lib/session-links";
import { clearTabOpenSession, getTabOpen, setTabOpenNewSession, setTabOpenSession } from "@/lib/tab-session";
import { mergeCatalogRow } from "./session-catalog-helpers";
import { getDraft, parkedNewSessionDraftKey, rekeyDraft } from "@/lib/draft-store";
import {
  contextForCwd,
  type NewSessionContext,
  type NewSessionMove,
  type NewSessionOptions,
  type NewSessionTarget,
  type ProjectChoice,
} from "@/lib/new-session-context";
import {
  clearLastOpen,
  getLastOpenSession,
  setLastOpenSession,
  workspaceKeyOf,
} from "@/lib/workspace-memory";
import {
  getDefaultRightPanelWidth,
  getRightPanelMaxWidth,
  getSidebarMaxWidth,
  RIGHT_PANEL_FALLBACK_WIDTH,
  RIGHT_PANEL_MAX_WIDTH,
  RIGHT_PANEL_MIN_WIDTH,
  SIDEBAR_DEFAULT_WIDTH,
  SIDEBAR_MAX_WIDTH,
  SIDEBAR_MIN_WIDTH,
} from "@/lib/panel-layout";
import type { BlockingExtensionUiRequest, SessionInfo, SessionTreeNode } from "@/lib/types";
import type { McpErrorResponse, ProjectTrustStatus } from "@/lib/api-types";
import type { ChatInputHandle } from "./ChatInput";
import type { AgentEndInfo, NewSessionChoices } from "@/hooks/useAgentSession";
import type { SessionStatsInfo } from "@/lib/pi-types";
import { formatActiveDuration, formatCompactCount, formatCostShort } from "@/lib/session-stats-format";
import type { FileViewerState } from "@/lib/file-viewer-state";
import { PRESET_READ_ONLY, type ToolEntry } from "@/lib/tool-presets";
import { createSideChat, deleteSideChat } from "@/lib/side-chat-client";
import { getAgentsBadge, getSessionFamily, isHiddenRelation, sideChatTitle } from "@/lib/session-family";
import { getLastSettingsSection, SETTINGS_SECTION_VALUES, settingsSectionRequiresProject, type SettingsSection } from "@/lib/settings-navigation";
import { getRuoyiAuthorization, setRuoyiAuthorization } from "@/lib/ruoyi-auth-client";
import { getRuoyiEmbedOrigins } from "@/lib/ruoyi-embed-origins";
import { focusIfLost } from "@/lib/stacked-dialog";

type SessionCopyField = "file" | "id" | "projectDir" | "gitBranch" | "gitWorktree";
type AutoNameStatus =
  | { kind: "idle" }
  | { kind: "naming" }
  | { kind: "success" }
  | { kind: "error"; message: string };
type RuoyiParentMessage = {
  type: string;
  hasSession?: boolean;
  screenX?: number;
  screenY?: number;
  text?: string;
  path?: string;
  aborted?: boolean;
  toolCallId?: string;
  toolName?: string;
  status?: "started" | "completed" | "failed";
};

// app/globals.css: 36px, 44px on a phone or touch screen.
const TOP_BAR_ICON_BUTTON_SIZE = "var(--top-bar-height)";
const AGENT_PANEL_WIDTH = 420;
// pi's built-in tools that never change a file; any other tool may (#1144).
const READ_ONLY_TOOL_NAMES = new Set(PRESET_READ_ONLY);
const TOOL_END_REFRESH_MS = 1000;
const RUOYI_EMBED_ORIGINS = getRuoyiEmbedOrigins(process.env.NEXT_PUBLIC_RUOYI_EMBED_ORIGIN);

/** Panel tab id of the last sub-agent tab, or null when there is none. */
function lastAgentTabId(tabs: readonly { sessionId: string }[]): string | null {
  const last = tabs.at(-1);
  return last ? `agent:${last.sessionId}` : null;
}

export function AppShell({ isRuoyiIntegration = false }: { isRuoyiIntegration?: boolean }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isEmbeddedRuoyi = searchParams.get("embedded") === "1";
  const isHeadlessRuoyi = searchParams.get("headless") === "1";
  const activeToolbarBackground = isRuoyiIntegration ? "#ecf5ff" : "var(--bg-selected)";
  const activeToolbarColor = isRuoyiIntegration ? "#409eff" : "var(--text)";
  const [initialNavigation, setInitialNavigation] = useState(() => getInitialNavigation(searchParams));
  const [isRuoyiAuthenticated, setIsRuoyiAuthenticated] = useState(() => !isEmbeddedRuoyi);
  const [isWorkbenchInline, setIsWorkbenchInline] = useState(false);
  const [ruoyiExternalPrompt, setRuoyiExternalPrompt] = useState<{ id: number; text: string } | null>(null);
  const ruoyiAuthTokenRef = useRef<string | null>(null);
  const ruoyiAuthAbortRef = useRef<AbortController | null>(null);
  const ruoyiAuthenticatedRef = useRef(!isEmbeddedRuoyi);
  const ruoyiPromptSequenceRef = useRef(0);
  const ruoyiParentOriginRef = useRef<string | null>(null);
  const getRuoyiParentOrigin = useCallback(() => {
    if (ruoyiParentOriginRef.current) return ruoyiParentOriginRef.current;
    try {
      const referrerOrigin = new URL(document.referrer).origin;
      return RUOYI_EMBED_ORIGINS.includes(referrerOrigin) ? referrerOrigin : null;
    } catch {
      return null;
    }
  }, []);
  const postRuoyiParentMessage = useCallback((message: RuoyiParentMessage) => {
    if (window.parent === window) return;
    const origin = getRuoyiParentOrigin();
    if (origin) window.parent.postMessage(message, origin);
  }, [getRuoyiParentOrigin]);
  useEffect(() => {
    // 企业集成由服务端开关决定；URL 未保留 embedded 参数时，也必须接收父页握手，
    // 否则标题栏的拖动和双击最大化无法把事件回传给 RuoYi 外层窗口。
    if (!isRuoyiIntegration && !isEmbeddedRuoyi) return;

    const notifyParent = (type: "qimiao-authenticated" | "qimiao-auth-failed") => {
      postRuoyiParentMessage({ type });
    };
    const establish = async (token: string) => {
      const currentController = ruoyiAuthAbortRef.current;
      // iframe 重挂载或开发环境的 effect 重放会中止旧请求；同一令牌此时必须重试。
      if (token === ruoyiAuthTokenRef.current && !currentController?.signal.aborted) return;
      currentController?.abort();
      const controller = new AbortController();
      ruoyiAuthAbortRef.current = controller;
      ruoyiAuthTokenRef.current = token;
      ruoyiAuthenticatedRef.current = false;
      setRuoyiExternalPrompt(null);
      setIsRuoyiAuthenticated(false);
      setInitialSessionRestored(false);
      setRuoyiAuthorization(token);
      try {
        const authResponse = await fetch("/api/ruoyi-auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token }),
          signal: controller.signal,
        });
        if (!authResponse.ok) throw new Error("RuoYi authentication failed");
        const workspaceResponse = await fetch("/api/ruoyi-workspace", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(getRuoyiAuthorization() ? { "X-RuoYi-Authorization": getRuoyiAuthorization()! } : {}),
          },
          signal: controller.signal,
        });
        const workspace = await workspaceResponse.json().catch(() => ({})) as { cwd?: string };
        if (!workspaceResponse.ok || !workspace.cwd || ruoyiAuthTokenRef.current !== token) {
          throw new Error("RuoYi workspace unavailable");
        }
        const sessionResponse = await fetch("/api/ruoyi-workbench/session", {
          cache: "no-store",
          headers: getRuoyiAuthorization()
            ? { "X-RuoYi-Authorization": getRuoyiAuthorization()! }
            : {},
          signal: controller.signal,
        });
        const savedSession = await sessionResponse.json().catch(() => ({})) as { sessionId?: unknown };
        if (!sessionResponse.ok || ruoyiAuthTokenRef.current !== token) {
          throw new Error("RuoYi workbench session unavailable");
        }
        const params = new URLSearchParams(window.location.search);
        const sessionId = typeof savedSession.sessionId === "string" ? savedSession.sessionId : null;
        if (sessionId) {
          params.delete("cwd");
          params.set("session", sessionId);
        } else {
          params.delete("session");
          params.set("cwd", workspace.cwd);
        }
        const nextUrl = `?${params.toString()}`;
        if (`?${new URLSearchParams(window.location.search).toString()}` !== nextUrl) {
          setInitialNavigation(getInitialNavigation(params));
          setInitialSessionRestored(Boolean(sessionId) ? false : true);
          router.replace(nextUrl, { scroll: false });
        } else if (sessionId) {
          setInitialNavigation(getInitialNavigation(params));
          setInitialSessionRestored(false);
        } else {
          setInitialSessionRestored(true);
        }
        ruoyiAuthenticatedRef.current = true;
        setIsRuoyiAuthenticated(true);
        postRuoyiParentMessage({ type: "qimiao-authenticated", hasSession: Boolean(sessionId) });
        if (isHeadlessRuoyi && sessionId) {
          // 会话接口再次校验当前用户归属；只向父页面返回最后一条助手正文。
          void fetch(`/api/sessions/${encodeURIComponent(sessionId)}?tail=50&tree=summary&deferThinking=1&deferMedia=1`, {
            cache: "no-store",
            headers: { "X-RuoYi-Authorization": token },
            signal: controller.signal,
          }).then(async (response) => {
            if (!response.ok) throw new Error("Session history unavailable");
            const data = await response.json() as { context?: { messages?: Array<{ role?: string; content?: unknown }> } };
            const messages = data.context?.messages ?? [];
            const answer = messages.findLast((message) => message.role === "assistant" && (
              typeof message.content === "string" ||
              (Array.isArray(message.content) && message.content.some((block: { type?: string; text?: string }) => block.type === "text" && block.text))
            ));
            const text = typeof answer?.content === "string"
              ? answer.content
              : Array.isArray(answer?.content)
                ? answer.content.filter((block: { type?: string }) => block.type === "text").map((block: { text?: string }) => block.text ?? "").join("")
                : "";
            if (!controller.signal.aborted && ruoyiAuthTokenRef.current === token) {
              postRuoyiParentMessage({ type: "qimiao-sidebar-last-answer", text });
            }
          }).catch(() => {
            if (!controller.signal.aborted && ruoyiAuthTokenRef.current === token) {
              postRuoyiParentMessage({ type: "qimiao-sidebar-last-answer", text: "", aborted: true });
            }
          });
        }
      } catch {
        if (!controller.signal.aborted && ruoyiAuthTokenRef.current === token) {
          ruoyiAuthenticatedRef.current = false;
          notifyParent("qimiao-auth-failed");
        }
      }
    };
    const receive = (event: MessageEvent) => {
      if (window.parent === window || event.source !== window.parent) return;
      if (!RUOYI_EMBED_ORIGINS.includes(event.origin)) return;
      ruoyiParentOriginRef.current = event.origin;
      if (event.data?.type === "qimiao-auth-clear") {
        ruoyiAuthAbortRef.current?.abort();
        ruoyiAuthTokenRef.current = null;
        ruoyiAuthenticatedRef.current = false;
        setRuoyiExternalPrompt(null);
        setIsRuoyiAuthenticated(false);
        void fetch("/api/ruoyi-auth", { method: "DELETE" })
          .then((response) => postRuoyiParentMessage({ type: "qimiao-auth-cleared", aborted: !response.ok }))
          .catch(() => postRuoyiParentMessage({ type: "qimiao-auth-cleared", aborted: true }));
        return;
      }
      if (event.data?.type === "qimiao-auth" && typeof event.data.token === "string" && event.data.token.trim()) {
        setIsWorkbenchInline(event.data.inlineWorkbench === true);
        void establish(event.data.token);
        return;
      }
      if (
        event.data?.type === "qimiao-agent-submit" &&
        ruoyiAuthenticatedRef.current &&
        typeof event.data.text === "string" &&
        event.data.text.trim()
      ) {
        const token = ruoyiAuthTokenRef.current;
        const controller = ruoyiAuthAbortRef.current;
        const text = event.data.text.trim();
        if (!token || !controller) return;
        // 只刷新认证 Cookie，不重建窗口或重新加载会话；提交前由 RuoYi 重新校验令牌。
        void fetch("/api/ruoyi-auth", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token }),
          signal: controller.signal,
        }).then(async (response) => {
          if (!response.ok) throw new Error("RuoYi authentication failed");
          if (controller.signal.aborted || ruoyiAuthTokenRef.current !== token || !ruoyiAuthenticatedRef.current) return;
          const sessionResponse = await fetch("/api/ruoyi-workbench/session", {
            cache: "no-store",
            headers: { "X-RuoYi-Authorization": token },
            signal: controller.signal,
          });
          if (!sessionResponse.ok) throw new Error("RuoYi workbench session unavailable");
          const currentSession = await sessionResponse.json() as { sessionId?: unknown };
          if (controller.signal.aborted || ruoyiAuthTokenRef.current !== token || !ruoyiAuthenticatedRef.current) return;
          if (typeof currentSession.sessionId === "string" && currentSession.sessionId !== activeSessionIdRef.current) {
            postRuoyiParentMessage({ type: "qimiao-agent-session-stale" });
            return;
          }
          ruoyiPromptSequenceRef.current += 1;
          setRuoyiExternalPrompt({ id: ruoyiPromptSequenceRef.current, text });
        }).catch(() => {
          if (!controller.signal.aborted && ruoyiAuthTokenRef.current === token) {
            ruoyiAuthenticatedRef.current = false;
            setIsRuoyiAuthenticated(false);
            postRuoyiParentMessage({ type: "qimiao-agent-response-end", aborted: true });
          }
        });
      }
    };
    window.addEventListener("message", receive);
    if (window.parent !== window && RUOYI_EMBED_ORIGINS.length > 0) {
      const ready = () => postRuoyiParentMessage({ type: "qimiao-ready" });
      ready();
      const retry = window.setTimeout(ready, 250);
      return () => {
        window.clearTimeout(retry);
        ruoyiAuthAbortRef.current?.abort();
        window.removeEventListener("message", receive);
      };
    }
    return () => {
      ruoyiAuthAbortRef.current?.abort();
      window.removeEventListener("message", receive);
    };
  }, [isEmbeddedRuoyi, isHeadlessRuoyi, isRuoyiIntegration, postRuoyiParentMessage, router]);
  // Keep the system-theme subscription mounted for the lifetime of the app.
  useTheme();
  // Restore fonts even when Settings and the chat composer have not been opened.
  useFontPreferences();
  const { locale, t: translate } = useI18n();
  const [terminalAccess, setTerminalAccess] = useState(() => ({
    ready: !isRuoyiIntegration,
    allowed: !isRuoyiIntegration,
  }));
  const [allowedSettingsSections, setAllowedSettingsSections] = useState<readonly SettingsSection[]>(
    () => isRuoyiIntegration ? [] : SETTINGS_SECTION_VALUES,
  );
  useEffect(() => {
    if (!isRuoyiIntegration) {
      setTerminalAccess({ ready: true, allowed: true });
      setAllowedSettingsSections(SETTINGS_SECTION_VALUES);
      return;
    }
    if (!isRuoyiAuthenticated) {
      setTerminalAccess({ ready: false, allowed: false });
      setAllowedSettingsSections([]);
      return;
    }
    const controller = new AbortController();
    const authorization = getRuoyiAuthorization();
    void fetch("/api/ruoyi-agent-policy", {
      headers: authorization ? { "X-RuoYi-Authorization": authorization } : undefined,
      signal: controller.signal,
    })
      .then(async (response) => response.ok ? response.json() as Promise<{ managed?: unknown; toolNames?: unknown; settingsSections?: unknown }> : null)
      .then((policy) => {
        if (controller.signal.aborted) return;
        setTerminalAccess({
          ready: true,
          allowed: policy?.managed !== true || (Array.isArray(policy.toolNames) && policy.toolNames.includes("bash")),
        });
        setAllowedSettingsSections(policy?.managed === true
          ? SETTINGS_SECTION_VALUES.filter((section) => Array.isArray(policy.settingsSections) && policy.settingsSections.includes(section))
          : SETTINGS_SECTION_VALUES);
      })
      .catch(() => {
        if (!controller.signal.aborted) {
          setTerminalAccess({ ready: true, allowed: false });
          setAllowedSettingsSections([]);
        }
      });
    return () => controller.abort();
  }, [isRuoyiIntegration, isRuoyiAuthenticated]);
  const isMobile = useIsMobile();
  const isNarrowMobile = useIsNarrowMobile();
  useViewportHeight();

  // Once the user has granted notification permission, register a Web Push
  // subscription so the server can notify backgrounded PWAs (notably iOS,
  // which suspends page JS and never receives the SSE completion event).
  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    if (Notification.permission !== "granted") return;
    void setupPushSubscription(locale);
  }, [locale]);
  // Audio ownership lives here (not in ChatWindow) so the completion tone can
  // also fire for tasks finishing in a non-active workspace whose ChatWindow
  // is not mounted. ChatWindow receives the audio callbacks as props.
  const { soundEnabled, onSoundToggle, playDoneSound, unlockAudio, holdAudio, soundEnabledRef } = useAudio();
  const [quoteSelectionEnabled, setQuoteSelectionEnabled] = useState(false);
  useEffect(() => {
    try {
      setQuoteSelectionEnabled(localStorage.getItem("pi-quote-selection-enabled") === "true");
    } catch {
      // Browser storage is best-effort.
    }
  }, []);
  const handleQuoteSelectionChange = useCallback((enabled: boolean) => {
    setQuoteSelectionEnabled(enabled);
    try {
      localStorage.setItem("pi-quote-selection-enabled", String(enabled));
    } catch {
      // Keep the current page usable when storage is unavailable.
    }
  }, []);
  const notifiedAttentionRequestIdsRef = useRef(new Set<string>());
  // Sessions that finished while the tab was out of sight (#1484): the browser
  // Notification fires for the selected session, which the sidebar's unread
  // markers exclude ("already looking" — false while hidden). The favicon keeps
  // their badge until the tab is opened again; never persisted, never dotted.
  const [hiddenFinishedSessionIds, setHiddenFinishedSessionIds] = useState<Set<string>>(new Set());
  const handleBackgroundTaskDone = useCallback(() => {
    if (soundEnabledRef.current) playDoneSound();
  }, [playDoneSound, soundEnabledRef]);
  const [selectedSession, setSelectedSession] = useState<SessionInfo | null>(null);
  // Latest selection readable from async callbacks whose captured state is
  // stale (e.g. a delete that completes after the user navigated away).
  const selectedSessionRef = useRef(selectedSession);
  selectedSessionRef.current = selectedSession;
  const [sessionCatalog, setSessionCatalog] = useState<SessionInfo[]>([]);
  const [catalogLoaded, setCatalogLoaded] = useState(false);
  const handleSessionsChange = useCallback((sessions: SessionInfo[]) => {
    setSessionCatalog(sessions);
    setCatalogLoaded(true);
    // The sidebar hydrates metadata after the selected session has already
    // mounted. Merge that update into the active session without changing the
    // ChatWindow key or restarting its history load.
    setSelectedSession((current) => {
      if (!current) return current;
      const refreshed = sessions.find((session) => session.id === current.id);
      return refreshed ? mergeCatalogRow(current, refreshed) : current;
    });
  }, []);
  const sessionsWithSelection = useMemo(() => {
    if (!selectedSession) return sessionCatalog;
    return [
      ...sessionCatalog.filter((session) => session.id !== selectedSession.id),
      selectedSession,
    ];
  }, [selectedSession, sessionCatalog]);
  const activeSessionFamily = useMemo(
    () => getSessionFamily(sessionsWithSelection, selectedSession?.id),
    [selectedSession?.id, sessionsWithSelection],
  );
  const [runningSessionIds, setRunningSessionIds] = useState<Set<string>>(() => new Set());
  const handleRunningSessionIdsChange = useCallback((ids: Set<string>) => {
    setRunningSessionIds((previous) => {
      if (previous.size === ids.size && [...ids].every((id) => previous.has(id))) return previous;
      return ids;
    });
  }, []);
  const agentsBadge = activeSessionFamily ? getAgentsBadge(activeSessionFamily.subagents, runningSessionIds) : null;
  const agentsButtonLabel = agentsBadge?.running
    ? translate("agentSwitcher.titleRunning", { count: agentsBadge.count })
    : translate("agentSwitcher.title");
  // The temporary id distinguishes consecutive fresh composers in one cwd.
  const [newSessionCwd, setNewSessionCwd] = useState<string | null>(null);
  const [newSessionDraftId, setNewSessionDraftId] = useState("initial");
  const activeNewSessionDraftKeyRef = useRef<string | null>(null);
  // The bar above a fresh composer (NewSessionContextBar): the sidebar reports
  // what it shows and carries out its moves, which remount the composer. Its
  // model and reasoning picks, as it last reported them, go along with the
  // draft to the composer that replaces it, which takes them once.
  const sidebarControlRef = useRef<SessionSidebarControl | null>(null);
  const [sidebarNewSessionContext, setSidebarNewSessionContext] = useState<NewSessionContext | null>(null);
  // The bar's last move until the sidebar reports that cwd (a commit later),
  // so the bar of the new composer shows the target's project, and a worktree
  // it just created, from its first frame.
  const newSessionMoveRef = useRef<NewSessionMove | null>(null);
  const handleSidebarNewSessionContext = useCallback((context: NewSessionContext | null) => {
    if (context && context.cwd === newSessionMoveRef.current?.cwd) newSessionMoveRef.current = null;
    setSidebarNewSessionContext(context);
  }, []);
  const newSessionBarFocusRef = useRef<NewSessionContextControl | null>(null);
  const newSessionChoicesRef = useRef<NewSessionChoices | null>(null);
  const [carriedNewSessionChoices, setCarriedNewSessionChoices] = useState<NewSessionChoices | null>(null);
  const handleNewSessionChoicesChange = useCallback((choices: NewSessionChoices) => {
    newSessionChoicesRef.current = choices;
    setCarriedNewSessionChoices(null);
  }, []);
  const [initialCwdStatus, setInitialCwdStatus] = useState<"idle" | "validating" | "ready" | "error">(
    () => initialNavigation.requestedCwd ? "validating" : "idle",
  );
  const [initialCwdError, setInitialCwdError] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);
  const [sessionKey, setSessionKey] = useState(0);
  const sessionScrollPositionsRef = useRef(new Map<string, ChatScrollPosition>());
  const handleSessionScrollPositionChange = useCallback((sessionId: string, position: ChatScrollPosition) => {
    sessionScrollPositionsRef.current.set(sessionId, position);
  }, []);
  const [searchTarget, setSearchTarget] = useState<{ sessionId: string; entryId: string; blockIndex?: number } | null>(null);
  const handleSearchTargetHandled = useCallback((target: { sessionId: string; entryId: string }) => {
    setSearchTarget((current) => current === target ? null : current);
  }, []);
  const [explorerRefreshKey, setExplorerRefreshKey] = useState(0);
  const [settingsSection, setSettingsSection] = useState<SettingsSection | null>(null);
  // The plain Settings button opens a phone's Settings on its list of sections; shortcuts open theirs.
  const [settingsOpenAtHome, setSettingsOpenAtHome] = useState(false);
  const [modelsRefreshKey, setModelsRefreshKey] = useState(0);
  const [projectTrust, setProjectTrust] = useState<ProjectTrustStatus | null>(null);
  const [projectTrustDialogOpen, setProjectTrustDialogOpen] = useState(false);
  const [projectTrustBusy, setProjectTrustBusy] = useState(false);
  const [projectTrustError, setProjectTrustError] = useState<ProjectTrustFailure | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(() => !initialNavigation.sidebarCollapsed);
  const desktopSidebarOpenRef = useRef(!initialNavigation.sidebarCollapsed);
  const [rightPanelOpen, setRightPanelOpen] = useState(false);
  const [digitalHumanOpen, setDigitalHumanOpen] = useState(false);
  const [digitalHumanVisibilityReady, setDigitalHumanVisibilityReady] = useState(!isRuoyiIntegration);
  const [digitalHumanAllowed, setDigitalHumanAllowed] = useState(false);
  const [rightPanelExpanded, setRightPanelExpanded] = useState(false);
  const [rightFileSearchOpen, setRightFileSearchOpen] = useState(false);
  const [rightExplorerUploadBusy, setRightExplorerUploadBusy] = useState(false);
  const [rightExplorerChangesCollapsed, setRightExplorerChangesCollapsed] = useState(true);
  const [rightExplorerChangesCount, setRightExplorerChangesCount] = useState(0);
  const [rightExplorerShowIgnoredFiles, setRightExplorerShowIgnoredFiles] = useState(false);
  const rightFileExplorerRef = useRef<FileExplorerHandle>(null);
  const rightPanelWasOpenRef = useRef(false);
  const rightPanelOpenRef = useRef(false);
  const digitalHumanHiddenByFilePanelRef = useRef(false);
  const digitalHumanVisibilitySavingRef = useRef(false);
  const rightPanelFullWidth = rightPanelOpen && rightPanelExpanded && !isMobile;
  useEffect(() => {
    if (!rightPanelOpen || isMobile) setRightPanelExpanded(false);
  }, [rightPanelOpen, isMobile]);
  useEffect(() => {
    rightPanelOpenRef.current = rightPanelOpen;
  }, [rightPanelOpen]);
  useEffect(() => {
    if (!isRuoyiIntegration) return;
    if (!isRuoyiAuthenticated) {
      setDigitalHumanAllowed(false);
      setDigitalHumanOpen(false);
      setDigitalHumanVisibilityReady(false);
      return;
    }
    let active = true;
    void fetch("/api/ruoyi-digital-human", { cache: "no-store" })
      .then(async (response) => response.ok ? response.json() as Promise<{ settings?: Record<string, string> }> : null)
      .then((response) => {
        if (!active) return;
        const allowed = response !== null;
        // 手机每次打开时默认关闭，不覆盖电脑端的账号偏好。
        const open = allowed && !window.matchMedia("(max-width: 640px)").matches
          && response.settings?.["ui.qimiao-web.digital-human-hidden"] !== "true";
        setDigitalHumanAllowed(allowed);
        digitalHumanHiddenByFilePanelRef.current = open && rightPanelOpenRef.current;
        setDigitalHumanOpen(open && !rightPanelOpenRef.current);
        setDigitalHumanVisibilityReady(true);
      })
      .catch(() => {
        if (!active) return;
        setDigitalHumanAllowed(false);
        digitalHumanHiddenByFilePanelRef.current = false;
        setDigitalHumanOpen(false);
        setDigitalHumanVisibilityReady(true);
      });
    return () => { active = false; };
  }, [isRuoyiIntegration, isRuoyiAuthenticated]);
  useEffect(() => {
    const justOpened = rightPanelOpen && !rightPanelWasOpenRef.current;
    const justClosed = !rightPanelOpen && rightPanelWasOpenRef.current;
    rightPanelWasOpenRef.current = rightPanelOpen;
    if (!isRuoyiIntegration) return;
    // 文件浏览器只恢复它自己自动隐藏的数字人，保留用户原本关闭的选择。
    if (justOpened) {
      digitalHumanHiddenByFilePanelRef.current = digitalHumanOpen;
      if (digitalHumanOpen) setDigitalHumanOpen(false);
    } else if (justClosed && digitalHumanHiddenByFilePanelRef.current) {
      digitalHumanHiddenByFilePanelRef.current = false;
      setDigitalHumanOpen(true);
    }
  }, [digitalHumanOpen, isRuoyiIntegration, rightPanelOpen]);
  const [mobileToolbarMoreOpen, setMobileToolbarMoreOpen] = useState(false);
  const moreControlsLabel = mobileToolbarMoreOpen ? translate("chat.close") : translate("chat.moreControls");
  const [mobileSidebarReady, setMobileSidebarReady] = useState(false);
  const sidebarWidthRef = useRef(SIDEBAR_DEFAULT_WIDTH);
  const rightPanelWidthRef = useRef(RIGHT_PANEL_FALLBACK_WIDTH);
  const getResponsiveRightPanelWidth = useCallback(
    () => typeof window === "undefined"
      ? RIGHT_PANEL_FALLBACK_WIDTH
      : getDefaultRightPanelWidth(window.innerWidth),
    [],
  );
  const getResponsiveSidebarMaxWidth = useCallback(
    () => typeof window === "undefined"
      ? SIDEBAR_MAX_WIDTH
      : getSidebarMaxWidth({
        viewportWidth: window.innerWidth,
        rightPanelOpen,
        rightPanelWidth: rightPanelWidthRef.current,
      }),
    [rightPanelOpen],
  );
  const getResponsiveRightPanelMaxWidth = useCallback(
    () => typeof window === "undefined"
      ? RIGHT_PANEL_MAX_WIDTH
      : getRightPanelMaxWidth({
        viewportWidth: window.innerWidth,
        sidebarOpen,
        sidebarWidth: sidebarWidthRef.current,
      }),
    [sidebarOpen],
  );
  const sidebarResizer = useResizablePanel({
    ariaLabel: translate("layout.resizeSidebar"),
    cssVariable: "--sidebar-width",
    defaultWidth: SIDEBAR_DEFAULT_WIDTH,
    getMaxWidth: getResponsiveSidebarMaxWidth,
    growthDirection: "right",
    maxWidth: SIDEBAR_MAX_WIDTH,
    minWidth: SIDEBAR_MIN_WIDTH,
    storageKey: "pi-sidebar-width",
    widthRef: sidebarWidthRef,
  });
  const rightPanelResizer = useResizablePanel({
    ariaLabel: translate("layout.resizeFilePanel"),
    cssVariable: "--right-panel-width",
    defaultWidth: RIGHT_PANEL_FALLBACK_WIDTH,
    getDefaultWidth: getResponsiveRightPanelWidth,
    getMaxWidth: getResponsiveRightPanelMaxWidth,
    growthDirection: "left",
    maxWidth: RIGHT_PANEL_MAX_WIDTH,
    minWidth: RIGHT_PANEL_MIN_WIDTH,
    storageKey: "pi-right-panel-width",
    widthRef: rightPanelWidthRef,
  });
  const reclampSidebarWidth = sidebarResizer.reclampWidth;
  const reclampRightPanelWidth = rightPanelResizer.reclampWidth;
  // On mobile the sidebar is an overlay drawer; hide it by default so the chat
  // is visible on load. Runs once the breakpoint resolves after hydration.
  // Mobile drawer actions must not change the remembered desktop preference.
  useEffect(() => {
    setSidebarOpen(isMobile ? false : desktopSidebarOpenRef.current);
  }, [isMobile]);
  useEffect(() => {
    setMobileSidebarReady(true);
  }, []);
  useEffect(() => {
    if (!rightPanelOpen) return;
    reclampSidebarWidth();
    reclampRightPanelWidth();
  }, [reclampRightPanelWidth, reclampSidebarWidth, rightPanelOpen]);
  const chatInputRef = useRef<ChatInputHandle | null>(null);
  // `/side <prompt>`: the text that seeds the side chat's composer, until its panel consumes it.
  const [sideChatPrompts, setSideChatPrompts] = useState<Record<string, string>>({});
  const topBarRef = useRef<HTMLDivElement>(null);
  // 父页只接受配置来源的窗口控制消息；普通 Pi Web 不参与这个嵌入式交互。
  const ruoyiToolbarPointerRef = useRef<{
    id: number;
    startX: number;
    startY: number;
    dragging: boolean;
  } | null>(null);
  const postRuoyiDialogEvent = useCallback((message: RuoyiParentMessage) => {
    postRuoyiParentMessage(message);
  }, [postRuoyiParentMessage]);
  const isRuoyiToolbarWindowGesture = useCallback((target: EventTarget | null) => {
    if (!(target instanceof Element)) return false;
    // 整个窗口顶栏都可作为标题栏：包括左侧 Web Agent、中间聊天和数字人顶部工具栏。
    return Boolean(target.closest(".qm-art-topbar, .session-sidebar.is-ruoyi-embedded .sidebar-header, .digital-human-panel__header"));
  }, []);
  const isRuoyiToolbarInteractiveElement = useCallback((target: EventTarget | null) => (
    target instanceof Element && Boolean(target.closest("button, a, input, select, textarea, [role='button'], [contenteditable='true']"))
  ), []);
  const handleRuoyiToolbarPointerDown = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0 || !isRuoyiToolbarWindowGesture(event.target)) return;
    if (isWorkbenchInline && isRuoyiToolbarInteractiveElement(event.target)) return;
    // 先保留原始单击。只有超过微小移动阈值时才捕获指针并进入拖动，避免按钮收不到 click。
    ruoyiToolbarPointerRef.current = {
      id: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      dragging: false,
    };
  }, [isRuoyiToolbarWindowGesture, isRuoyiToolbarInteractiveElement, isWorkbenchInline]);
  const handleRuoyiToolbarPointerMove = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    const pointer = ruoyiToolbarPointerRef.current;
    if (!pointer || pointer.id !== event.pointerId) return;
    if (!pointer.dragging) {
      if (Math.hypot(event.clientX - pointer.startX, event.clientY - pointer.startY) < 4) return;
      pointer.dragging = true;
      event.currentTarget.setPointerCapture(event.pointerId);
      postRuoyiDialogEvent({ type: "qimiao-dialog-drag-start", screenX: event.screenX, screenY: event.screenY });
    }
    postRuoyiDialogEvent({ type: "qimiao-dialog-drag-move", screenX: event.screenX, screenY: event.screenY });
  }, [postRuoyiDialogEvent]);
  const handleRuoyiToolbarPointerEnd = useCallback((event: React.PointerEvent<HTMLDivElement>) => {
    const pointer = ruoyiToolbarPointerRef.current;
    if (!pointer || pointer.id !== event.pointerId) return;
    if (pointer.dragging) {
      if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
      postRuoyiDialogEvent({ type: "qimiao-dialog-drag-end" });
    }
    ruoyiToolbarPointerRef.current = null;
  }, [postRuoyiDialogEvent]);
  useEffect(() => {
    if (!isRuoyiIntegration) return;
    // 拖动时根节点会持有 pointer capture，双击事件的 target 会被重定向到根节点；
    // 因此以坐标重新命中顶栏，而不是直接依赖 event.target。
    const handleDocumentDoubleClick = (event: MouseEvent) => {
      const target = document.elementFromPoint(event.clientX, event.clientY) ?? event.target;
      // 工具栏按钮的双击仍应是两次单击，不能放大外层 RuoYi 窗口。
      if (isWorkbenchInline || !isRuoyiToolbarWindowGesture(target) || isRuoyiToolbarInteractiveElement(target)) return;
      postRuoyiDialogEvent({ type: "qimiao-dialog-toggle-fullscreen" });
    };
    document.addEventListener("dblclick", handleDocumentDoubleClick, true);
    return () => document.removeEventListener("dblclick", handleDocumentDoubleClick, true);
  }, [isRuoyiIntegration, isWorkbenchInline, isRuoyiToolbarInteractiveElement, isRuoyiToolbarWindowGesture, postRuoyiDialogEvent]);
  const mobileToolbarRef = useRef<HTMLDivElement>(null);
  // Branch navigator state — populated by ChatWindow via onBranchDataChange
  const [branchTree, setBranchTree] = useState<SessionTreeNode[]>([]);
  const [branchActiveLeafId, setBranchActiveLeafId] = useState<string | null>(null);
  const [branchSwitchLocked, setBranchSwitchLocked] = useState(false);
  const branchLeafChangeFnRef = useRef<((leafId: string | null) => void) | null>(null);
  const sessionHasBranches = hasSessionBranches(branchTree);

  const handleBranchDataChange = useCallback((tree: SessionTreeNode[], activeLeafId: string | null, onLeafChange: (leafId: string | null) => void, locked: boolean) => {
    setBranchTree(tree);
    setBranchActiveLeafId(activeLeafId);
    setBranchSwitchLocked(locked);
    branchLeafChangeFnRef.current = onLeafChange;
  }, []);

  const handleBranchLeafChange = useCallback((leafId: string | null) => {
    branchLeafChangeFnRef.current?.(leafId);
  }, []);

  const [systemPrompt, setSystemPrompt] = useState<string | null>(null);
  const [systemTools, setSystemTools] = useState<ToolEntry[] | null>(null);
  const [systemInfoLoading, setSystemInfoLoading] = useState(false);
  const systemInfoLoaderRef = useRef<(() => Promise<void>) | null>(null);
  const systemInfoLoadIdRef = useRef(0);

  const handleSystemPromptChange = useCallback((prompt: string | null) => {
    setSystemPrompt(prompt);
    setSystemInfoLoading(false);
  }, []);

  const handleSystemToolsChange = useCallback((tools: ToolEntry[] | null) => {
    setSystemTools(tools);
  }, []);

  const handleSystemInfoLoaderChange = useCallback((loader: (() => Promise<void>) | null) => {
    systemInfoLoadIdRef.current += 1;
    systemInfoLoaderRef.current = loader;
    setSystemInfoLoading(false);
  }, []);

  // The debug panel's reader of the chat's own state: kept in a ref, so registering renders
  // nothing, and read only by the open panel (DebugPanel), never on AppShell's renders.
  const debugSnapshotReaderRef = useRef<(() => DebugClientSession) | null>(null);
  const handleDebugSnapshotReaderChange = useCallback((reader: (() => DebugClientSession) | null) => {
    debugSnapshotReaderRef.current = reader;
  }, []);
  // The panel reports the page's visibility history from the first mount on, opened or not.
  useEffect(() => {
    startPageVisibilityTracking();
  }, []);

  // Session stats (tokens + cost) — populated by ChatWindow, displayed in top bar
  const [sessionStats, setSessionStats] = useState<SessionStatsInfo | null>(null);
  const [autoNameStatus, setAutoNameStatus] = useState<AutoNameStatus>({ kind: "idle" });
  const autoNameTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const activeSessionIdRef = useRef<string | null>(selectedSession?.id ?? null);
  activeSessionIdRef.current = selectedSession?.id ?? null;
  const handleSessionStatsChange = useCallback((stats: SessionStatsInfo | null) => {
    setSessionStats(stats);
  }, []);
  const [copiedSessionField, setCopiedSessionField] = useState<SessionCopyField | null>(null);
  const sessionCopyTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleCopySessionField = useCallback((field: SessionCopyField, value: string) => {
    void copyText(value).then(() => {
      if (sessionCopyTimerRef.current) clearTimeout(sessionCopyTimerRef.current);
      setCopiedSessionField(field);
      sessionCopyTimerRef.current = setTimeout(() => setCopiedSessionField(null), 1400);
    });
  }, []);

  useEffect(() => {
    return () => {
      if (sessionCopyTimerRef.current) clearTimeout(sessionCopyTimerRef.current);
      if (autoNameTimerRef.current) clearTimeout(autoNameTimerRef.current);
    };
  }, []);

  // Context usage — populated by ChatWindow, displayed in top bar
  const [contextUsage, setContextUsage] = useState<{ percent: number | null; contextWindow: number; tokens: number | null } | null>(null);
  const handleContextUsageChange = useCallback((usage: { percent: number | null; contextWindow: number; tokens: number | null } | null) => {
    setContextUsage(usage);
  }, []);

  // Single active panel — only one dropdown open at a time
  const [activeTopPanel, setActiveTopPanel] = useState<"agents" | "branches" | "system" | "tools" | "session" | "debug" | null>(null);
  const [topPanelPos, setTopPanelPos] = useState<{ top: number; left: number; width: number } | null>(null);

  useEffect(() => {
    if (!sessionHasBranches) {
      setActiveTopPanel((panel) => panel === "branches" ? null : panel);
    }
  }, [sessionHasBranches]);

  useEffect(() => {
    if (!activeSessionFamily) {
      setActiveTopPanel((panel) => panel === "agents" ? null : panel);
    }
  }, [activeSessionFamily]);

  useEffect(() => {
    if (rightPanelFullWidth) setActiveTopPanel(null);
  }, [rightPanelFullWidth]);

  const toggleTopPanel = useCallback((
    panel: "agents" | "branches" | "system" | "tools" | "session" | "debug",
    keepMobileToolbarOpen = false,
  ) => {
    if (isMobile) setSidebarOpen(false);
    setActiveTopPanel((cur) => cur === panel ? null : panel);
    if (isMobile && isNarrowMobile && keepMobileToolbarOpen) setMobileToolbarMoreOpen(true);
  }, [isMobile, isNarrowMobile]);

  // The Debug button on screen (one of its three places at a time); Escape gives focus back to it.
  const debugButtonRef = useRef<HTMLButtonElement | null>(null);

  // Escape inside the debug panel; it never closes another panel that took its place. With focus
  // in the panel, that focus leaves the page with it: once the panel is gone (the next frame), the
  // Debug button gets it back, unless the user moved it meanwhile (focusIfLost).
  const closeDebugPanel = useCallback((restoreFocus: boolean) => {
    setActiveTopPanel((panel) => panel === "debug" ? null : panel);
    if (restoreFocus) requestAnimationFrame(() => focusIfLost(document, debugButtonRef.current));
  }, []);

  const handleSystemInfoToggle = useCallback((
    panel: "system" | "tools",
    keepMobileToolbarOpen = false,
  ) => {
    const opening = activeTopPanel !== panel;
    toggleTopPanel(panel, keepMobileToolbarOpen);
    if (!opening || systemInfoLoading) return;

    const load = systemInfoLoaderRef.current;
    if (!load) return;
    const loadId = ++systemInfoLoadIdRef.current;
    setSystemInfoLoading(true);
    void load().catch((error) => {
      console.error("Failed to load system information:", error);
    }).finally(() => {
      if (systemInfoLoadIdRef.current === loadId) {
        setSystemInfoLoading(false);
      }
    });
  }, [activeTopPanel, systemInfoLoading, toggleTopPanel]);

  const openSessionStatsPanel = useCallback(() => {
    if (isMobile) setSidebarOpen(false);
    setMobileToolbarMoreOpen(false);
    setActiveTopPanel("session");
  }, [isMobile]);

  // The composer opens Settings too: a bare /mcp opens Settings › MCP (useAgentSession).
  const openSettingsSection = useCallback((section: SettingsSection) => {
    if (allowedSettingsSections.includes(section)) {
      setSettingsOpenAtHome(false);
      setSettingsSection(section);
    }
  }, [allowedSettingsSections]);

  useEffect(() => {
    if (settingsSection && !allowedSettingsSections.includes(settingsSection)) setSettingsSection(null);
  }, [allowedSettingsSections, settingsSection]);

  const handleSidebarToggle = useCallback(() => {
    if (isMobile) {
      setActiveTopPanel(null);
      setMobileToolbarMoreOpen(false);
    }
    setSidebarOpen((open) => {
      const next = !open;
      if (!isMobile) desktopSidebarOpenRef.current = next;
      return next;
    });
  }, [isMobile]);

  const handleMobileToolbarMoreToggle = useCallback(() => {
    setSidebarOpen(false);
    setActiveTopPanel(null);
    setMobileToolbarMoreOpen((open) => !open);
  }, []);

  const handleRightPanelToggle = useCallback(() => {
    if (isMobile) {
      setSidebarOpen(false);
      setActiveTopPanel(null);
      setMobileToolbarMoreOpen(false);
    }
    setRightPanelOpen((open) => !open);
  }, [isMobile]);

  const updateDigitalHumanVisibility = useCallback(async (open: boolean) => {
    if (!digitalHumanAllowed || !digitalHumanVisibilityReady || digitalHumanVisibilitySavingRef.current) return;
    if (isMobile) {
      setDigitalHumanOpen(open);
      return;
    }
    const previousOpen = digitalHumanOpen;
    setDigitalHumanOpen(open);
    digitalHumanVisibilitySavingRef.current = true;
    try {
      const response = await fetch("/api/ruoyi-digital-human", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ digitalHumanHidden: !open }),
      });
      if (!response.ok) throw new Error("数字人显示偏好保存失败");
    } catch {
      setDigitalHumanOpen(previousOpen);
    } finally {
      digitalHumanVisibilitySavingRef.current = false;
    }
  }, [digitalHumanAllowed, digitalHumanOpen, digitalHumanVisibilityReady, isMobile]);

  const handleDigitalHumanToggle = useCallback(() => {
    if (isMobile) {
      setSidebarOpen(false);
      setActiveTopPanel(null);
      setMobileToolbarMoreOpen(false);
    }
    void updateDigitalHumanVisibility(!digitalHumanOpen);
  }, [digitalHumanOpen, isMobile, updateDigitalHumanVisibility]);

  const handleRightPanelExpandToggle = useCallback(() => {
    setActiveTopPanel(null);
    setRightPanelExpanded((expanded) => !expanded);
  }, []);

  useEffect(() => {
    if (!mobileToolbarMoreOpen) return;

    const handlePointerDown = (event: PointerEvent) => {
      const toolbar = mobileToolbarRef.current;
      if (toolbar && event.composedPath().includes(toolbar)) return;
      setMobileToolbarMoreOpen(false);
    };
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      event.preventDefault();
      event.stopPropagation();
      setMobileToolbarMoreOpen(false);
    };

    document.addEventListener("pointerdown", handlePointerDown, true);
    document.addEventListener("keydown", handleKeyDown, true);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown, true);
      document.removeEventListener("keydown", handleKeyDown, true);
    };
  }, [mobileToolbarMoreOpen]);

  useEffect(() => {
    setMobileToolbarMoreOpen(false);
  }, [isMobile, isNarrowMobile, selectedSession?.id, newSessionDraftId]);

  useEffect(() => {
    if (!activeTopPanel || !topBarRef.current) return;
    const update = () => {
      const topBarRect = topBarRef.current!.getBoundingClientRect();
      if (activeTopPanel === "agents") {
        setTopPanelPos({
          top: topBarRect.bottom,
          left: topBarRect.left,
          width: Math.min(AGENT_PANEL_WIDTH, topBarRect.width),
        });
        return;
      }
      setTopPanelPos({ top: topBarRect.bottom, left: topBarRect.left, width: topBarRect.width });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(topBarRef.current);
    return () => ro.disconnect();
  }, [activeTopPanel, isMobile]);

  // Files unmount when inactive; workspace terminals stay mounted until closed.
  const [fileTabs, setFileTabs] = useState<Tab[]>([]);
  const [activeFileTabId, setActiveFileTabId] = useState<string | null>(null);
  const digitalHumanRef = useRef<DigitalHumanHandle | null>(null);
  const pendingDigitalHumanSpeechRef = useRef<string | null>(null);
  useEffect(() => {
    if (!digitalHumanOpen) digitalHumanRef.current?.stop();
  }, [digitalHumanOpen]);
  const handleSpeakAnswer = useCallback((text: string) => {
    if (!digitalHumanAllowed || !text.trim()) return;
    if (digitalHumanOpen) {
      digitalHumanRef.current?.speakAnswer(text);
      return;
    }
    // 用户点击播报即表示希望看到数字人；同时将该选择保存为显示状态。
    pendingDigitalHumanSpeechRef.current = text;
    void updateDigitalHumanVisibility(true);
  }, [digitalHumanAllowed, digitalHumanOpen, updateDigitalHumanVisibility]);
  const handleDigitalHumanReady = useCallback(() => {
    const text = pendingDigitalHumanSpeechRef.current;
    if (!text) return;
    pendingDigitalHumanSpeechRef.current = null;
    digitalHumanRef.current?.speakAnswer(text);
  }, []);
  const fileWorkspaceStatesRef = useRef(new Map<string, ParkedFileWorkspace>());
  // Bumped on every workspace switch. The active viewer reports its state as
  // it unmounts, tagged with the generation it rendered in, so the report of a
  // tab just parked goes to its workspace, not to a same-path tab restored.
  const [fileWorkspaceGeneration, setFileWorkspaceGeneration] = useState(0);
  const fileWorkspaceGenerationRef = useRef(0);
  const [terminalTabs, setTerminalTabs] = useState<TerminalTab[]>([]);
  const [terminalsRestored, setTerminalsRestored] = useState(false);
  // Subagent tabs remain open within a project; side tabs follow their main session.
  const [agentTabs, setAgentTabs] = useState<{ sessionId: string; label: string; side?: boolean }[]>([]);
  const sideTabOwnerRef = useRef<string | null>(null);
  const sideTabsReadyRef = useRef(false);
  const sideTabsSavedOnWorkspaceSwitchRef = useRef(false);
  const [activeCwd, setActiveCwd] = useState<string | null>(null);
  const activeProjectKeyRef = useRef<string | null>(null);
  const [panelTabOrder, setPanelTabOrder] = useState<string[]>([]);
  const panelTabs: Tab[] = orderPanelTabs([
    ...fileTabs,
    ...terminalTabs.map((tab) => ({
      id: tab.id,
      label: getFileName(tab.cwd) || tab.cwd,
      filePath: tab.cwd,
      kind: "terminal" as const,
      closing: Boolean(tab.closing),
    })),
    ...agentTabs.map((tab) => {
      const session = tab.side ? sessionCatalog.find((item) => item.id === tab.sessionId) : undefined;
      const label = session ? sideChatTitle(session, translate("agentSwitcher.sideChat"), activeSessionFamily?.subagents ?? []) : tab.label;
      return {
        id: `agent:${tab.sessionId}`,
        label,
        filePath: label,
        kind: (tab.side ? "side" : "agent") as "agent" | "side",
      };
    }),
  ], panelTabOrder);
  // A closed tab leaves the saved order, so reopening it appends it like any new tab.
  const panelTabIds = panelTabs.map((tab) => tab.id).join("\n");
  useEffect(() => {
    const open = new Set(panelTabIds.split("\n"));
    setPanelTabOrder((order) => order.every((id) => open.has(id)) ? order : order.filter((id) => open.has(id)));
  }, [panelTabIds]);

  useEffect(() => {
    if (terminalsRestored || !terminalAccess.ready) return;
    try {
      if (terminalAccess.allowed) {
        const saved = restoreTerminalTabs(window.sessionStorage.getItem(TERMINAL_TABS_KEY));
        setTerminalTabs(saved.tabs);
        if (saved.activeId) {
          setActiveFileTabId(saved.activeId);
          setRightPanelOpen(saved.open);
        }
      }
    } catch { /* storage is optional */ }
    setTerminalsRestored(true);
  }, [terminalAccess, terminalsRestored]);

  useEffect(() => {
    if (!terminalAccess.ready || terminalAccess.allowed) return;
    setTerminalTabs([]);
    setActiveFileTabId((tabId) => /^[a-f0-9]{32}$/.test(tabId ?? "") ? null : tabId);
  }, [terminalAccess]);

  useEffect(() => {
    if (!terminalsRestored) return;
    try {
      window.sessionStorage.setItem(TERMINAL_TABS_KEY, JSON.stringify({
        tabs: terminalTabs.map(({ id, cwd }) => ({ id, cwd })),
        activeId: activeFileTabId,
        open: rightPanelOpen,
      }));
    } catch { /* storage is optional */ }
  }, [terminalTabs, activeFileTabId, rightPanelOpen, terminalsRestored]);

  const rememberSideTabs = useCallback((key: string) => {
    try {
      const tabs = agentTabs.filter((tab) => tab.side);
      // A session without side tabs keeps no entry: one per visited session otherwise.
      if (!tabs.length) {
        window.sessionStorage.removeItem(sideTabsKey(key));
        return;
      }
      window.sessionStorage.setItem(sideTabsKey(key), JSON.stringify({
        tabs,
        activeId: tabs.some((tab) => `agent:${tab.sessionId}` === activeFileTabId) ? activeFileTabId : null,
        open: rightPanelOpen,
      }));
    } catch { /* storage is optional */ }
  }, [agentTabs, activeFileTabId, rightPanelOpen]);

  const handleFileViewerStateChange = useCallback((
    generation: number,
    tabId: string,
    viewerRevision: number,
    viewerState: FileViewerState,
  ) => {
    if (generation !== fileWorkspaceGenerationRef.current) {
      saveParkedFileViewerState(fileWorkspaceStatesRef.current, generation, tabId, viewerRevision, viewerState);
      return;
    }
    setFileTabs((prev) => saveFileViewerState(prev, tabId, viewerRevision, viewerState));
  }, []);

  const changeFileWorkspace = useCallback((currentKey: string | null, nextKey: string) => {
    if (currentKey === nextKey) return;
    const activeFileId = activeFileTabId?.startsWith("file:") ? activeFileTabId : null;
    const next = switchFileWorkspace(fileWorkspaceStatesRef.current, currentKey, nextKey, {
      tabs: fileTabs,
      activeTabId: activeFileId,
      open: rightPanelOpen && Boolean(activeFileId),
    }, fileWorkspaceGenerationRef.current);
    fileWorkspaceGenerationRef.current += 1;
    setFileWorkspaceGeneration(fileWorkspaceGenerationRef.current);
    setFileTabs(next.tabs);
    // Subagent tabs are project-scoped; side tabs are saved under their main session.
    setAgentTabs((tabs) => tabs.filter((tab) => tab.side));
    if (sideTabsReadyRef.current && sideTabOwnerRef.current) {
      rememberSideTabs(sideTabOwnerRef.current);
      sideTabsSavedOnWorkspaceSwitchRef.current = true;
    }
    // Terminal tabs span workspaces and keep control of the panel while active.
    if (!activeFileTabId || activeFileId || activeFileTabId.startsWith("agent:")) {
      setActiveFileTabId(next.activeTabId);
      setRightPanelOpen(next.open);
    }
  }, [activeFileTabId, fileTabs, rememberSideTabs, rightPanelOpen]);

  // Same @mention format as the chat input's @ autocomplete, so the agent's
  // read tool resolves it the same way (it strips the @ prefix).
  const handleAtMention = useCallback((relativePath: string, isDir: boolean) => {
    chatInputRef.current?.insertText(buildAtMentionText(relativePath, isDir));
    if (isMobile) { setRightPanelOpen(false); setSidebarOpen(false); }
  }, [isMobile]);

  const handleAtMentions = useCallback((relativePaths: string[]) => {
    const mentions = buildFileAtMentionsText(relativePaths);
    if (mentions) chatInputRef.current?.insertText(mentions);
    if (isMobile) { setRightPanelOpen(false); setSidebarOpen(false); }
  }, [isMobile]);

  const handleFileLineMention = useCallback((relativePath: string, startLine: number, endLine: number) => {
    chatInputRef.current?.insertText(buildFileLineMentionText(relativePath, startLine, endLine));
    if (isMobile) { setRightPanelOpen(false); setSidebarOpen(false); }
  }, [isMobile]);

  const initialSessionId = initialNavigation.sessionId;
  const initialLinkedSessionId = linkedSessionId(initialNavigation);
  // True once the initial ?session= URL param has been resolved (or confirmed absent)
  const [initialSessionRestored, setInitialSessionRestored] = useState<boolean>(() => !initialSessionId);
  const sideTabOwner = activeSessionFamily?.root.id ?? null;
  useEffect(() => {
    if (!catalogLoaded || !initialSessionRestored) return;
    const previous = sideTabOwnerRef.current;
    if (!sideTabsReadyRef.current || previous !== sideTabOwner) {
      if (sideTabsReadyRef.current && previous && !sideTabsSavedOnWorkspaceSwitchRef.current) rememberSideTabs(previous);
      sideTabsSavedOnWorkspaceSwitchRef.current = false;
      sideTabsReadyRef.current = true;
      sideTabOwnerRef.current = sideTabOwner;
      let restored = { tabs: [] as { sessionId: string; label: string; side: true }[], activeId: null as string | null, open: false };
      if (sideTabOwner) {
        try { restored = restoreSideTabs(window.sessionStorage.getItem(sideTabsKey(sideTabOwner)), sideTabOwner, sessionCatalog); }
        catch { /* storage is optional */ }
      }
      setAgentTabs((tabs) => [...tabs.filter((tab) => !tab.side), ...restored.tabs]);
      const nextId = restored.activeId === `agent:${selectedSession?.id}` ? null : restored.activeId;
      if (nextId || activeFileTabId?.startsWith("agent:") || !activeFileTabId) {
        setActiveFileTabId(nextId ?? fileTabs.at(-1)?.id ?? terminalTabs.at(-1)?.id ?? null);
        setRightPanelOpen(nextId ? restored.open : Boolean(fileTabs.length || terminalTabs.length) && rightPanelOpen);
      }
      return;
    }
    if (sideTabOwner) rememberSideTabs(sideTabOwner);
    sideTabsSavedOnWorkspaceSwitchRef.current = false;
  }, [activeFileTabId, catalogLoaded, fileTabs, initialSessionRestored, rememberSideTabs, rightPanelOpen, selectedSession?.id, sessionCatalog, sideTabOwner, terminalTabs]);
  // sessionStorage is empty during SSR. Applying the tab's remembered session
  // in the useState initializer made the first client tree differ from the
  // server HTML (sidebar "select project" vs ""). Restore after mount instead.
  useLayoutEffect(() => {
    const next = withTabOpen(initialNavigation, getTabOpen());
    if (next === initialNavigation) return;
    setInitialNavigation(next);
    if (next.sessionId) setInitialSessionRestored(false);
  }, [initialNavigation]);
  // Suppresses sessionKey bump in handleCwdChange during the initial URL restore
  const suppressCwdBumpRef = useRef(false);
  // Set when the session the URL linked to is gone: the project the sidebar
  // adopts next keeps a fresh composer instead of restoring its last session.
  const skipWorkspaceRestoreRef = useRef(false);
  // Guards the async workspace restore so a slow response from an earlier
  // switch cannot resurrect a session into a project the user already left.
  const workspaceRestoreTokenRef = useRef(0);

  const invalidateWorkspaceRestore = useCallback(() => {
    workspaceRestoreTokenRef.current += 1;
  }, []);

  // Persist every active-session transition, including new and forked sessions
  // that bypass the sidebar selection handler. Transient sessions do not yet
  // carry projectKey, so use the active project identity until hydration.
  // The workspace memory is shared by every tab; the tab memory keeps this
  // tab's own session so a reload does not follow another tab's last pick.
  // New session is a selection too: remember the composer cwd so reload stays
  // on that UI instead of resurrecting the previous chat.
  useEffect(() => {
    if (selectedSession) {
      const projectKey = selectedSession.projectKey
        ?? activeProjectKeyRef.current
        ?? workspaceKeyOf(selectedSession);
      setLastOpenSession(projectKey, selectedSession.id);
      setTabOpenSession(selectedSession.id);
      return;
    }
    if (newSessionCwd) setTabOpenNewSession(newSessionCwd);
  }, [newSessionCwd, selectedSession]);

  useEffect(() => {
    const requestedCwd = initialNavigation.requestedCwd;
    if (!requestedCwd) return;

    const controller = new AbortController();
    setInitialCwdStatus("validating");
    setInitialCwdError(null);

    void fetch("/api/cwd/validate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ cwd: requestedCwd }),
      signal: controller.signal,
    })
      .then(async (response) => {
        const data = await response.json().catch(() => ({})) as { cwd?: string; error?: string };
        if (!response.ok || !data.cwd) {
          throw new Error(data.error ?? `HTTP ${response.status}`);
        }

        // The sidebar will notify us when it adopts this cwd. Avoid remounting
        // the just-created empty chat during that initial synchronization.
        suppressCwdBumpRef.current = true;
        const draftId = `initial:${requestedCwd}`;
        setNewSessionDraftId(draftId);
        activeNewSessionDraftKeyRef.current = `new:${draftId}:${data.cwd}`;
        setNewSessionCwd(data.cwd);
        setInitialCwdStatus("ready");
        if (!new URLSearchParams(window.location.search).get("cwd")) {
          router.replace(`?cwd=${encodeURIComponent(data.cwd)}`, { scroll: false });
        }
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setInitialCwdError(error instanceof Error ? error.message : String(error));
        setInitialCwdStatus("error");
      });

    return () => controller.abort();
  }, [initialNavigation, router]);

  // Restore the workspace's last open session after switching to it. Called
  // from handleCwdChange once the outgoing context has been reset. The session
  // is looked up against the live list so a deleted or drifted session falls
  // back to the default welcome page instead of erroring.
  const restoreWorkspaceContext = useCallback((projectKey: string, cwd: string) => {
    const token = ++workspaceRestoreTokenRef.current;
    const lastOpenSessionId = getLastOpenSession(projectKey);
    if (!lastOpenSessionId) return;
    const adopt = (d: { sessions: SessionInfo[] } | null) => {
      if (token !== workspaceRestoreTokenRef.current) return; // stale switch
      const s = d?.sessions.find((x) => x.id === lastOpenSessionId);
      if (!s) {
        // The list loaded but the remembered session is gone — forget it.
        // When the list itself failed (d === null) keep the memory so a
        // later switch retries the restore.
        if (d) clearLastOpen(projectKey);
        return;
      }
      if (workspaceKeyOf(s) !== projectKey) {
        // Defensive: the remembered session drifted out of this workspace.
        clearLastOpen(projectKey);
        return;
      }
      // Keep the temporary composer's draft in its cwd, even when the
      // remembered session belongs to another worktree of this project.
      const activeDraftKey = activeNewSessionDraftKeyRef.current;
      if (activeDraftKey) {
        rekeyDraft(activeDraftKey, parkedNewSessionDraftKey(cwd));
      }
      activeNewSessionDraftKeyRef.current = null;
      // Selecting the session must remount the chat with the session
      // present: useAgentSession loads content in a mount-only effect, so
      // the null-session welcome mount from the switch would never load
      // the restored session's messages.
      setSelectedSession(s);
      setSessionKey((k) => k + 1);
      if (new URLSearchParams(window.location.search).get("session") !== s.id) {
        router.replace(`?session=${encodeURIComponent(s.id)}`, { scroll: false });
      }
    };
    // Fast path: the sidebar already delivered the catalogue — restore
    // without waiting on a fresh /api/sessions round trip.
    if (sessionCatalog.length > 0) {
      adopt({ sessions: sessionCatalog });
      return;
    }
    void fetch("/api/sessions")
      .then((r) => (r.ok ? (r.json() as Promise<{ sessions: SessionInfo[] }>) : null))
      .then(adopt)
      .catch(() => {
        // Network hiccup: keep the remembered session for a later retry.
      });
  }, [router, sessionCatalog]);

  const handleCwdChange = useCallback((
    cwd: string | null,
    projectRoot?: string | null,
    projectKey?: string | null,
  ) => {
    invalidateWorkspaceRestore();
    const currentFreshCwd = newSessionCwd ?? activeCwd;
    setActiveCwd(cwd);
    // Skip if cwd is null (initial mount).
    if (!cwd) return;
    const skipWorkspaceRestore = skipWorkspaceRestoreRef.current;
    skipWorkspaceRestoreRef.current = false;
    const newProject = projectKey ?? projectRoot ?? cwd;
    const currentProject = activeProjectKeyRef.current
      ?? (selectedSession ? workspaceKeyOf(selectedSession) : null);
    activeProjectKeyRef.current = newProject;

    // Keep the project identity in sync during the initial URL restore without
    // remounting the just-created or restored chat.
    if (suppressCwdBumpRef.current) {
      suppressCwdBumpRef.current = false;
      return;
    }
    // The server may hydrate a normalized key after a custom cwd is already
    // active. Updating identity for the exact same cwd is not a user switch.
    if (currentFreshCwd === cwd && currentProject !== newProject) return;
    // Existing sessions stay open when the worktree selector moves within the
    // same project. A fresh composer must remount when its effective cwd moves,
    // otherwise its already-created runtime would keep sending to the old cwd.
    if (
      currentProject === newProject
      && (selectedSession !== null || currentFreshCwd === cwd)
    ) {
      return;
    }
    // Close any session that belongs to a different project — it no longer
    // matches the selected project directory.
    const previousDraftKey = activeNewSessionDraftKeyRef.current;
    if (previousDraftKey && currentFreshCwd) {
      rekeyDraft(previousDraftKey, parkedNewSessionDraftKey(currentFreshCwd));
    }
    const draftId = typeof crypto.randomUUID === "function"
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    const draftKey = `new:${draftId}:${cwd}`;
    rekeyDraft(parkedNewSessionDraftKey(cwd), draftKey);
    setNewSessionDraftId(draftId);
    activeNewSessionDraftKeyRef.current = draftKey;
    setSelectedSession(null);
    setNewSessionCwd((prev) => {
      if (prev && prev !== cwd) return null;
      return prev;
    });
    setSessionKey((k) => k + 1);
    setBranchTree([]);
    setBranchActiveLeafId(null);
    setBranchSwitchLocked(false);
    setSystemPrompt(null);
    setSystemTools(null);
    setSystemInfoLoading(false);
    // The debug panel stays open across the switch: it follows whichever session is shown.
    setActiveTopPanel((panel) => panel === "debug" ? panel : null);
    if (currentProject !== newProject) {
      // Keep #281's project isolation, but park each workspace's file tabs
      // instead of discarding them so they return when the user switches back.
      changeFileWorkspace(currentProject, newProject);
      // Restore the workspace we switched to: its last open session, or keep
      // the default welcome page when none is remembered.
      if (!skipWorkspaceRestore) restoreWorkspaceContext(newProject, cwd);
    }
    router.replace(typeof window !== "undefined" ? window.location.pathname : "/", { scroll: false });
  }, [activeCwd, changeFileWorkspace, invalidateWorkspaceRestore, newSessionCwd, router, selectedSession, restoreWorkspaceContext]);

  const persistRuoyiWorkbenchSession = useCallback((sessionId: string) => {
    if (!isRuoyiIntegration) return;
    void fetch("/api/ruoyi-workbench/session", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(getRuoyiAuthorization() ? { "X-RuoYi-Authorization": getRuoyiAuthorization()! } : {}),
      },
      body: JSON.stringify({ sessionId }),
    }).then((response) => {
      if (response.ok && !isHeadlessRuoyi) postRuoyiParentMessage({ type: "qimiao-workbench-session-changed" });
    }).catch(() => {});
  }, [isHeadlessRuoyi, isRuoyiIntegration, postRuoyiParentMessage]);

  const handleSelectSession = useCallback((session: SessionInfo, isRestore = false, entryId?: string, blockIndex?: number, options?: SelectSessionOptions) => {
    if (!isRestore) persistRuoyiWorkbenchSession(session.id);
    setSearchTarget(entryId ? { sessionId: session.id, entryId, blockIndex } : null);
    invalidateWorkspaceRestore();
    const activeDraftKey = activeNewSessionDraftKeyRef.current;
    const activeDraftCwd = newSessionCwd ?? (selectedSession === null ? activeCwd : null);
    if (activeDraftKey && activeDraftCwd) {
      rekeyDraft(activeDraftKey, parkedNewSessionDraftKey(activeDraftCwd));
    }
    activeNewSessionDraftKeyRef.current = null;
    // Adopt an explicitly selected session before the sidebar reports its cwd.
    const projectKey = workspaceKeyOf(session);
    if (activeProjectKeyRef.current !== projectKey) {
      changeFileWorkspace(activeProjectKeyRef.current, projectKey);
      setActiveTopPanel((panel) => panel === "debug" ? panel : null);
    }
    activeProjectKeyRef.current = projectKey;
    // Re-clicking the already-open session must not remount the chat and
    // re-run the full load/positioning cycle. Only skip when the effective
    // cwd context already matches — otherwise a pending cwd move still needs
    // the full re-select flow.
    if (!isRestore && selectedSession) {
      const sameProject =
        workspaceKeyOf(selectedSession) === workspaceKeyOf(session);
      if (selectedSession.id === session.id && sameProject) {
        if (isMobile) setSidebarOpen(false);
        return;
      }
    }
    setNewSessionCwd(null);
    setSelectedSession(session);
    setSessionKey((k) => k + 1);
    setBranchTree([]);
    setBranchActiveLeafId(null);
    setBranchSwitchLocked(false);
    branchLeafChangeFnRef.current = null;
    setSystemPrompt(null);
    setSystemTools(null);
    setSystemInfoLoading(false);
    setInitialSessionRestored(true);
    // On mobile, collapse the overlay drawer so the chat is revealed after pick
    // (unless the sidebar still has something to show: a fork's row and toast).
    if (isMobile && !isRestore && !options?.keepSidebarOpen) setSidebarOpen(false);
    if (isRestore) {
      // Suppress the redundant sessionKey bump that would come from the
      // onCwdChange effect firing after setSelectedCwd in the sidebar
      suppressCwdBumpRef.current = true;
    }
    // Skip router.replace when the URL already has this session — calling
    // replace in production Next.js triggers a Suspense remount loop.
    // Tab-memory restore lands on `/` and must write `?session=` so reload
    // and copy-link keep this session.
    if (!isRestore || new URLSearchParams(window.location.search).get("session") !== session.id) {
      router.replace(`?session=${encodeURIComponent(session.id)}`, { scroll: false });
    }
  }, [activeCwd, changeFileWorkspace, invalidateWorkspaceRestore, router, isMobile, newSessionCwd, persistRuoyiWorkbenchSession, selectedSession]);

  const handleNewSession = useCallback((sessionId: string, cwd: string, projectKey?: string | null, options?: NewSessionOptions) => {
    invalidateWorkspaceRestore();
    const draftKey = `new:${sessionId}:${cwd}`;
    // Leaving a fresh composer for another cwd parks its draft there, as a
    // workspace switch does; New in the same cwd still starts empty. The bar
    // above the composer moves the composer instead: its draft (the live
    // text, as promoteNewSession takes it) and its model picks go along.
    const activeDraftKey = activeNewSessionDraftKeyRef.current;
    const activeDraftCwd = newSessionCwd ?? (selectedSession === null ? activeCwd : null);
    if (options?.carryComposer && selectedSession === null && activeDraftKey) {
      const input = chatInputRef.current;
      if (input) input.rekeyDraft(activeDraftKey, draftKey);
      else rekeyDraft(activeDraftKey, draftKey);
      setCarriedNewSessionChoices(newSessionChoicesRef.current);
    } else if (activeDraftKey && activeDraftCwd && activeDraftCwd !== cwd) {
      rekeyDraft(activeDraftKey, parkedNewSessionDraftKey(activeDraftCwd));
    }
    // Adopt the target project before the sidebar reports its cwd, as an
    // explicit session pick does. Without a key (Ctrl+Alt+N) the current cwd
    // keeps its project.
    const targetProject = projectKey ?? (cwd === activeCwd ? activeProjectKeyRef.current : null) ?? cwd;
    if (activeProjectKeyRef.current !== targetProject) {
      changeFileWorkspace(activeProjectKeyRef.current, targetProject);
    }
    activeProjectKeyRef.current = targetProject;
    // A draft parked in this cwd comes back, unless one was carried here: it
    // stays parked for the next time, never merged into what was carried.
    if (!getDraft(draftKey)) rekeyDraft(parkedNewSessionDraftKey(cwd), draftKey);
    activeNewSessionDraftKeyRef.current = draftKey;
    setNewSessionDraftId(sessionId);
    setSelectedSession(null);
    setNewSessionCwd(cwd);
    setSessionKey((k) => k + 1);
    setBranchTree([]);
    setBranchActiveLeafId(null);
    setBranchSwitchLocked(false);
    setSystemPrompt(null);
    setSystemTools(null);
    setSystemInfoLoading(false);
    setActiveTopPanel((panel) => panel === "debug" ? panel : null);
    if (isMobile) setSidebarOpen(false);
    router.replace(`?cwd=${encodeURIComponent(cwd)}`, { scroll: false });
    // The fresh composer takes the caret once it renders (#1313), unless the
    // move came from the new-session bar, whose control keeps focus instead
    // (newSessionBarFocusRef), or a phone would raise the keyboard for it.
    // A dialog still open over the page (Ctrl+Alt+N under Settings) keeps it.
    if (!isMobile && !newSessionBarFocusRef.current) {
      requestAnimationFrame(() => {
        if (document.activeElement?.closest("[aria-modal='true']")) return;
        chatInputRef.current?.focus();
      });
    }
  }, [activeCwd, changeFileWorkspace, invalidateWorkspaceRestore, isMobile, newSessionCwd, router, selectedSession]);

  // Global keyboard shortcuts (handles Esc, Ctrl+Alt+N etc.)
  useGlobalKeyboardShortcuts({
    onNewSession: (cwd: string) => handleNewSession(`kb-${Date.now()}`, cwd),
    activeCwd,
  });

  // Client-built transient SessionInfo (new session / fork) lacks the
  // server-computed projectKey, which the same-project check in
  // handleCwdChange relies on. Hydrate it from the session list so switching
  // worktrees right after creating a session doesn't close the chat.
  const hydrateSelectedSession = useCallback((sessionId: string) => {
    void fetch("/api/sessions", { cache: "no-store" })
      .then((r) => (r.ok ? (r.json() as Promise<{ sessions: SessionInfo[] }>) : null))
      .then((d) => {
        const full = d?.sessions.find((s) => s.id === sessionId);
        if (!full) return;
        setSelectedSession((prev) => (
          prev?.id === sessionId
            ? { ...prev, ...full, transient: full.transient ?? false }
            : prev
        ));
      })
      .catch(() => {});
  }, []);

  // Called by ChatWindow when a new session gets its real id from pi
  const handleSessionCreated = useCallback((session: SessionInfo, sourceDraftKey: string) => {
    setRefreshKey((k) => k + 1);
    persistRuoyiWorkbenchSession(session.id);
    if (activeNewSessionDraftKeyRef.current !== sourceDraftKey) return;
    invalidateWorkspaceRestore();
    activeNewSessionDraftKeyRef.current = null;
    setNewSessionCwd(null);
    setSelectedSession(session);
    hydrateSelectedSession(session.id);
    router.replace(`?session=${encodeURIComponent(session.id)}`, { scroll: false });
  }, [invalidateWorkspaceRestore, router, hydrateSelectedSession, persistRuoyiWorkbenchSession]);

  const deliverSessionNotification = useCallback(({
    targetSession,
    title,
    body,
    tag,
  }: {
    targetSession: SessionInfo | null;
    title: string;
    body: string;
    tag?: string;
  }) => {
    if (!("Notification" in window)) return;

    const fire = () => {
      const sessionUrl = targetSession ? `/?session=${encodeURIComponent(targetSession.id)}` : "/";
      void showBrowserNotification({
        title,
        body,
        sessionUrl,
        tag,
        onClick: () => {
          window.focus();
          if (targetSession) handleSelectSession(targetSession);
        },
      });
    };

    if (Notification.permission === "granted") {
      fire();
      void setupPushSubscription(locale);
    } else if (Notification.permission === "default") {
      void Notification.requestPermission().then((p) => {
        if (p === "granted") {
          fire();
          void setupPushSubscription(locale);
        }
      });
    }
  }, [handleSelectSession, locale]);

  const handleAgentEnd = useCallback((end: AgentEndInfo) => {
    // The sidebar's reload merges the selected session's new row into it
    // (handleSessionsChange), so no list fetch of its own here.
    setRefreshKey((k) => k + 1);
    setExplorerRefreshKey((k) => k + 1);

    if (end.aborted || end.subagentsActive || isHiddenRelation(selectedSession?.relation)) return;
    if (!shouldShowBrowserNotification()) return;
    const targetSession = selectedSession;
    if (targetSession) {
      setHiddenFinishedSessionIds((prev) => {
        if (prev.has(targetSession.id)) return prev;
        const next = new Set(prev);
        next.add(targetSession.id);
        return next;
      });
    }
    deliverSessionNotification({
      targetSession,
      title: targetSession?.name ?? translate("i18n.sessionComplete"),
      body: translate("i18n.taskFinished"),
      tag: targetSession ? `pi-session-complete:${targetSession.id}` : "pi-session-complete",
    });
  }, [deliverSessionNotification, selectedSession, translate]);

  // The badge is for an unseen tab: opening it puts the finished chat on screen.
  useEffect(() => {
    const clearIfSeen = () => {
      if (document.visibilityState !== "visible" || !document.hasFocus()) return;
      setHiddenFinishedSessionIds((prev) => (prev.size === 0 ? prev : new Set()));
    };
    clearIfSeen();
    document.addEventListener("visibilitychange", clearIfSeen);
    window.addEventListener("focus", clearIfSeen);
    return () => {
      document.removeEventListener("visibilitychange", clearIfSeen);
      window.removeEventListener("focus", clearIfSeen);
    };
  }, []);

  const handleAttentionNeeded = useCallback((request: BlockingExtensionUiRequest) => {
    if (isHiddenRelation(selectedSession?.relation)) return;
    if (!shouldShowBrowserNotification()) return;
    if (!claimExtensionAttentionNotification(request, notifiedAttentionRequestIdsRef.current)) return;

    deliverSessionNotification({
      targetSession: selectedSession,
      title: translate("i18n.attentionNeeded"),
      body: request.method === "custom"
        ? translate("i18n.extensionInputNeeded")
        : request.title,
      tag: `pi-extension-ui:${request.id}`,
    });
  }, [deliverSessionNotification, selectedSession, translate]);

  const handleAutoName = useCallback(async () => {
    const sessionId = selectedSession?.id;
    if (!sessionId || autoNameStatus.kind === "naming") return;
    if (autoNameTimerRef.current) clearTimeout(autoNameTimerRef.current);
    setActiveTopPanel(null);
    setAutoNameStatus({ kind: "naming" });

    try {
      const response = await fetch(`/api/sessions/${encodeURIComponent(sessionId)}/auto-name`, {
        method: "POST",
      });
      const body = (await response.json().catch(() => ({}))) as { title?: string; error?: string };
      if (!response.ok || !body.title) {
        throw new Error(body.error || `HTTP ${response.status}`);
      }

      const title = body.title.trim();
      setRefreshKey((key) => key + 1);
      if (activeSessionIdRef.current !== sessionId) return;
      setSelectedSession((current) => current?.id === sessionId ? { ...current, name: title } : current);
      setSessionStats((current) => current?.sessionId === sessionId ? { ...current, sessionName: title } : current);
      setAutoNameStatus({ kind: "success" });
      autoNameTimerRef.current = setTimeout(() => setAutoNameStatus({ kind: "idle" }), 1800);
    } catch (error) {
      if (activeSessionIdRef.current !== sessionId) return;
      const message = error instanceof Error ? error.message : String(error);
      setAutoNameStatus({ kind: "error", message });
      autoNameTimerRef.current = setTimeout(() => setAutoNameStatus({ kind: "idle" }), 5000);
    }
  }, [autoNameStatus.kind, selectedSession?.id]);

  useEffect(() => {
    if (autoNameTimerRef.current) clearTimeout(autoNameTimerRef.current);
    setAutoNameStatus({ kind: "idle" });
  }, [selectedSession?.id]);

  const handleExplorerRefresh = useCallback(() => {
    setExplorerRefreshKey((k) => k + 1);
  }, []);

  // A run's writes show in the file tree as they happen, not only when it ends
  // (#1144): at most one refresh a second, after any tool but the read-only ones.
  const toolEndRefreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const handleToolEnd = useCallback((toolName: string) => {
    if (READ_ONLY_TOOL_NAMES.has(toolName) || toolEndRefreshTimerRef.current) return;
    toolEndRefreshTimerRef.current = setTimeout(() => {
      toolEndRefreshTimerRef.current = null;
      setExplorerRefreshKey((k) => k + 1);
    }, TOOL_END_REFRESH_MS);
  }, []);
  useEffect(() => () => {
    if (toolEndRefreshTimerRef.current) clearTimeout(toolEndRefreshTimerRef.current);
  }, []);

  const handleSessionForked = useCallback((newSessionId: string) => {
    invalidateWorkspaceRestore();
    activeNewSessionDraftKeyRef.current = null;
    setRefreshKey((k) => k + 1);
    setSessionKey((k) => k + 1);
    setNewSessionCwd(null);
    setSelectedSession((prev) => ({
      ...(prev ?? { path: "", cwd: "", created: "", modified: "", messageCount: 0, firstMessage: "" }),
      id: newSessionId,
      transient: false,
    }));
    hydrateSelectedSession(newSessionId);
    router.replace(`?session=${encodeURIComponent(newSessionId)}`, { scroll: false });
  }, [invalidateWorkspaceRestore, router, hydrateSelectedSession]);

  // The sidebar calls this when the initial session is not in its list.
  const handleInitialRestoreDone = useCallback(() => {
    setInitialSessionRestored(true);
    if (initialLinkedSessionId) skipWorkspaceRestoreRef.current = true;
  }, [initialLinkedSessionId]);

  const handleSessionDeleted = useCallback((sessionId: string) => {
    invalidateWorkspaceRestore();
    setRefreshKey((k) => k + 1);
    // The DELETE can outlive a session switch: this callback's captured
    // selectedSession is from the delete click. Read the latest selection
    // and only fall back to the empty composer when the user is still on
    // the deleted session at the moment removal completes.
    const active = selectedSessionRef.current;
    if (active?.id === sessionId) {
      clearTabOpenSession(sessionId);
      const cwd = active.cwd;
      const draftId = typeof crypto.randomUUID === "function"
        ? crypto.randomUUID()
        : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
      setNewSessionDraftId(draftId);
      activeNewSessionDraftKeyRef.current = cwd ? `new:${draftId}:${cwd}` : null;
      setSelectedSession(null);
      setNewSessionCwd(cwd ?? null);
      setSessionKey((k) => k + 1);
      setBranchTree([]);
      setBranchActiveLeafId(null);
      setBranchSwitchLocked(false);
      setSystemPrompt(null);
      setSystemTools(null);
      setSystemInfoLoading(false);
      setActiveTopPanel((panel) => panel === "debug" ? panel : null);
      router.replace(cwd ? `?cwd=${encodeURIComponent(cwd)}` : (typeof window !== "undefined" ? window.location.pathname : "/"), { scroll: false });
    }
  }, [invalidateWorkspaceRestore, router]);

  const handleOpenFile = useCallback((
    filePath: string,
    fileName: string,
    options?: { sourceSessionId?: string | null; modeHint?: "diff"; page?: number },
  ) => {
    const sourceSessionId = options?.sourceSessionId;
    const modeHint = options?.modeHint;
    const page = options?.page;
    const tabId = `file:${filePath}`;
    setFileTabs((prev) => openFileTab(prev, {
      fileName,
      filePath,
      modeHint,
      page,
      sourceSessionId,
      tabId,
    }));
    setActiveFileTabId(tabId);
    setRightPanelOpen(true);
    // RuoYi 的文件树与预览共用右侧栏；打开文件时自动展开，避免预览被树挤出视口。
    if (isRuoyiIntegration && !isMobile) setRightPanelExpanded(true);
    // On mobile the file panel is full-screen; close the drawer so it shows.
    if (isMobile) setSidebarOpen(false);
  }, [isMobile, isRuoyiIntegration]);

  const handleOpenLinkedFile = useCallback((filePath: string, page?: number, options?: { download?: boolean }) => {
    // 会话切换可能移除 embedded 参数，仍需通过父页面完成认证下载。
    if (options?.download && isRuoyiIntegration && window.parent !== window && ruoyiAuthenticatedRef.current) {
      const path = getWorkspaceDownloadPath(filePath, selectedSession?.cwd ?? newSessionCwd ?? activeCwd ?? undefined);
      if (path) postRuoyiParentMessage({ type: "qimiao-file-download", path });
      return;
    }
    handleOpenFile(filePath, getFileName(filePath), { sourceSessionId: selectedSession?.id ?? null, page });
  }, [handleOpenFile, selectedSession?.cwd, selectedSession?.id, newSessionCwd, activeCwd, isRuoyiIntegration, postRuoyiParentMessage]);

  const handleOpenTerminal = useCallback((cwd: string) => {
    if (!terminalAccess.allowed) return;
    const existing = terminalTabs.find((tab) => tab.cwd === cwd);
    const tab = existing ?? newTerminalTab(cwd);
    if (!existing) setTerminalTabs((tabs) => [...tabs, tab]);
    setActiveFileTabId(tab.id);
    setRightPanelOpen(true);
    if (isMobile) setSidebarOpen(false);
  }, [terminalAccess.allowed, terminalTabs, isMobile]);

  // Subagent work opens in a right-panel tab instead of hijacking the main chat.
  const handleOpenSubagentTab = useCallback((sessionId: string, label: string, side?: boolean) => {
    setAgentTabs((prev) => prev.some((tab) => tab.sessionId === sessionId)
      ? prev
      : [...prev, { sessionId, label, ...(side ? { side: true } : {}) }]);
    setActiveFileTabId(`agent:${sessionId}`);
    setRightPanelOpen(true);
    if (isMobile) setSidebarOpen(false);
  }, [isMobile]);

  // The agent switcher's side-panel button: opens a subagent's tab, or closes
  // it when the open panel already has it (the panel closes with its last tab).
  // The switcher stays open beside the panel, except on phones, where the
  // panel covers the chat.
  const openSubagentTabIds = useMemo(
    () => new Set(rightPanelOpen ? agentTabs.map((tab) => tab.sessionId) : []),
    [agentTabs, rightPanelOpen],
  );
  const handleToggleSubagentTab = (sessionId: string, label: string, side?: boolean) => {
    if (openSubagentTabIds.has(sessionId)) {
      handleCloseFileTab(`agent:${sessionId}`);
      return;
    }
    if (isMobile) setActiveTopPanel(null);
    handleOpenSubagentTab(sessionId, label, side);
  };

  // `/side` landed (hooks/useAgentSession): open the forked chat's tab, seed
  // its composer when the command carried a prompt, and refresh the list so
  // the family's badge folds the new member in.
  const handleSideSession = useCallback((session: SessionInfo, prompt: string | null) => {
    if (prompt) setSideChatPrompts((prev) => ({ ...prev, [session.id]: prompt }));
    setSessionCatalog((prev) => [session, ...prev.filter((item) => item.id !== session.id)]);
    const label = translate("agentSwitcher.sideChat");
    const parentId = session.relation?.kind === "side" ? session.relation.parentSessionId : null;
    if (parentId && parentId !== sideTabOwnerRef.current) {
      // The fork landed after the main chat moved on: the tab waits with its own session.
      try {
        const key = sideTabsKey(parentId);
        window.sessionStorage.setItem(key, appendSideTab(window.sessionStorage.getItem(key), session.id, label));
      } catch { /* storage is optional */ }
    } else {
      handleOpenSubagentTab(session.id, label, true);
    }
    setRefreshKey((key) => key + 1);
  }, [handleOpenSubagentTab, translate]);

  // The switcher's New side chat, on the main agent's row, whichever family member the main chat shows.
  const handleNewSideChat = useCallback(async (rootSessionId: string) => {
    const result = await createSideChat(rootSessionId, translate);
    if ("error" in result) return result.error;
    if (isMobile) setActiveTopPanel(null);
    handleSideSession(result.session, null);
    return null;
  }, [handleSideSession, isMobile, translate]);

  // A side chat's first prompt names it: read the name when a run in an open tab starts or ends.
  const runningSideTabs = agentTabs.filter((tab) => tab.side && runningSessionIds.has(tab.sessionId)).map((tab) => tab.sessionId).join();
  useEffect(() => {
    if (runningSideTabs) setRefreshKey((key) => key + 1);
  }, [runningSideTabs]);

  const handleTerminalClosed = (tab: TerminalTab) => {
    const replacement = tab.closing === "restart" ? newTerminalTab(tab.cwd) : null;
    const remaining = terminalTabs.filter((item) => item.id !== tab.id);
    setTerminalTabs((tabs) => tabs.flatMap((item) => item.id !== tab.id ? [item] : replacement ? [replacement] : []));
    setActiveFileTabId((current) => current !== tab.id ? current : replacement?.id ?? remaining.at(-1)?.id ?? fileTabs.at(-1)?.id ?? lastAgentTabId(agentTabs));
    if (!replacement && !remaining.length && !fileTabs.length && !agentTabs.length) {
      if (isRuoyiIntegration) setRightPanelExpanded(false);
      else setRightPanelOpen(false);
    }
  };

  const handleCloseFileTab = useCallback((tabId: string) => {
    if (terminalTabs.some((tab) => tab.id === tabId)) {
      setTerminalTabs((tabs) => tabs.map((tab) => tab.id === tabId && !tab.closing ? { ...tab, closing: "close" } : tab));
      return;
    }
    if (tabId.startsWith("agent:")) {
      const remainingAgents = agentTabs.filter((tab) => `agent:${tab.sessionId}` !== tabId);
      setAgentTabs(remainingAgents);
      setActiveFileTabId((cur) => {
        if (cur !== tabId) return cur;
        return fileTabs.at(-1)?.id ?? terminalTabs.at(-1)?.id ?? lastAgentTabId(remainingAgents);
      });
      if (fileTabs.length === 0 && terminalTabs.length === 0 && remainingAgents.length === 0) {
        if (isRuoyiIntegration) setRightPanelExpanded(false);
        else setRightPanelOpen(false);
      }
      return;
    }
    setFileTabs((prev) => {
      const next = prev.filter((t) => t.id !== tabId);
      if (next.length === 0 && terminalTabs.length === 0 && agentTabs.length === 0) {
        if (isRuoyiIntegration) setRightPanelExpanded(false);
        else setRightPanelOpen(false);
      }
      return next;
    });
    setActiveFileTabId((cur) => {
      if (cur !== tabId) return cur;
      const remaining = fileTabs.filter((t) => t.id !== tabId);
      return remaining.at(-1)?.id ?? terminalTabs.at(-1)?.id ?? lastAgentTabId(agentTabs);
    });
  }, [fileTabs, terminalTabs, agentTabs, isRuoyiIntegration]);

  // The Agents switcher's Delete on a side chat: its tab goes with it, and the
  // main chat showing it goes back to the parent, as the Main agent row does
  // (`handleSessionDeleted` would leave the family for a fresh composer).
  const handleDeleteSideChat = useCallback(async (sessionId: string, root: SessionInfo): Promise<string | null> => {
    const result = await deleteSideChat(sessionId);
    if (result) return result.error;
    handleCloseFileTab(`agent:${sessionId}`);
    if (selectedSessionRef.current?.id === sessionId) {
      handleSelectSession(root);
      setRefreshKey((key) => key + 1);
    } else {
      handleSessionDeleted(sessionId);
    }
    return null;
  }, [handleCloseFileTab, handleSelectSession, handleSessionDeleted]);

  // One session, one chat: opening a subagent or side chat in the main chat closes its tab.
  const selectedSessionId = selectedSession?.id;
  useEffect(() => {
    if (agentTabs.some((tab) => tab.sessionId === selectedSessionId)) handleCloseFileTab(`agent:${selectedSessionId}`);
  }, [agentTabs, handleCloseFileTab, selectedSessionId]);

  const handleViewFullHistory = useCallback(() => {
    if (!selectedSession) return;
    window.open(
      `/api/sessions/${encodeURIComponent(selectedSession.id)}/export?inline=1`,
      "_blank",
      "noopener,noreferrer",
    );
  }, [selectedSession]);

  // Show chat area if a session is selected, or if we have a cwd to start a new session in
  const effectiveNewSessionCwd = newSessionCwd ?? (selectedSession === null && activeCwd ? activeCwd : null);
  const newSessionDraftKey = selectedSession === null && effectiveNewSessionCwd
    ? `new:${newSessionDraftId}:${effectiveNewSessionCwd}`
    : null;
  useLayoutEffect(() => {
    activeNewSessionDraftKeyRef.current = newSessionDraftKey;
  }, [newSessionDraftKey]);

  // The bar above a fresh composer. Only a fresh composer moves, and only
  // somewhere else: the folder in use would remount it for nothing. The
  // control the move came from takes focus in the bar of the new composer.
  const handlePickNewSessionContext = useCallback((target: NewSessionTarget, from: NewSessionContextControl) => {
    if (selectedSession !== null || !effectiveNewSessionCwd || target.cwd === effectiveNewSessionCwd) return;
    newSessionBarFocusRef.current = from;
    // A worktree just created already left its move, with the branch.
    if (target.projectKey && target.projectRoot && newSessionMoveRef.current?.cwd !== target.cwd) {
      newSessionMoveRef.current = { cwd: target.cwd, project: { key: target.projectKey, root: target.projectRoot }, branch: null };
    }
    sidebarControlRef.current?.startNewSessionIn({ ...target, carryComposer: true });
  }, [effectiveNewSessionCwd, selectedSession]);
  // The folder picker answers later: its pick runs the newest closure, guard included.
  const pickNewSessionContextRef = useRef(handlePickNewSessionContext);
  pickNewSessionContextRef.current = handlePickNewSessionContext;
  const handleOpenFolderForNewSession = useCallback((opener: HTMLElement | null) => {
    sidebarControlRef.current?.openFolderForNewSession((target) => pickNewSessionContextRef.current(target, "project"), opener);
  }, []);
  const handleDefaultDirectoryForNewSession = useCallback(() => {
    sidebarControlRef.current?.openDefaultDirectoryForNewSession((target) => pickNewSessionContextRef.current(target, "project"));
  }, []);
  const handleRefreshNewSessionWorktrees = useCallback(() => {
    sidebarControlRef.current?.refreshWorktrees();
  }, []);
  const handleCreateNewSessionWorktree = useCallback(async (project: ProjectChoice, branch: string) => {
    const control = sidebarControlRef.current;
    if (!control) throw new Error("The session sidebar is not mounted");
    const result = await control.createWorktree(project, branch);
    // The bar moves there next, before any report lists it.
    if ("path" in result) newSessionMoveRef.current = { cwd: result.path, project, branch };
    return result;
  }, []);
  const handleNewSessionBarFocusDone = useCallback(() => {
    newSessionBarFocusRef.current = null;
  }, []);
  const newSessionContextBar = !isRuoyiIntegration && selectedSession === null && effectiveNewSessionCwd ? (
    <NewSessionContextBar
      context={contextForCwd(sidebarNewSessionContext, effectiveNewSessionCwd, newSessionMoveRef.current)}
      mobile={isMobile}
      initialFocus={newSessionBarFocusRef.current}
      onInitialFocusDone={handleNewSessionBarFocusDone}
      onPick={handlePickNewSessionContext}
      onUseDefaultDirectory={handleDefaultDirectoryForNewSession}
      onOpenFolder={handleOpenFolderForNewSession}
      onRefreshWorktrees={handleRefreshNewSessionWorktrees}
      onCreateWorktree={handleCreateNewSessionWorktree}
    />
  ) : null;
  const showChat = selectedSession !== null || effectiveNewSessionCwd !== null;
  const handleExternalPromptReady = useCallback(() => {
    if (ruoyiAuthenticatedRef.current) postRuoyiParentMessage({ type: "qimiao-agent-ready" });
  }, [postRuoyiParentMessage]);
  const projectTrustCwd = selectedSession?.cwd ?? effectiveNewSessionCwd;
  // While restoring initial session from URL, don't show the placeholder
  const showPlaceholder = initialSessionRestored && !showChat;

  // The Debug button shows with a chat only: without one, its panel would have nothing to close it.
  useEffect(() => {
    if (!showChat) setActiveTopPanel((panel) => panel === "debug" ? null : panel);
  }, [showChat]);

  useEffect(() => {
    setProjectTrust(null);
    setProjectTrustDialogOpen(false);
    setProjectTrustError(null);
    // RuoYi 会话禁止读取或信任项目配置，避免项目级 MCP/扩展进入受控会话。
    if (isRuoyiIntegration || !projectTrustCwd) return;

    const controller = new AbortController();
    // The answer also lists the project's MCP servers (`mcpFile`, `mcpServers`), unused here: the
    // trust dialog fetches the listing again when it opens, since the file can change in between.
    fetch(`/api/project-trust?cwd=${encodeURIComponent(projectTrustCwd)}`, {
      signal: controller.signal,
    })
      .then(async (response) => {
        const data = await response.json() as ProjectTrustStatus & { error?: string };
        if (!response.ok || data.error) throw new Error(data.error ?? `HTTP ${response.status}`);
        setProjectTrust(data);
      })
      .catch((error) => {
        if (error instanceof DOMException && error.name === "AbortError") return;
        console.error("Failed to load project trust:", error);
      });
    return () => controller.abort();
  }, [isRuoyiIntegration, projectTrustCwd]);

  const handleTrustProject = useCallback(async () => {
    if (isRuoyiIntegration || !projectTrustCwd || projectTrustBusy) return;
    setProjectTrustBusy(true);
    setProjectTrustError(null);
    try {
      const response = await fetch("/api/project-trust", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cwd: projectTrustCwd }),
      });
      const data = await response.json() as ProjectTrustStatus & Partial<McpErrorResponse>;
      if (!response.ok || data.error) {
        // The dialog translates the reason; the English error is only its diagnostic.
        setProjectTrustError({ error: data.error ?? `HTTP ${response.status}`, ...(data.reason ? { reason: data.reason } : {}) });
        return;
      }
      setProjectTrust(data);
      setProjectTrustDialogOpen(false);
      setModelsRefreshKey((key) => key + 1);
      setSessionKey((key) => key + 1);
    } catch (error) {
      setProjectTrustError({ error: error instanceof Error ? error.message : String(error) });
    } finally {
      setProjectTrustBusy(false);
    }
  }, [isRuoyiIntegration, projectTrustBusy, projectTrustCwd]);

  // The restricted-mode banner and Settings › MCP's trust notice open the same dialog.
  const openProjectTrustDialog = useCallback(() => {
    setProjectTrustError(null);
    setProjectTrustDialogOpen(true);
  }, []);

  // Settings › MCP added a project server: `.pi/mcp.json` alone makes a folder require trust, and a
  // fresh folder was trusted in the same step. Every mounted section reloads in place on the new
  // status (projectTrustReloadKey); nothing was rebuilt, so the chat needs no new session key.
  const handleProjectTrustChanged = useCallback((cwd: string, status: ProjectTrustStatus) => {
    if (cwd === projectTrustCwd) setProjectTrust(status);
  }, [projectTrustCwd]);

  const activeFileTab = fileTabs.find((tab) => tab.id === activeFileTabId) ?? null;
  // Subagent work tabs: like files, only the active one is mounted.
  const activeAgentTab = agentTabs.find((tab) => `agent:${tab.sessionId}` === activeFileTabId) ?? null;
  const rightExplorerCwd = selectedSession?.cwd ?? newSessionCwd ?? activeCwd;
  const activePanelHasContent = Boolean(
    activeFileTab?.filePath
    || terminalTabs.some((tab) => tab.id === activeFileTabId)
    || activeAgentTab,
  );
  useEffect(() => {
    setRightFileSearchOpen(false);
  }, [rightExplorerCwd]);
  const renderRuoyiFileActions = () => (
    <div className="ruoyi-file-actions" role="group" aria-label={translate("sidebar.fileActions")}>
      {terminalAccess.allowed && (
        <button
          type="button"
          onClick={() => { if (rightExplorerCwd) handleOpenTerminal(rightExplorerCwd); }}
          disabled={!rightExplorerCwd}
          title={translate("terminal.open")}
          aria-label={translate("terminal.open")}
        >
          <TerminalIcon size={15} />
        </button>
      )}
      <button
        type="button"
        onClick={() => rightFileExplorerRef.current?.openUploadPicker()}
        disabled={!rightExplorerCwd || rightExplorerUploadBusy}
        title={translate("sidebar.uploadFilesTitle")}
        aria-label={translate("sidebar.uploadFilesTitle")}
      >
        <UploadIcon size={15} />
      </button>
      <button
        type="button"
        onClick={handleExplorerRefresh}
        disabled={!rightExplorerCwd}
        title={translate("sidebar.refreshExplorer")}
        aria-label={translate("sidebar.refreshExplorer")}
      >
        <RefreshIcon size={15} />
      </button>
      <button
        type="button"
        onClick={() => setRightExplorerShowIgnoredFiles((shown) => !shown)}
        disabled={!rightExplorerCwd}
        title={translate("sidebar.showIgnoredFiles")}
        aria-label={translate("sidebar.showIgnoredFiles")}
        aria-pressed={rightExplorerShowIgnoredFiles}
      >
        <EyeIcon size={15} />
      </button>
      <button
        type="button"
        onClick={() => setRightExplorerChangesCollapsed((collapsed) => !collapsed)}
        disabled={!rightExplorerCwd || rightExplorerChangesCount === 0}
        title={translate("sidebar.changedFiles", { count: rightExplorerChangesCount })}
        aria-label={translate("sidebar.changedFiles", { count: rightExplorerChangesCount })}
        aria-pressed={rightExplorerChangesCount > 0 && !rightExplorerChangesCollapsed}
      >
        <ChangesIcon size={15} />
      </button>
      <button
        type="button"
        onClick={() => setRightFileSearchOpen((open) => !open)}
        disabled={!rightExplorerCwd}
        title={translate("sidebar.searchFiles")}
        aria-label={translate("sidebar.searchFiles")}
        aria-expanded={rightFileSearchOpen}
        aria-controls="file-search-input"
      >
        <SearchIcon size={15} />
      </button>
    </div>
  );
  const panelTabContent = (
    <>
      {activeFileTab?.filePath ? (
        <FileViewer
          key={`${fileWorkspaceGeneration}:${activeFileTab.id}:${activeFileTab.viewerRevision ?? 0}`}
          filePath={activeFileTab.filePath}
          cwd={activeCwd ?? undefined}
          sourceSessionId={activeFileTab.sourceSessionId}
          gitRefreshKey={explorerRefreshKey}
          initialDisplayMode={activeFileTab.initialDisplayMode}
          initialPage={activeFileTab.page}
          initialState={activeFileTab.viewerState}
          watchEnabled={rightPanelOpen}
          onStateChange={(viewerState) => handleFileViewerStateChange(
            fileWorkspaceGeneration,
            activeFileTab.id,
            activeFileTab.viewerRevision ?? 0,
            viewerState,
          )}
          onMentionLines={rightPanelOpen ? handleFileLineMention : undefined}
          onAtMention={handleAtMention}
          onOpenFile={(filePath, page) => handleOpenFile(
            filePath,
            getFileName(filePath),
            { sourceSessionId: activeFileTab.sourceSessionId, page },
          )}
        />
      ) : !terminalTabs.some((tab) => tab.id === activeFileTabId) && !activeAgentTab ? (
        <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-dim)", fontSize: 12 }}>
          {translate("files.noneOpen")}
        </div>
      ) : null}
      {terminalTabs.map((tab) => (
        <div key={tab.id} hidden={tab.id !== activeFileTabId} style={{ width: "100%", height: "100%" }}>
          <TerminalPanel
            tab={tab}
            active={rightPanelOpen && tab.id === activeFileTabId}
            onRestart={() => setTerminalTabs((tabs) => tabs.map((item) => item.id === tab.id ? { ...item, closing: "restart" } : item))}
            onClosed={() => handleTerminalClosed(tab)}
            onCloseError={() => setTerminalTabs((tabs) => tabs.map((item) => item.id === tab.id ? { ...item, closing: undefined } : item))}
          />
        </div>
      ))}
      {activeAgentTab && (
        <SessionChatPanel
          key={activeAgentTab.sessionId}
          sessionId={activeAgentTab.sessionId}
          running={runningSessionIds.has(activeAgentTab.sessionId)}
          initialPrompt={sideChatPrompts[activeAgentTab.sessionId]}
          onInitialPromptConsumed={() => setSideChatPrompts((prev) => {
            if (!(activeAgentTab.sessionId in prev)) return prev;
            const next = { ...prev };
            delete next[activeAgentTab.sessionId];
            return next;
          })}
          modelsRefreshKey={modelsRefreshKey}
          quoteSelectionEnabled={quoteSelectionEnabled}
          onOpenFile={handleOpenLinkedFile}
          onOpenSubagent={handleOpenSubagentTab}
          onSessionForked={(newSessionId) => {
            if (isMobile) setRightPanelOpen(false);
            handleSessionForked(newSessionId);
          }}
          onOpenSettings={openSettingsSection}
          onToolEnd={handleToolEnd}
          onFilesUploaded={handleExplorerRefresh}
          soundEnabled={soundEnabled}
          onSoundToggle={onSoundToggle}
          playDoneSound={playDoneSound}
          unlockAudio={unlockAudio}
          holdAudio={holdAudio}
        />
      )}
    </>
  );
  const activeCwdName = activeCwd ? getFileName(activeCwd) || activeCwd : null;
  const selectedSessionTitle = selectedSession?.name?.trim() || selectedSession?.firstMessage.trim();
  const windowTitle = isRuoyiIntegration
    ? (selectedSessionTitle && selectedSessionTitle !== "(no messages)"
      ? `${selectedSessionTitle.slice(0, 60)} · Web Agent`
      : "Web Agent")
    : (activeCwdName ? `${activeCwdName} - Pi Web` : "Pi Web");

  useEffect(() => {
    const syncWindowTitle = () => {
      if (document.title !== windowTitle) document.title = windowTitle;
    };

    syncWindowTitle();
    const observer = new MutationObserver(syncWindowTitle);
    observer.observe(document.head, { childList: true, subtree: true, characterData: true });
    return () => observer.disconnect();
  }, [windowTitle]);

  const sidebarContent = (
    <>
      <SessionSidebar
        selectedSessionId={selectedSession?.id ?? null}
        onSelectSession={handleSelectSession}
        onNewSession={handleNewSession}
        controlRef={sidebarControlRef}
        onNewSessionContextChange={handleSidebarNewSessionContext}
        hideWorkspacePicker={isRuoyiIntegration}
        sidebarOpen={sidebarOpen}
        onToggleSidebar={handleSidebarToggle}
        filesInRightPanel={isRuoyiIntegration}
        initialSessionId={initialSessionId}
        initialSessionLinked={initialLinkedSessionId !== null}
        skipInitialProjectSelection={initialNavigation.requestedCwd !== null}
        onInitialRestoreDone={handleInitialRestoreDone}
        refreshKey={refreshKey}
        onSessionDeleted={handleSessionDeleted}
        selectedCwd={selectedSession?.cwd ?? newSessionCwd ?? null}
        onCwdChange={handleCwdChange}
        onOpenFile={handleOpenFile}
        onOpenTerminal={terminalAccess.allowed ? handleOpenTerminal : undefined}
        explorerRefreshKey={explorerRefreshKey}
        onExplorerRefresh={handleExplorerRefresh}
        onAtMention={handleAtMention}
        onAtMentions={handleAtMentions}
        onBackgroundTaskDone={handleBackgroundTaskDone}
        hiddenFinishedSessionIds={hiddenFinishedSessionIds}
        onRunningSessionIdsChange={handleRunningSessionIdsChange}
        onSessionsChange={handleSessionsChange}
      />
      <div style={{ padding: "8px", flexShrink: 0, display: "flex", justifyContent: "space-between", gap: 4 }}>
        {([
          ["models", translate("common.models")],
          ["skills", translate("common.skills")],
        ] as const).filter(([section]) => allowedSettingsSections.includes(section)).map(([section, label]) => {
          const disabled = settingsSectionRequiresProject(section) && !projectTrustCwd;
          return (
            <button
              key={section}
              type="button"
              onClick={() => openSettingsSection(section)}
              disabled={disabled}
              title={disabled ? translate("settings.projectRequired") : label}
              aria-label={label}
              style={{
                flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                height: 32, padding: 0, background: "none", border: "none",
                borderRadius: 9, color: "var(--text-muted)", cursor: disabled ? "default" : "pointer",
                fontSize: 12, opacity: disabled ? 0.35 : 1,
                transition: "background 0.12s, color 0.12s",
              }}
              onMouseEnter={(event) => { if (!disabled) { event.currentTarget.style.background = "var(--bg-hover)"; event.currentTarget.style.color = "var(--text)"; } }}
              onMouseLeave={(event) => { event.currentTarget.style.background = "none"; event.currentTarget.style.color = "var(--text-muted)"; }}
            >
              <SettingsSectionIcon section={section} size={14} strokeWidth={2} />
              <span>{label}</span>
            </button>
          );
        })}
        {allowedSettingsSections.length > 0 && <button
          type="button"
          onClick={() => {
            setSettingsOpenAtHome(true);
            const lastSection = getLastSettingsSection(projectTrustCwd);
            setSettingsSection(allowedSettingsSections.includes(lastSection) ? lastSection : allowedSettingsSections[0]);
          }}
          title={translate("common.settings")}
          aria-label={translate("common.settings")}
          style={{
            flex: 1, display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
            height: 32, padding: 0, background: "none", border: "none",
            borderRadius: 9, color: "var(--text-muted)", cursor: "pointer",
            fontSize: 12, transition: "background 0.12s, color 0.12s",
          }}
          onMouseEnter={(event) => { event.currentTarget.style.background = "var(--bg-hover)"; event.currentTarget.style.color = "var(--text)"; }}
          onMouseLeave={(event) => { event.currentTarget.style.background = "none"; event.currentTarget.style.color = "var(--text-muted)"; }}
        >
          <SettingsSectionIcon section="general" size={14} strokeWidth={2} />
          <span>{translate("common.settings")}</span>
        </button>}
      </div>
    </>
  );

  const renderProjectTrustWarning = (mobileBanner: boolean) => {
    if (isRuoyiIntegration || !showChat || !projectTrust?.requiresTrust || projectTrust.trusted) return null;
    return (
      <button
        type="button"
        onClick={openProjectTrustDialog}
        title={translate("trust.resourcesNotLoaded")}
        aria-label={translate("trust.resourcesNotLoaded")}
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: mobileBanner ? "flex-start" : "center",
          gap: 6,
          width: mobileBanner ? "100%" : undefined,
          minHeight: mobileBanner ? 32 : undefined,
          height: mobileBanner ? undefined : "100%",
          padding: mobileBanner ? "6px 12px" : "0 12px",
          background: mobileBanner ? "color-mix(in srgb, #d97706 8%, var(--bg-panel))" : "none",
          border: "none",
          borderRight: mobileBanner ? "none" : "1px solid var(--border)",
          borderBottom: mobileBanner ? "1px solid var(--border)" : "none",
          color: "#d97706",
          cursor: "pointer",
          flexShrink: 0,
          fontSize: 11,
          lineHeight: 1.35,
          textAlign: "left",
        }}
        data-mobile-trust-banner={mobileBanner ? "true" : undefined}
      >
        <svg
          width="13"
          height="13"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
          style={{ flexShrink: 0 }}
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z" />
          <path d="M12 8v4" />
          <path d="M12 16h.01" />
        </svg>
        <span>{translate("trust.resourcesNotLoaded")}</span>
      </button>
    );
  };

  // While subagents run: their count, ringed by a spinner; otherwise all of them.
  const renderAgentsBadge = (badge: { count: number; running: boolean }, mobile: boolean) => (
    <span
      aria-hidden="true"
      style={{
        position: "relative",
        minWidth: 15, height: 15, padding: "0 4px", display: "grid", placeItems: "center",
        borderRadius: 7,
        background: badge.running ? "color-mix(in srgb, var(--accent) 22%, var(--bg-panel))" : "var(--bg-selected)",
        color: "var(--accent)",
        fontSize: 10, lineHeight: 1, fontVariantNumeric: "tabular-nums",
        fontWeight: badge.running ? 600 : undefined,
        ...(mobile ? { position: "absolute", top: 3, right: 3, minWidth: 13, height: 13, padding: "0 3px", fontSize: 9 } : {}),
      }}
    >
      {badge.running && (
        <svg
          className="animate-spin motion-reduce:animate-none"
          viewBox="0 0 24 24" fill="none" aria-hidden="true"
          style={{ position: "absolute", top: -3, left: -3, width: "calc(100% + 6px)", height: "calc(100% + 6px)", pointerEvents: "none" }}
        >
          <circle cx="12" cy="12" r="11" stroke="currentColor" strokeWidth="2" opacity="0.2" />
          <path d="M23 12a11 11 0 0 0-11-11" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        </svg>
      )}
      {badge.count}
    </span>
  );

  // The Agents switcher's button. A narrow phone shows it left of the More button instead of
  // folding it into that menu: the bar has the room, and the badge stays in sight.
  const renderAgentsButton = (mobile: boolean) => (
    <button
      type="button"
      // On a narrow phone it sits outside the More menu, so it leaves that menu as it is.
      onClick={() => toggleTopPanel("agents", mobile && !isNarrowMobile)}
      disabled={!activeSessionFamily}
      title={agentsButtonLabel}
      aria-label={agentsButtonLabel}
      aria-pressed={activeTopPanel === "agents"}
      style={{
        position: "relative",
        display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
        width: mobile ? TOP_BAR_ICON_BUTTON_SIZE : undefined,
        height: "100%", padding: mobile ? 0 : "0 12px",
        background: activeTopPanel === "agents" ? "var(--bg-selected)" : "none",
        border: "none",
        borderTop: activeTopPanel === "agents" ? "2px solid var(--accent)" : "2px solid transparent",
        borderRight: "1px solid var(--border)",
        color: activeTopPanel === "agents" ? "var(--text)" : activeSessionFamily ? "var(--text-muted)" : "var(--text-dim)",
        cursor: activeSessionFamily ? "pointer" : "not-allowed", opacity: activeSessionFamily ? 1 : 0.45,
        flexShrink: 0, fontSize: 11, whiteSpace: "nowrap",
        transition: "color 0.1s, background 0.1s",
      }}
      data-mobile-toolbar-action={mobile ? "agents" : undefined}
    >
      <svg width={mobile ? 16 : 13} height={mobile ? 16 : 13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
        <rect x="5" y="7" width="14" height="11" rx="2" /><path d="M9 11h.01M15 11h.01M9 15h6M12 7V4M10 4h4" />
      </svg>
      {!mobile && <span>{translate("agentSwitcher.title")}</span>}
      {agentsBadge && agentsBadge.count > 0 && renderAgentsBadge(agentsBadge, mobile)}
    </button>
  );

  const renderChatToolbarActions = (mobile: boolean) => {
    if (!mobile && !showChat) return null;
    return (
      <div style={{ display: "flex", alignItems: "stretch", height: "100%" }}>
        {(() => {
          // 上下文压缩后当前消息可能不再包含 user 消息，需同时参考会话文件的消息总数。
          const hasMessages = Boolean(
            selectedSession
            && ((sessionStats?.userMessages ?? 0) > 0 || selectedSession.messageCount > 0),
          );
          const disabled = !selectedSession || selectedSession.transient || !hasMessages || autoNameStatus.kind === "naming";
          const isSuccess = autoNameStatus.kind === "success";
          const isError = autoNameStatus.kind === "error";
          const label = autoNameStatus.kind === "naming"
            ? translate("title.generating")
            : isSuccess
              ? translate("title.updated")
              : isError
                ? translate("title.failed")
                : translate("title.generate");
          const title = !selectedSession || selectedSession.transient
            ? translate("title.unsaved")
            : !hasMessages
              ? translate("title.noMessages")
              : isError
                ? autoNameStatus.message
                : translate("title.generateSession");

          return (
            <button
              type="button"
              onClick={() => {
                void handleAutoName();
                if (mobile && isNarrowMobile) setMobileToolbarMoreOpen(true);
              }}
              disabled={disabled}
              title={title}
              aria-label={label}
              style={{
                display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                width: mobile ? TOP_BAR_ICON_BUTTON_SIZE : undefined,
                height: "100%", padding: mobile ? 0 : "0 12px",
                background: "none", border: "none",
                borderTop: "2px solid transparent",
                borderRight: "1px solid var(--border)",
                color: isError ? "#dc2626" : isSuccess ? "var(--accent)" : disabled ? "var(--text-dim)" : "var(--text-muted)",
                cursor: disabled ? "not-allowed" : "pointer",
                opacity: disabled && autoNameStatus.kind !== "naming" ? 0.45 : 1,
                flexShrink: 0, fontSize: 11, whiteSpace: "nowrap",
                transition: "color 0.1s, background 0.1s, opacity 0.1s",
              }}
              onMouseEnter={(event) => {
                if (disabled) return;
                event.currentTarget.style.color = isError ? "#dc2626" : "var(--text)";
                event.currentTarget.style.background = "var(--bg-hover)";
              }}
              onMouseLeave={(event) => {
                event.currentTarget.style.color = isError ? "#dc2626" : isSuccess ? "var(--accent)" : disabled ? "var(--text-dim)" : "var(--text-muted)";
                event.currentTarget.style.background = "none";
              }}
              data-mobile-toolbar-action={mobile ? "name" : undefined}
            >
              {autoNameStatus.kind === "naming" ? (
                <svg className="animate-spin" width={mobile ? 16 : 13} height={mobile ? 16 : 13} viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" opacity="0.25" />
                  <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              ) : isSuccess ? (
                <svg width={mobile ? 16 : 13} height={mobile ? 16 : 13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <polyline points="20 6 9 17 4 12" />
                </svg>
              ) : (
                <svg width={mobile ? 16 : 13} height={mobile ? 16 : 13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="m15 4 5 5L7 22l-5-5Z" />
                  <path d="m14 5 5 5" />
                  <path d="M6 4V2M5 3H3M19 19v3M17.5 20.5h3" />
                </svg>
              )}
              {!mobile && <span>{label}</span>}
            </button>
          );
        })()}
        {!(mobile && isNarrowMobile) && renderAgentsButton(mobile)}
        {sessionHasBranches && (mobile ? (
          <button
            type="button"
            onClick={() => toggleTopPanel("branches", true)}
            title={translate("i18n.branches")}
            aria-label={translate("i18n.branches")}
            aria-pressed={activeTopPanel === "branches"}
            style={{
              display: "flex", alignItems: "center", justifyContent: "center",
              width: TOP_BAR_ICON_BUTTON_SIZE, height: "100%", padding: 0,
              background: activeTopPanel === "branches" ? activeToolbarBackground : "none",
              border: "none",
              borderTop: activeTopPanel === "branches" ? "2px solid var(--accent)" : "2px solid transparent",
              borderRight: "1px solid var(--border)",
              color: activeTopPanel === "branches" ? activeToolbarColor : "var(--text-muted)",
              cursor: "pointer", flexShrink: 0,
            }}
            data-mobile-toolbar-action="branches"
          >
            <svg width={mobile ? 16 : 12} height={mobile ? 16 : 12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: branchTree.length > 0 ? "var(--accent)" : "var(--text-dim)" }} aria-hidden="true">
              <line x1="6" y1="3" x2="6" y2="15" />
              <circle cx="18" cy="6" r="3" />
              <circle cx="6" cy="18" r="3" />
              <path d="M18 9a9 9 0 0 1-9 9" />
            </svg>
          </button>
        ) : (
          <BranchNavigator
            tree={branchTree}
            activeLeafId={branchActiveLeafId}
            onLeafChange={handleBranchLeafChange}
            locked={branchSwitchLocked}
            inline
            containerRef={topBarRef}
            open={activeTopPanel === "branches"}
            onToggle={() => toggleTopPanel("branches")}
            hasSession
          />
        ))}
        <button
          type="button"
          onClick={() => handleSystemInfoToggle("tools", mobile)}
          disabled={mobile && !showChat}
          title={translate("tools.title")}
          aria-label={translate("tools.title")}
          aria-pressed={activeTopPanel === "tools"}
          style={{
            display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
            width: mobile ? TOP_BAR_ICON_BUTTON_SIZE : undefined,
            height: "100%", padding: mobile ? 0 : "0 12px",
            background: activeTopPanel === "tools" ? activeToolbarBackground : "none",
            border: "none",
            borderTop: activeTopPanel === "tools" ? "2px solid var(--accent)" : "2px solid transparent",
            borderRight: "1px solid var(--border)",
            cursor: mobile && !showChat ? "not-allowed" : "pointer",
            color: activeTopPanel === "tools" ? activeToolbarColor : "var(--text-muted)",
            opacity: mobile && !showChat ? 0.45 : 1,
            fontSize: 11, whiteSpace: "nowrap", transition: "color 0.1s, background 0.1s",
          }}
          onMouseEnter={(event) => {
            if (mobile && !showChat) return;
            event.currentTarget.style.color = "var(--text)";
          }}
          onMouseLeave={(event) => {
            event.currentTarget.style.color = activeTopPanel === "tools" ? "var(--text)" : "var(--text-muted)";
          }}
          data-mobile-toolbar-action={mobile ? "tools" : undefined}
        >
          <svg width={mobile ? 16 : 12} height={mobile ? 16 : 12} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: systemTools?.some((tool) => tool.active) ? "var(--accent)" : "var(--text-dim)", flexShrink: 0 }} aria-hidden="true">
            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.8-3.8a6 6 0 0 1-7.9 7.9l-6.9 6.9a2.1 2.1 0 0 1-3-3l6.9-6.9a6 6 0 0 1 7.9-7.9z" />
          </svg>
          {!mobile && <span>{translate("tools.label")}</span>}
        </button>
      </div>
    );
  };

  const renderSessionStatsButton = (mobile: boolean, placement: "top" | "composer" = "top") => {
    if (!mobile && (!showChat || (!sessionStats && !contextUsage))) return null;

    const inComposer = placement === "composer";

    const tokens = sessionStats?.tokens;
    const cost = sessionStats?.cost ?? 0;
    const formatCompact = formatCompactCount;
    const costText = formatCostShort(cost);

    let contextColor = "var(--text-muted)";
    let desktopContextText: string | null = null;
    let mobileContextText: string | null = null;
    if (contextUsage?.contextWindow) {
      const percent = contextUsage.percent;
      if (percent !== null && percent > 90) contextColor = "#ef4444";
      else if (percent !== null && percent > 70) contextColor = "rgba(234,179,8,0.95)";
      desktopContextText = percent !== null
        ? `${percent.toFixed(0)}% / ${formatCompact(contextUsage.contextWindow)}`
        : `? / ${formatCompact(contextUsage.contextWindow)}`;
      mobileContextText = percent !== null ? `${percent.toFixed(0)}%` : null;
    }

    const tooltipParts: string[] = [];
    if (tokens) {
      tooltipParts.push(`${translate("session.input")}: ${tokens.input.toLocaleString(locale)}`);
      tooltipParts.push(`${translate("session.output")}: ${tokens.output.toLocaleString(locale)}`);
      tooltipParts.push(`${translate("session.cacheRead")}: ${tokens.cacheRead.toLocaleString(locale)}`);
      tooltipParts.push(`${translate("session.cacheWrite")}: ${tokens.cacheWrite.toLocaleString(locale)}`);
      if (cost > 0) tooltipParts.push(`${translate("session.cost")}: $${cost.toFixed(4)}`);
    }
    if (contextUsage?.contextWindow) {
      const percent = contextUsage.percent;
      tooltipParts.push(`${translate("session.context")}: ${percent !== null ? `${percent.toFixed(1)}%` : "?"} / ${contextUsage.contextWindow.toLocaleString(locale)}`);
    }
    const tooltip = tooltipParts.join("  |  ");
    const covered = mobile && isNarrowMobile && mobileToolbarMoreOpen;
    const hasMobileValues = Boolean(
      (tokens && (tokens.input > 0 || tokens.output > 0))
      || costText
      || mobileContextText,
    );

    return (
      <button
        type="button"
        onClick={() => toggleTopPanel("session")}
        disabled={!showChat || covered}
        tabIndex={covered ? -1 : undefined}
        title={tooltip || translate("session.title")}
        aria-label={translate("session.title")}
        aria-pressed={activeTopPanel === "session"}
        aria-hidden={covered ? true : undefined}
        className={mobile ? "mobile-session-stats" : undefined}
        data-mobile-toolbar-stats={mobile ? "true" : undefined}
        style={{
          marginLeft: mobile ? 0 : inComposer ? 0 : "auto",
          display: "flex", alignItems: "center", justifyContent: "flex-end",
          flex: mobile ? 1 : undefined,
          minWidth: 0,
          gap: mobile ? 7 : inComposer ? 8 : 10,
          paddingLeft: mobile ? 6 : inComposer ? 4 : 12,
          paddingRight: mobile ? 6 : inComposer ? 4 : 12,
          height: inComposer ? 32 : "100%",
          overflow: "hidden",
          visibility: covered ? "hidden" : "visible",
          pointerEvents: covered ? "none" : "auto",
          background: activeTopPanel === "session" ? activeToolbarBackground : "none",
          border: "none",
          borderTop: inComposer ? "none" : activeTopPanel === "session" ? "2px solid var(--accent)" : "2px solid transparent",
          borderRadius: inComposer ? 6 : 0,
          fontSize: 11, color: "var(--text-muted)",
          whiteSpace: "nowrap", cursor: showChat ? "pointer" : "default",
          fontVariantNumeric: "tabular-nums",
          transition: "color 0.1s, background 0.1s",
        }}
        onMouseEnter={(event) => {
          if (showChat && !covered) event.currentTarget.style.color = "var(--text)";
        }}
        onMouseLeave={(event) => {
          event.currentTarget.style.color = activeTopPanel === "session" ? "var(--text)" : "var(--text-muted)";
        }}
      >
        {mobile ? (
          <>
            {tokens && tokens.input > 0 && (
              <span className="mobile-session-stat-io" style={{ display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <line x1="5" y1="8.5" x2="5" y2="1.5" /><polyline points="2 4 5 1.5 8 4" />
                </svg>
                {formatCompact(tokens.input)}
              </span>
            )}
            {tokens && tokens.output > 0 && (
              <span className="mobile-session-stat-io" style={{ display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
                <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <line x1="5" y1="1.5" x2="5" y2="8.5" /><polyline points="2 6 5 8.5 8 6" />
                </svg>
                {formatCompact(tokens.output)}
              </span>
            )}
            {costText && (
              <span className="mobile-session-stat-cost" style={{ color: "var(--text)", fontWeight: 500, flexShrink: 0 }}>
                {costText}
              </span>
            )}
            {mobileContextText && (
              <span style={{ color: contextColor, flexShrink: 0 }}>
                {mobileContextText}
              </span>
            )}
            {!hasMobileValues && showChat && (
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", color: "var(--text-dim)" }}>
                {translate("session.title")}
              </span>
            )}
          </>
        ) : (
          <>
            {tokens && tokens.input > 0 && (
              <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <svg width="12" height="12" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <line x1="5" y1="8.5" x2="5" y2="1.5" /><polyline points="2 4 5 1.5 8 4" />
                </svg>
                {formatCompact(tokens.input)}
              </span>
            )}
            {tokens && tokens.output > 0 && (
              <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <svg width="12" height="12" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <line x1="5" y1="1.5" x2="5" y2="8.5" /><polyline points="2 6 5 8.5 8 6" />
                </svg>
                {formatCompact(tokens.output)}
              </span>
            )}
            {tokens && tokens.cacheRead > 0 && (
              <span style={{ display: "flex", alignItems: "center", gap: 4 }}>
                <svg width="12" height="12" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M8.5 5a3.5 3.5 0 1 1-1-2.45" /><polyline points="6.5 1.5 8.5 2.5 7.5 4.5" />
                </svg>
                {formatCompact(tokens.cacheRead)}
              </span>
            )}
            {costText && (
              <span style={{ display: "flex", alignItems: "center", color: "var(--text)", fontWeight: 500 }}>
                {costText}
              </span>
            )}
            {desktopContextText && (
              <span style={{ display: "flex", alignItems: "center", gap: 4, color: contextColor }}>
                <svg width="12" height="12" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d="M1 9 L1 5 Q1 1 5 1 Q9 1 9 5 L9 9" /><line x1="1" y1="9" x2="9" y2="9" />
                </svg>
                {desktopContextText}
              </span>
            )}
          </>
        )}
      </button>
    );
  };

  // 调试入口与聊天操作放在一起，点击后才加载面板。
  const renderDebugButton = (mobile: boolean) => {
    if (!showChat) return null;
    const open = activeTopPanel === "debug";
    return (
      <button
        ref={debugButtonRef}
        type="button"
        onClick={() => toggleTopPanel("debug", mobile)}
        title={translate("debug.title")}
        aria-label={translate("debug.title")}
        aria-pressed={open}
        style={{
          display: "flex", alignItems: "center", justifyContent: "center",
          width: TOP_BAR_ICON_BUTTON_SIZE, height: "100%", padding: 0,
          background: open ? "var(--bg-selected)" : "none",
          border: "none",
          borderTop: open ? "2px solid var(--accent)" : "2px solid transparent",
          ...(mobile ? { borderRight: "1px solid var(--border)" } : { borderLeft: "1px solid var(--border)" }),
          color: open ? "var(--text)" : "var(--text-muted)",
          cursor: "pointer", flexShrink: 0, transition: "color 0.1s, background 0.1s",
        }}
        onMouseEnter={(event) => {
          event.currentTarget.style.color = "var(--text)";
        }}
        onMouseLeave={(event) => {
          event.currentTarget.style.color = open ? "var(--text)" : "var(--text-muted)";
        }}
        data-mobile-toolbar-action={mobile ? "debug" : undefined}
      >
        <svg width={mobile ? 16 : 13} height={mobile ? 16 : 13} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ color: open ? "var(--accent)" : "var(--text-dim)", flexShrink: 0 }} aria-hidden="true">
          <path d="M8 2l1.9 1.9M16 2l-1.9 1.9M9 7.1v-1a3 3 0 0 1 6 0v1" />
          <path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6zM12 20v-9" />
          <path d="M6.5 9C4.6 8.8 3 7.1 3 5M6 13H2M3 21c0-2.1 1.7-3.9 3.8-4M21 5c0 2.1-1.6 3.8-3.5 4M22 13h-4M17.2 17c2.1.1 3.8 1.9 3.8 4" />
        </svg>
      </button>
    );
  };

  const renderMainFileToggle = (mobile: boolean) => {
    const covered = mobile && isNarrowMobile && mobileToolbarMoreOpen;
    return (
      <button
        type="button"
        onClick={handleRightPanelToggle}
        disabled={covered}
        tabIndex={covered ? -1 : undefined}
        aria-controls="file-panel"
        aria-expanded={rightPanelOpen}
        aria-hidden={covered ? true : undefined}
        title={rightPanelOpen ? translate("files.hidePanel") : translate("files.showPanel")}
        aria-label={rightPanelOpen ? translate("files.hidePanel") : translate("files.showPanel")}
        data-mobile-toolbar-file={mobile ? "true" : undefined}
        style={{
          marginLeft: !mobile && !showChat ? "auto" : 0,
          display: "flex", alignItems: "center", justifyContent: "center",
          width: TOP_BAR_ICON_BUTTON_SIZE, height: TOP_BAR_ICON_BUTTON_SIZE, padding: 0,
          visibility: covered ? "hidden" : "visible",
          pointerEvents: covered ? "none" : "auto",
          background: rightPanelOpen ? activeToolbarBackground : "none",
          border: "none", borderLeft: "1px solid var(--border)",
          color: rightPanelOpen ? activeToolbarColor : "var(--text-muted)",
          cursor: "pointer", flexShrink: 0, transition: "color 0.12s, background 0.12s",
        }}
        onMouseEnter={(event) => { if (!covered) event.currentTarget.style.color = "var(--text)"; }}
        onMouseLeave={(event) => { event.currentTarget.style.color = rightPanelOpen ? activeToolbarColor : "var(--text-muted)"; }}
      >
        <FolderIcon size={18} />
      </button>
    );
  };

  const renderOpenSessionInNewTab = (mobile: boolean) => {
    const target = selectedSession && !selectedSession.transient
      ? sessionDeepLink(selectedSession.id)
      : effectiveNewSessionCwd
        ? newSessionDeepLink(effectiveNewSessionCwd)
        : null;
    const disabled = target === null;
    return (
      <button
        type="button"
        onClick={() => {
          if (!target) return;
          window.open(target, "_blank", "noopener,noreferrer");
        }}
        disabled={disabled}
        title={translate("sidebar.openInNewTab")}
        aria-label={translate("sidebar.openInNewTab")}
        style={{
          display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
          width: mobile ? TOP_BAR_ICON_BUTTON_SIZE : undefined,
          height: TOP_BAR_ICON_BUTTON_SIZE, padding: mobile ? 0 : "0 12px",
          marginLeft: mobile ? 0 : "auto",
          background: "none",
          border: "none", borderLeft: "1px solid var(--border)",
          color: disabled ? "var(--text-dim)" : "var(--text-muted)",
          cursor: disabled ? "not-allowed" : "pointer", flexShrink: 0,
          opacity: disabled ? 0.45 : 1, fontSize: 11, whiteSpace: "nowrap",
          transition: "color 0.12s, background 0.12s, opacity 0.12s",
        }}
        onMouseEnter={(event) => {
          if (!disabled) event.currentTarget.style.color = "var(--text)";
        }}
        onMouseLeave={(event) => {
          event.currentTarget.style.color = disabled ? "var(--text-dim)" : "var(--text-muted)";
        }}
      >
        <OpenInNewTabIcon size={17} />
        {!mobile && <span>{translate("sidebar.openInNewTab")}</span>}
      </button>
    );
  };

  const renderDigitalHumanToggle = (mobile: boolean) => {
    // 面板展开时由其右上角的数字人图标负责隐藏；这里只保留隐藏后的恢复入口。
    if (!isRuoyiIntegration || !digitalHumanAllowed || !digitalHumanVisibilityReady || digitalHumanOpen) return null;
    const covered = mobile && isNarrowMobile && mobileToolbarMoreOpen;
    return (
      <button
        type="button"
        onClick={handleDigitalHumanToggle}
        disabled={covered}
        tabIndex={covered ? -1 : undefined}
        aria-controls="digital-human-panel"
        aria-expanded={false}
        aria-hidden={covered ? true : undefined}
        title="显示业务助手"
        aria-label="显示业务助手"
        style={{
          display: "flex", alignItems: "center", justifyContent: "center",
          width: TOP_BAR_ICON_BUTTON_SIZE, height: TOP_BAR_ICON_BUTTON_SIZE, padding: 0,
          visibility: covered ? "hidden" : "visible",
          pointerEvents: covered ? "none" : "auto",
          background: "none",
          border: "none", borderLeft: "1px solid var(--border)",
          color: "var(--text-muted)",
          cursor: "pointer", flexShrink: 0, transition: "color 0.12s, background 0.12s",
        }}
        onMouseEnter={(event) => { if (!covered) event.currentTarget.style.color = "var(--text)"; }}
        onMouseLeave={(event) => { event.currentTarget.style.color = "var(--text-muted)"; }}
      >
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <circle cx="12" cy="8" r="3" /><path d="M5 21a7 7 0 0 1 14 0M19 4v4m2-2h-4" />
        </svg>
      </button>
    );
  };

  if (isEmbeddedRuoyi && !isRuoyiAuthenticated) {
    return (
      <div
        role="status"
        aria-live="polite"
        style={{
          display: "flex", alignItems: "center", justifyContent: "center",
          width: "100%", height: "var(--app-viewport-height, 100dvh)",
          color: "var(--text-muted)", background: "var(--bg)", fontSize: 14,
        }}
      >
        正在验证当前账号…
      </div>
    );
  }

  return (
    <>
    <style>{`
      @keyframes session-info-pop {
        0% {
          opacity: 0;
          transform: translateY(-24px);
          filter: blur(6px);
          box-shadow: 0 2px 8px rgba(0,0,0,0);
        }
        55% {
          opacity: 1;
          transform: translateY(0);
          filter: blur(0);
          background: color-mix(in srgb, var(--accent) 8%, var(--bg-panel));
          box-shadow: 0 18px 44px rgba(37,99,235,0.16);
        }
        100% {
          opacity: 1;
          transform: translateY(0);
          filter: blur(0);
          background: var(--bg-panel);
          box-shadow: 0 10px 28px rgba(0,0,0,0.10);
        }
      }
      @keyframes session-info-light-wash {
        0% {
          opacity: 0;
          transform: translateX(-110%) skewX(-16deg);
        }
        24% {
          opacity: 0.42;
        }
        100% {
          opacity: 0;
          transform: translateX(115%) skewX(-16deg);
        }
      }
      .session-info-popover {
        position: relative;
        overflow: hidden;
        transform-origin: top right;
        animation: session-info-pop 360ms ease-out both;
        will-change: transform, opacity, filter, background, box-shadow;
      }
      .session-info-popover::after {
        content: "";
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        width: 44%;
        pointer-events: none;
        background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--accent) 24%, transparent), transparent);
        animation: session-info-light-wash 620ms ease-out both;
      }
      @media (prefers-reduced-motion: reduce) {
        .session-info-popover,
        .session-info-popover::after {
          animation: none;
        }
      }
      .mobile-session-stats {
        container-type: inline-size;
      }
      @container (max-width: 158px) {
        .mobile-session-stat-io {
          display: none !important;
        }
      }
      @container (max-width: 88px) {
        .mobile-session-stat-cost {
          display: none !important;
        }
      }
      @media (max-width: 640px) {
        .sidebar-overlay-backdrop.sidebar-mobile-pending {
          opacity: 0 !important;
          pointer-events: none !important;
        }
        .sidebar-container.sidebar-mobile-pending.sidebar-open {
          transform: translateX(calc(-100% - env(safe-area-inset-left)));
          box-shadow: none;
        }
      }
    `}</style>
    <div
      className={isRuoyiIntegration ? `qm-art-shell${isWorkbenchInline ? " is-workbench-inline" : ""}` : undefined}
      onPointerDownCapture={isRuoyiIntegration ? handleRuoyiToolbarPointerDown : undefined}
      onPointerMoveCapture={isRuoyiIntegration ? handleRuoyiToolbarPointerMove : undefined}
      onPointerUpCapture={isRuoyiIntegration ? handleRuoyiToolbarPointerEnd : undefined}
      onPointerCancelCapture={isRuoyiIntegration ? handleRuoyiToolbarPointerEnd : undefined}
      style={{
      display: "flex",
      width: "100%",
      height: "var(--app-viewport-height, 100dvh)",
      paddingLeft: "env(safe-area-inset-left)",
      paddingRight: "env(safe-area-inset-right)",
      overflow: "hidden",
      background: "var(--bg)",
    }}>
      {/* Mobile overlay backdrop */}
      <div
        className={`sidebar-overlay-backdrop${mobileSidebarReady ? "" : " sidebar-mobile-pending"}`}
        onClick={() => setSidebarOpen(false)}
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 199,
          background: "rgba(0,0,0,0.4)",
          opacity: sidebarOpen ? 1 : 0,
          pointerEvents: sidebarOpen ? "auto" : "none",
          transition: "opacity 0.25s ease",
        }}
      />

      {/* Left sidebar */}
      <div
        ref={sidebarResizer.panelRef}
        id="session-sidebar"
        inert={rightPanelFullWidth}
        className={`sidebar-container qm-art-sidebar-panel${sidebarOpen ? " sidebar-open" : " sidebar-closed"}${mobileSidebarReady ? "" : " sidebar-mobile-pending"}${sidebarResizer.isResizing ? " sidebar-resizing" : ""}`}
        style={{
          "--sidebar-width": `${sidebarResizer.width}px`,
          // RuoYi 侧栏以旧版 Pi Web 的纯白内容区为准，不能继承外层浅灰画布色。
          background: isRuoyiIntegration ? "var(--bg)" : "var(--bg-panel)",
          borderRight: "1px solid var(--border)",
          display: "flex",
          flexDirection: "column",
          flexShrink: 0,
          paddingTop: "env(safe-area-inset-top)",
          paddingBottom: "env(safe-area-inset-bottom)",
          zIndex: 200,
        } as React.CSSProperties}
      >
        {sidebarContent}
      </div>
      {sidebarOpen && (
        <div
          {...sidebarResizer.separatorProps}
          inert={rightPanelFullWidth}
          aria-controls="session-sidebar"
          className={`panel-resize-handle sidebar-resize-handle${sidebarResizer.isResizing ? " is-resizing" : ""}`}
          data-resize-handle="sidebar"
          title={`${translate("layout.resizeSidebar")}: ${translate("layout.resizeHint")}`}
        />
      )}

      {/* Center: chat */}
      <div inert={rightPanelFullWidth} style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>
        {/* Top bar with sidebar toggle */}
        <div ref={topBarRef} className="qm-art-topbar" style={{ flexShrink: 0, background: "var(--bg)" }}>
        <div style={{ display: "flex", alignItems: "center", position: "relative", borderBottom: "1px solid var(--border)", height: "calc(var(--top-bar-height) + env(safe-area-inset-top))", paddingTop: "env(safe-area-inset-top)" }}>
          {(!isRuoyiIntegration || !sidebarOpen) && <button
            onClick={handleSidebarToggle}
             title={sidebarOpen ? translate("sidebar.hide") : translate("sidebar.show")}
             aria-label={sidebarOpen ? translate("sidebar.hide") : translate("sidebar.show")}
            aria-controls="session-sidebar"
            aria-pressed={sidebarOpen}
            style={{
              display: "flex", alignItems: "center", justifyContent: "center",
              width: TOP_BAR_ICON_BUTTON_SIZE, height: TOP_BAR_ICON_BUTTON_SIZE, padding: 0,
              background: sidebarOpen ? activeToolbarBackground : "none",
              border: "none", borderRight: "1px solid var(--border)",
              borderBottom: isRuoyiIntegration && !sidebarOpen ? "3px solid #409eff" : "3px solid transparent",
              color: sidebarOpen || isRuoyiIntegration ? activeToolbarColor : "var(--text-muted)",
              cursor: "pointer", flexShrink: 0, transition: "color 0.12s, background 0.12s",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.color = "var(--text)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.color = sidebarOpen || isRuoyiIntegration ? activeToolbarColor : "var(--text-muted)"; }}
          >
            {sidebarOpen ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2" /><line x1="9" y1="3" x2="9" y2="21" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2" /><line x1="15" y1="3" x2="15" y2="21" />
              </svg>
            )}
          </button>}
          {isMobile && (
            <div
              ref={mobileToolbarRef}
              data-mobile-toolbar="true"
              style={{
                position: "relative",
                display: "flex",
                alignItems: "stretch",
                flex: 1,
                minWidth: 0,
                height: "100%",
              }}
            >
              {isNarrowMobile && renderAgentsButton(true)}
              {isNarrowMobile && (
                <button
                  type="button"
                  onClick={handleMobileToolbarMoreToggle}
                  title={moreControlsLabel}
                  aria-label={moreControlsLabel}
                  aria-controls="mobile-toolbar-actions"
                  aria-expanded={mobileToolbarMoreOpen}
                  data-mobile-toolbar-more="true"
                  style={{
                    position: "relative",
                    zIndex: mobileToolbarMoreOpen ? 21 : undefined,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    width: TOP_BAR_ICON_BUTTON_SIZE, height: TOP_BAR_ICON_BUTTON_SIZE, padding: 0,
                    background: mobileToolbarMoreOpen ? "var(--bg-selected)" : "none",
                    border: "none", borderRight: "1px solid var(--border)",
                    color: mobileToolbarMoreOpen ? "var(--text)" : "var(--text-muted)",
                    cursor: "pointer", flexShrink: 0, transition: "color 0.12s, background 0.12s",
                  }}
                >
                  {mobileToolbarMoreOpen ? (
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                      <line x1="5" y1="5" x2="19" y2="19" /><line x1="19" y1="5" x2="5" y2="19" />
                    </svg>
                  ) : (
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                      <circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" />
                    </svg>
                  )}
                </button>
              )}
              {!isNarrowMobile && renderChatToolbarActions(true)}
              {!isNarrowMobile && renderDebugButton(true)}
              {renderSessionStatsButton(true)}
              {renderOpenSessionInNewTab(true)}
              {renderMainFileToggle(true)}
              {renderDigitalHumanToggle(true)}
              {isNarrowMobile && mobileToolbarMoreOpen && (
                <div
                  id="mobile-toolbar-actions"
                  role="toolbar"
                  aria-label={translate("chat.moreControls")}
                  data-mobile-toolbar-actions="true"
                  style={{
                    position: "absolute",
                    top: 0,
                    right: 0,
                    bottom: 0,
                    // Right of the Agents and More buttons, which stay in place.
                    left: `calc(2 * ${TOP_BAR_ICON_BUTTON_SIZE})`,
                    zIndex: 20,
                    display: "flex",
                    alignItems: "stretch",
                    // More buttons than a 320px phone fits (the Debug button made seven): scroll, never clip.
                    overflowX: "auto",
                    overflowY: "hidden",
                    scrollbarWidth: "none",
                    background: "color-mix(in srgb, var(--bg-panel) 94%, var(--bg))",
                    boxShadow: "4px 0 18px rgba(0,0,0,0.12)",
                    backdropFilter: "blur(10px)",
                  }}
                >
                  {renderChatToolbarActions(true)}
                  {renderDebugButton(true)}
                </div>
              )}
            </div>
          )}
          {!isMobile && (
            <>
              {renderProjectTrustWarning(false)}
              {renderChatToolbarActions(false)}
              {renderDebugButton(false)}
              {showChat && <div style={{ flex: 1 }} />}
            </>
          )}
          {!isMobile && renderOpenSessionInNewTab(false)}
          {!isMobile && renderMainFileToggle(false)}
          {!isMobile && renderDigitalHumanToggle(false)}
          {isMobile && sessionHasBranches && (
            <BranchNavigator
              tree={branchTree}
              activeLeafId={branchActiveLeafId}
              onLeafChange={handleBranchLeafChange}
              locked={branchSwitchLocked}
              inline
              compact
              containerRef={topBarRef}
              open={activeTopPanel === "branches"}
              onToggle={() => toggleTopPanel("branches")}
              hasSession={showChat}
              hideInlineButton
            />
          )}
          {/* Top panel dropdown — shared, only one active at a time */}
          {activeTopPanel && topPanelPos && (
            <div style={{
              position: "fixed",
              top: topPanelPos.top,
              left: topPanelPos.left,
              width: topPanelPos.width,
              maxHeight: `calc(100dvh - ${topPanelPos.top}px)`,
              overflowY: "auto",
              zIndex: 500,
            }}>
              {activeTopPanel === "agents" && activeSessionFamily && selectedSession && (
                <AgentSessionPanel
                  rootSession={activeSessionFamily.root}
                  subagents={activeSessionFamily.subagents}
                  selectedSessionId={selectedSession.id}
                  runningSessionIds={runningSessionIds}
                  onSelectSession={handleSelectSession}
                  openSubagentTabIds={openSubagentTabIds}
                  onToggleSubagentTab={handleToggleSubagentTab}
                  onNewSideChat={() => handleNewSideChat(activeSessionFamily.root.id)}
                  onDeleteSideChat={(sessionId) => handleDeleteSideChat(sessionId, activeSessionFamily.root)}
                />
              )}
              {activeTopPanel === "system" && (
                <SystemPromptPanel
                  loading={systemInfoLoading}
                  prompt={systemPrompt}
                  locale={locale}
                  translate={translate}
                />
              )}
              {activeTopPanel === "tools" && (
                <ToolDefinitionsPanel
                  loading={systemInfoLoading}
                  tools={systemTools}
                  translate={translate}
                  lightSurface={isRuoyiIntegration}
                />
              )}
              {activeTopPanel === "session" && (
                <div className="session-info-popover" style={{
                  background: "var(--bg-panel)",
                  borderBottom: "1px solid var(--border)",
                  boxShadow: "0 10px 28px rgba(0,0,0,0.10)",
                  padding: "12px 16px",
                  ...(isRuoyiIntegration && !isMobile ? { width: "min(560px, 100%)", marginLeft: "auto" } : {}),
                }}>
                  {sessionStats ? (() => {
                    const totalActiveMs = sessionStats.totalActiveMs ?? 0;
                    const ws = selectedSession;
                    // 企业会话不展示本机路径、会话标识及项目元数据，避免暴露内部目录结构。
                    const showSessionDiagnostics = !isRuoyiIntegration;
                    const sessionRows = [
                       ...(sessionStats.sessionName ? [{ label: translate("session.name"), value: sessionStats.sessionName, copyField: null }] : []),
                       ...(showSessionDiagnostics ? [
                         { label: translate("session.file"), value: sessionStats.sessionFile ?? translate("session.inMemory"), copyField: "file" as const },
                         { label: translate("session.id"), value: sessionStats.sessionId, copyField: "id" as const },
                         ...(totalActiveMs > 0 ? [{ label: translate("session.totalActive"), value: formatActiveDuration(totalActiveMs), copyField: null }] : []),
                       ] : []),
                    ];
                    const projectRows = showSessionDiagnostics ? [
                      ...(ws ? [{ label: translate("session.projectDir"), value: ws.projectRoot ?? ws.cwd, copyField: "projectDir" as const }] : []),
                      ...(ws?.branch ? [{ label: translate("session.gitBranch"), value: ws.branch, copyField: "gitBranch" as const }] : []),
                      ...(ws?.isWorktree ? [{ label: translate("session.gitWorktree"), value: ws.cwd, copyField: "gitWorktree" as const }] : []),
                    ] : [];
                    const messageRows = [
                       [translate("session.user"), sessionStats.userMessages.toLocaleString(locale)],
                       [translate("session.assistant"), sessionStats.assistantMessages.toLocaleString(locale)],
                       [translate("session.toolCalls"), sessionStats.toolCalls.toLocaleString(locale)],
                       [translate("session.toolResults"), sessionStats.toolResults.toLocaleString(locale)],
                       [translate("session.total"), sessionStats.totalMessages.toLocaleString(locale)],
                    ];
                    const tokenRows = [
                       [translate("session.input"), sessionStats.tokens.input.toLocaleString(locale)],
                       [translate("session.output"), sessionStats.tokens.output.toLocaleString(locale)],
                       ...(sessionStats.tokens.cacheRead > 0 ? [[translate("session.cacheRead"), sessionStats.tokens.cacheRead.toLocaleString(locale)]] : []),
                       ...(sessionStats.tokens.cacheWrite > 0 ? [[translate("session.cacheWrite"), sessionStats.tokens.cacheWrite.toLocaleString(locale)]] : []),
                       [translate("session.total"), sessionStats.tokens.total.toLocaleString(locale)],
                    ];
                    const ctx = contextUsage ?? sessionStats.contextUsage;
                    const extraTokenRows = [
                       ...(sessionStats.cost > 0 ? [[translate("session.cost"), `$${sessionStats.cost.toFixed(4)}`]] : []),
                       ...(ctx?.contextWindow ? [[translate("session.context"), `${ctx.percent !== null ? `${ctx.percent.toFixed(1)}%` : "?"} / ${formatCompactCount(ctx.contextWindow)}`]] : []),
                       // Cache hit rate = cache reads / (input + cache writes + cache reads) — the denominator covers all input-class tokens.
                       ...(sessionStats.tokens.cacheRead + sessionStats.tokens.cacheWrite > 0 && sessionStats.tokens.cacheRead + sessionStats.tokens.cacheWrite + sessionStats.tokens.input > 0
                         ? [[translate("session.cacheHitRate"), `${(sessionStats.tokens.cacheRead / (sessionStats.tokens.cacheRead + sessionStats.tokens.cacheWrite + sessionStats.tokens.input) * 100).toFixed(1)}%`]]
                         : []),
                    ];
                    const section = (
                      title: string,
                      sectionRows: string[][],
                      valueAlign: "left" | "right" = "left",
                      compact = false,
                    ) => (
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text)", marginBottom: 6 }}>{title}</div>
                          <div style={{
                            display: "grid",
                            gridTemplateColumns: compact ? "max-content max-content" : "auto minmax(0, 1fr)",
                            columnGap: compact ? 14 : 12,
                            rowGap: 4,
                            justifyContent: compact ? "start" : undefined,
                          }}>
                            {sectionRows.map(([label, value]) => (
                              <div key={`${title}:${label}`} style={{ display: "contents" }}>
                                <div style={{ color: "var(--text-dim)", whiteSpace: "nowrap" }}>{label}</div>
                                <div style={{
                                  color: "var(--text-muted)",
                                  minWidth: 0,
                                  overflowWrap: compact ? "normal" : "anywhere",
                                  textAlign: valueAlign,
                                  whiteSpace: valueAlign === "right" ? "nowrap" : "normal",
                                }}>{value}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    const copyTitleKey: Record<SessionCopyField, string> = {
                      file: "session.copyFile",
                      id: "session.copyId",
                      projectDir: "session.copyProjectDir",
                      gitBranch: "session.copyGitBranch",
                      gitWorktree: "session.copyGitWorktree",
                    };
                    const copyButton = (field: SessionCopyField, value: string) => {
                      const copied = copiedSessionField === field;
                      return (
                        <button
                          type="button"
                          title={copied ? translate("session.copied") : translate(copyTitleKey[field])}
                          onClick={() => handleCopySessionField(field, value)}
                          style={{
                            alignSelf: "start",
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: 22,
                            height: 22,
                            marginTop: -2,
                            color: copied ? "var(--accent)" : "var(--text-dim)",
                            background: "transparent",
                            border: "1px solid var(--border)",
                            borderRadius: 4,
                            cursor: "pointer",
                            flex: "0 0 auto",
                            transition: "color 0.12s, border-color 0.12s, background 0.12s",
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.color = "var(--accent)";
                            e.currentTarget.style.borderColor = "var(--accent)";
                            e.currentTarget.style.background = "var(--bg-hover)";
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.color = copied ? "var(--accent)" : "var(--text-dim)";
                            e.currentTarget.style.borderColor = "var(--border)";
                            e.currentTarget.style.background = "transparent";
                          }}
                        >
                          {copied ? (
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                              <polyline points="20 6 9 17 4 12" />
                            </svg>
                          ) : (
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                              <rect x="9" y="9" width="13" height="13" rx="2" ry="2" />
                              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
                            </svg>
                          )}
                        </button>
                      );
                    };
                    const sessionInfoSection = sessionRows.length > 0 ? (
                      <div style={{ minWidth: 0 }}>
                         <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text)", marginBottom: 6 }}>{translate("session.infoSection")}</div>
                        <div style={{ display: "grid", gridTemplateColumns: "auto minmax(0, 1fr) auto", columnGap: 12, rowGap: 8, alignItems: "start" }}>
                          {sessionRows.map((row) => (
                            <div key={`session-info:${row.label}`} style={{ display: "contents" }}>
                              <div style={{ color: "var(--text-dim)", whiteSpace: "nowrap" }}>{row.label}</div>
                              <div style={{
                                color: "var(--text-muted)",
                                minWidth: 0,
                                overflowWrap: "anywhere",
                                wordBreak: "break-word",
                                whiteSpace: "normal",
                              }}>{row.value}</div>
                              <div>{row.copyField ? copyButton(row.copyField, row.value) : null}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null;
                    const projectInfoSection = projectRows.length > 0 ? (
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text)", marginBottom: 6 }}>{translate("session.projectSection")}</div>
                        <div style={{ display: "grid", gridTemplateColumns: "auto minmax(0, 1fr) auto", columnGap: 12, rowGap: 8, alignItems: "start" }}>
                          {projectRows.map((row) => (
                            <div key={`project-info:${row.label}`} style={{ display: "contents" }}>
                              <div style={{ color: "var(--text-dim)", whiteSpace: "nowrap" }}>{row.label}</div>
                              <div style={{
                                color: "var(--text-muted)",
                                minWidth: 0,
                                overflowWrap: "anywhere",
                                wordBreak: "break-word",
                                whiteSpace: "normal",
                              }}>{row.value}</div>
                              <div>{row.copyField ? copyButton(row.copyField, row.value) : null}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ) : null;

                    const statistics = isRuoyiIntegration ? (
                      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                        {sessionInfoSection}
                        <div style={{ display: "grid", gridTemplateColumns: "minmax(120px, 0.65fr) minmax(220px, 1.35fr)", gap: 18 }}>
                          {section(translate("session.messages"), messageRows)}
                          {section(translate("session.tokens"), [...tokenRows, ...extraTokenRows], "right", true)}
                        </div>
                      </div>
                    ) : (
                      <div style={{
                        display: "grid",
                        gridTemplateColumns: isMobile ? "1fr" : "minmax(360px, 1.7fr) minmax(140px, 0.55fr) minmax(190px, 0.75fr)",
                        gap: isMobile ? 16 : 24,
                      }}>
                        <div style={{ display: "flex", flexDirection: "column", gap: isMobile ? 16 : 20 }}>
                          {sessionInfoSection}
                          {projectInfoSection}
                        </div>
                         {section(translate("session.messages"), messageRows)}
                         {section(translate("session.tokens"), [...tokenRows, ...extraTokenRows], "right", true)}
                      </div>
                    );

                    return (
                      <div style={{
                        fontSize: 12,
                        lineHeight: 1.5,
                        fontFamily: "var(--font-mono)",
                      }}>
                        {statistics}
                      </div>
                    );
                  })() : (
                    <div style={{ fontSize: 12, color: "var(--text-muted)", fontStyle: "italic" }}>
                       {translate("session.load")}
                    </div>
                  )}
                </div>
              )}
              {activeTopPanel === "debug" && (
                <DebugPanelBoundary fallback={translate("debug.failed")}>
                  <DebugPanel
                    readerRef={debugSnapshotReaderRef}
                    selectedSessionId={selectedSession?.id ?? null}
                    sessions={sessionsWithSelection}
                    onClose={closeDebugPanel}
                  />
                </DebugPanelBoundary>
              )}
            </div>
          )}

        </div>
        {isMobile && renderProjectTrustWarning(true)}
        </div>

        {/* Chat content */}
        <div style={{ flex: 1, overflow: "hidden", position: "relative" }}>
          {showChat ? (
            <ChatWindow
              key={sessionKey}
              session={selectedSession}
              searchTarget={searchTarget?.sessionId === selectedSession?.id ? searchTarget : null}
              onSearchTargetHandled={handleSearchTargetHandled}
              initialScrollPosition={selectedSession ? sessionScrollPositionsRef.current.get(selectedSession.id) ?? null : null}
              onScrollPositionChange={handleSessionScrollPositionChange}
              sessionRunning={Boolean(selectedSession && runningSessionIds.has(selectedSession.id))}
              newSessionCwd={effectiveNewSessionCwd}
              newSessionDraftKey={newSessionDraftKey}
              newSessionContextBar={newSessionContextBar}
              businessMode={isRuoyiIntegration}
              initialNewSessionChoices={selectedSession === null ? carriedNewSessionChoices : null}
              onNewSessionChoicesChange={handleNewSessionChoicesChange}
              onAgentEnd={handleAgentEnd}
              onAssistantTextStart={() => {
                if (!isHeadlessRuoyi) digitalHumanRef.current?.start();
                postRuoyiParentMessage({ type: "qimiao-agent-response-start" });
              }}
              onAssistantTextDelta={(text) => {
                if (!isHeadlessRuoyi) digitalHumanRef.current?.append(text);
                postRuoyiParentMessage({ type: "qimiao-agent-response-delta", text });
              }}
              onAssistantTextEnd={(end) => {
                if (!isHeadlessRuoyi) {
                  if (end.aborted) digitalHumanRef.current?.stop();
                  else digitalHumanRef.current?.finish();
                }
                postRuoyiParentMessage({ type: "qimiao-agent-response-end", aborted: end.aborted });
              }}
              onToolEvent={(event) => {
                postRuoyiParentMessage({
                  type: "qimiao-agent-tool",
                  toolCallId: event.toolCallId,
                  toolName: event.toolName,
                  status: event.status,
                });
              }}
              onSpeakAnswer={isRuoyiIntegration && digitalHumanAllowed ? handleSpeakAnswer : undefined}
              onToolEnd={handleToolEnd}
              onAttentionNeeded={handleAttentionNeeded}
              onSessionCreated={handleSessionCreated}
              onSessionForked={handleSessionForked}
              onSideSession={handleSideSession}
              modelsRefreshKey={modelsRefreshKey}
              chatInputRef={chatInputRef}
              onBranchDataChange={handleBranchDataChange}
              onSystemPromptChange={handleSystemPromptChange}
              onSystemToolsChange={handleSystemToolsChange}
              onSystemInfoLoaderChange={handleSystemInfoLoaderChange}
              onDebugSnapshotReaderChange={handleDebugSnapshotReaderChange}
              onSessionStatsChange={handleSessionStatsChange}
              onSessionStatsPanelOpen={openSessionStatsPanel}
              composerSessionStats={isMobile ? undefined : renderSessionStatsButton(false, "composer")}
              onOpenSettings={openSettingsSection}
              onContextUsageChange={handleContextUsageChange}
              onOpenFile={handleOpenLinkedFile}
              onFilesUploaded={handleExplorerRefresh}
              onOpenSubagent={handleOpenSubagentTab}
              quoteSelectionEnabled={quoteSelectionEnabled}
              externalPrompt={ruoyiExternalPrompt}
              externalPromptReady={initialSessionRestored && isRuoyiAuthenticated}
              onExternalPromptReady={isRuoyiIntegration ? handleExternalPromptReady : undefined}
              onExternalPromptRejected={() => postRuoyiParentMessage({ type: "qimiao-agent-response-end", aborted: true })}
              onExternalPromptConsumed={(id) => {
                setRuoyiExternalPrompt((current) => current?.id === id ? null : current);
              }}

              soundEnabled={soundEnabled}
              onSoundToggle={onSoundToggle}
              playDoneSound={playDoneSound}
              unlockAudio={unlockAudio}
              holdAudio={holdAudio}
            />
          ) : initialCwdStatus === "validating" ? (
            <div
              role="status"
              style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, padding: 24, color: "var(--text-muted)", textAlign: "center" }}
            >
              <div style={{ fontSize: 14, color: "var(--text)" }}>
                {isRuoyiIntegration ? "正在验证当前账号…" : translate("workspace.opening")}
              </div>
              {!isRuoyiIntegration && (
                <div style={{ maxWidth: "min(720px, 100%)", overflowWrap: "anywhere", fontFamily: "var(--font-mono)", fontSize: 12 }}>
                  {initialNavigation.requestedCwd}
                </div>
              )}
            </div>
          ) : initialCwdStatus === "error" ? (
            <div
              role="alert"
              style={{ height: "100%", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 8, padding: 24, color: "var(--text-muted)", textAlign: "center" }}
            >
               <div style={{ fontSize: 14, color: "#dc2626" }}>{translate("workspace.unable")}</div>
              <div style={{ maxWidth: "min(720px, 100%)", overflowWrap: "anywhere", fontFamily: "var(--font-mono)", fontSize: 12 }}>
                {initialNavigation.requestedCwd}
              </div>
              <div style={{ maxWidth: 720, fontSize: 12 }}>{initialCwdError}</div>
            </div>
          ) : showPlaceholder ? (
            activeCwd ? (
              <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "var(--text-muted)", fontSize: 15 }}>
                 {translate("workspace.selectSession")}
              </div>
            ) : (
              <div style={{ position: "absolute", top: 12, left: 12, display: "flex", alignItems: "flex-start", gap: 8, userSelect: "none", pointerEvents: "none" }}>
                <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.7, flexShrink: 0 }}>
                  <line x1="20" y1="12" x2="4" y2="12" /><polyline points="10 6 4 12 10 18" />
                </svg>
                <div>
                   <div style={{ fontSize: 18, fontWeight: 600, color: "var(--text)", marginBottom: 8 }}>{translate("workspace.getStarted")}</div>
                  <div style={{ fontSize: 12, color: "var(--text-muted)", lineHeight: 1.8 }}>
                     <span style={{ color: "var(--text-dim)", marginRight: 6 }}>1.</span>{translate("workspace.selectProject")}<br />
                     <span style={{ color: "var(--text-dim)", marginRight: 6 }}>2.</span>{translate("workspace.addModels")}
                  </div>
                </div>
              </div>
            )
          ) : null}
        </div>
      </div>

      <div
        aria-hidden="true"
        className={`right-panel-overlay-backdrop${rightPanelOpen ? " is-open" : ""}`}
        onClick={() => setRightPanelOpen(false)}
      />
      {rightPanelOpen && (
        <div
          {...rightPanelResizer.separatorProps}
          inert={rightPanelFullWidth}
          aria-controls="file-panel"
          className={`panel-resize-handle right-panel-resize-handle${rightPanelResizer.isResizing ? " is-resizing" : ""}`}
          data-resize-handle="right-panel"
          title={`${translate("layout.resizeFilePanel")}: ${translate("layout.resizeHint")}`}
        />
      )}

      {/* Right panel: file viewer — always mounted, width animated via CSS */}
      <div
        ref={rightPanelResizer.panelRef}
        id="file-panel"
        className={`right-panel-container${rightPanelOpen ? " right-panel-open" : " right-panel-closed"}${rightPanelFullWidth ? " right-panel-full-width" : ""}${rightPanelResizer.isResizing ? " right-panel-resizing" : ""}`}
        style={{
          "--right-panel-width": `${rightPanelResizer.width}px`,
          display: "flex",
          flexDirection: "column",
          borderLeft: "1px solid var(--border)",
          background: "var(--bg)",
        } as React.CSSProperties}
      >
        {/* Right panel tab bar */}
        <div style={{
          display: "flex",
          alignItems: "center",
          flexShrink: 0,
          height: "calc(var(--top-bar-height) + env(safe-area-inset-top))",
          paddingTop: "env(safe-area-inset-top)",
          background: isRuoyiIntegration ? "var(--bg)" : "var(--bg-panel)",
          borderBottom: "1px solid var(--border)",
        }}>
          <div style={{ flex: 1, overflow: "hidden" }}>
            {isRuoyiIntegration && !activePanelHasContent ? (
              <div className="ruoyi-file-panel-title">{translate("sidebar.tabFiles")}</div>
            ) : (
              <TabBar
                tabs={panelTabs}
                activeTabId={activeFileTabId ?? ""}
                onSelectTab={setActiveFileTabId}
                onCloseTab={handleCloseFileTab}
                onReorderTab={(source, target, after) => setPanelTabOrder(movePanelTab(panelTabs.map((tab) => tab.id), source, target, after))}
                background={isRuoyiIntegration ? "var(--bg)" : undefined}
              />
            )}
          </div>
          {isRuoyiIntegration && renderRuoyiFileActions()}
          <button
            type="button"
            className="file-panel-expand-button"
            onClick={handleRightPanelExpandToggle}
            aria-controls="file-panel"
            aria-pressed={rightPanelFullWidth}
            style={isRuoyiIntegration && rightPanelFullWidth
              ? { color: "#409eff", background: "#ecf5ff" }
              : isRuoyiIntegration ? { background: "var(--bg)" } : undefined}
            title={translate(rightPanelFullWidth ? "files.restorePanelWidth" : "files.expandPanel")}
            aria-label={translate(rightPanelFullWidth ? "files.restorePanelWidth" : "files.expandPanel")}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d={rightPanelFullWidth
                ? "M9 3v6H3m12-6v6h6M9 21v-6H3m12 6v-6h6M3 3l6 6m12-6-6 6M3 21l6-6m12 6-6-6"
                : "M8 3H3v5m13-5h5v5M3 16v5h5m13-5v5h-5M3 3l6 6m12-6-6 6M3 21l6-6m12 6-6-6"} />
            </svg>
          </button>
          <button
            type="button"
            onClick={() => setRightPanelOpen(false)}
            aria-controls="file-panel"
            aria-expanded={rightPanelOpen}
            title={translate("files.hidePanel")}
            aria-label={translate("files.hidePanel")}
            style={{
              display: "flex", alignItems: "center", justifyContent: "center",
              width: TOP_BAR_ICON_BUTTON_SIZE, height: TOP_BAR_ICON_BUTTON_SIZE, padding: 0,
              background: isRuoyiIntegration ? "var(--bg)" : "var(--bg-selected)", border: "none", borderLeft: "1px solid var(--border)",
              color: "var(--text)", cursor: "pointer", flexShrink: 0, transition: "color 0.12s",
            }}
            onMouseEnter={(event) => { event.currentTarget.style.color = "var(--accent)"; }}
            onMouseLeave={(event) => { event.currentTarget.style.color = "var(--text)"; }}
          >
            {isRuoyiIntegration ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
                <line x1="6" y1="6" x2="18" y2="18" /><line x1="18" y1="6" x2="6" y2="18" />
              </svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <rect x="3" y="3" width="18" height="18" rx="2" /><line x1="15" y1="3" x2="15" y2="21" />
              </svg>
            )}
          </button>
        </div>

        {/* Only the active viewer is mounted. Lightweight per-tab state is restored on activation. */}
        <div style={{ flex: 1, minHeight: 0, overflow: "hidden", paddingBottom: "env(safe-area-inset-bottom)" }}>
          {isRuoyiIntegration ? (
            <div className={`ruoyi-file-workbench${activePanelHasContent ? " is-viewing" : ""}`}>
              {activePanelHasContent && <div className="ruoyi-file-viewer">{panelTabContent}</div>}
              <aside className="ruoyi-file-browser" aria-label={translate("sidebar.tabFiles")}>
                <div className="ruoyi-file-browser-scroll scrollbar-subtle">
                  {rightExplorerCwd ? (
                    <FileExplorer
                      ref={rightFileExplorerRef}
                      cwd={rightExplorerCwd}
                      onOpenFile={handleOpenFile}
                      refreshKey={explorerRefreshKey}
                      onAtMention={handleAtMention}
                      onAtMentions={handleAtMentions}
                      onUploadBusyChange={setRightExplorerUploadBusy}
                      changesCollapsed={rightExplorerChangesCollapsed}
                      onChangesCountChange={setRightExplorerChangesCount}
                      fileSearchOpen={rightFileSearchOpen}
                      onFileSearchOpenChange={setRightFileSearchOpen}
                      showHidden={rightExplorerShowIgnoredFiles}
                    />
                  ) : (
                    <div className="ruoyi-file-browser-empty">{translate("sidebar.selectProject")}</div>
                  )}
                </div>
              </aside>
            </div>
          ) : panelTabContent}
        </div>
      </div>
      {isRuoyiIntegration && digitalHumanAllowed && digitalHumanVisibilityReady && digitalHumanOpen && (
        <aside id="digital-human-panel" className="digital-human-side-panel" aria-label="业务助手">
          <DigitalHumanPanel ref={digitalHumanRef} onClose={() => { void updateDigitalHumanVisibility(false); }} onReady={handleDigitalHumanReady} />
        </aside>
      )}
    </div>
    {settingsSection && (
      <SettingsPanel
        cwd={projectTrustCwd}
        sessionId={selectedSession?.id ?? null}
        isRuoyiIntegration={isRuoyiIntegration}
        initialSection={settingsSection}
        allowedSections={allowedSettingsSections}
        openAtHome={settingsOpenAtHome}
        quoteSelectionEnabled={quoteSelectionEnabled}
        onQuoteSelectionChange={handleQuoteSelectionChange}
        onClose={() => {
          setSettingsSection(null);
          setModelsRefreshKey((key) => key + 1);
        }}
        onSessionReloaded={() => setSessionKey((key) => key + 1)}
        projectTrust={isRuoyiIntegration ? null : projectTrust}
        onOpenTrustDialog={isRuoyiIntegration ? undefined : openProjectTrustDialog}
        onProjectTrustChanged={handleProjectTrustChanged}
      />
    )}
    {/* After Settings, so it opens above it (z-index 1100 over 1000) when Settings › MCP asks for it. */}
    {!isRuoyiIntegration && projectTrustDialogOpen && projectTrustCwd && (
      <ProjectTrustDialog
        cwd={projectTrustCwd}
        busy={projectTrustBusy}
        error={projectTrustError}
        onCancel={() => {
          if (!projectTrustBusy) setProjectTrustDialogOpen(false);
        }}
        onConfirm={() => void handleTrustProject()}
        onStatus={setProjectTrust}
      />
    )}
    </>
  );
}
